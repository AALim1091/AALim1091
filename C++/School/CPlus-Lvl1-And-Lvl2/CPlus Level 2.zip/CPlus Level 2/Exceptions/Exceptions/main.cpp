
#include <iostream>
using namespace std;

void riskyBusiness();

int main()
{

    return 0;
}

void riskyBusiness()
{
    char ch;
    cout << "Would you like"
}
