#include <iostream>
#include <fstream>
using namespace std;

struct clientData
{
    int accountNumber;
    char lastName[10];
    char firstName[15];
    double balance;
};
void writeFile();
void readFile();
bool writeClient();

int main()
{
    writeFile();
//    readFile();
//    writeClient();
    return 0;
}

void writeFile()
{
    ofstream outfile("numbers.txt");
    if(!outfile)
    {
        cout << "unable to open file"<< endl;
    }
    else
    {
        for(int j = 0; j<10; j++)
            {
            outfile << rand() % 100 + 1 << "\t";
            }
        
    }
    outfile.close();
}

void readFile()
{
    char line[100];
    ifstream infile("numbers.txt");
    if(!infile)
    {
        cout << "unable to open file"<< endl;
    }
    while (!infile.eof())
    {
        infile.getline(line,100);
        cout << line <<endl;
    }
    infile.close();
}

bool writeClient()
{
    clientData d[3] = {
        {1234, "smith", "joe", 222.22},
        {2345, "sJones", "Bill", 112.22},
        {3456, "akinson", "Greg", 332.22}
    };
    ofstream outData("credit.dat", ios::binary);
    if (!outData)
    {
        cout<< "Error Opening" <<endl;
        return false;
    }
    for (int i = 0; i<3; i++)
    {
        outData.write(reinterpret_cast<const char *>(&d[i]), sizeof(clientData));
    }
    outData.close();
    return true;
}
