#include <iostream>
#include <vector>

using namespace std;
void fillV(vector <int> v);

int main()
{
//    vector<int> v(32);
//    v.reserve(32);
//    
//    fillV(v);
//    cout << v[0] <<endl;
    
    int *p;
    int x[10] = {1,4,3,4,5,6,7,8};
    
    p = x;
    
    cout << p << endl;
    cout << &x << endl;
    cout << *p << endl;
    cout << x << endl;
    cout << p + 1 << endl;
    cout << &p << endl;
    cout << * (p + 1) << endl;
    cout << &p << endl;
    cout << *(++p) << endl;
    
    

    return 0;
}

void fillV(vector <int> v)
{
    v[0] = 2;
}
