#include <iostream>
#include "Character.h"

using namespace std;

int main()
{
    Character c('A');
    Character c2;
    setChar(c2, 'Z');
    
    cout <<  c2 << endl;
    cout << c << endl;
    

    return 0;
}
