#include "Character.h"
#include <string>
#include <iostream>
#include <sstream>

using namespace std;

Character::Character()
{
    this->setChar(' ');
}

Character::Character(char aChar)
{
    this->setChar(aChar);
}

Character::Character(const Character &ch)
{
    this->setChar(ch.toChar());
}

void Character::setChar(char ch)
{
    this->ch = ch;
}


char Character::toChar() const
{
    return this->ch;
}
string Character::toString() const
{
    string st;
    st += this->ch;
    return st;
}
string Character::toHexString() const
{
    stringstream ss;
    ss << hex << static_cast<int>(this->ch);
    return ss.str();
}
int Character::toHex() const
{
    return stod(this->toHexString());
}
int Character::toInt() const
{
    return static_cast<int>(this->ch);
}

//Friends

ostream &operator<< (ostream &output, const Character &c)
{
    output << c.toChar() << endl;
    return output;
}
istream &operator>> (istream &input, Character &c)
{
    input >> c.ch;
    return input;
}
void setChar(Character &ch, char set)
{
    ch.ch = set;
}

