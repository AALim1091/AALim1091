#ifndef Character_h
#define Character_h
#include <string>
#include <stdio.h>
#include <istream>
#include <ostream>
using std::string;
using std::istream;
using std::ostream;
class Character
{
private:
    char ch;
public:
    Character();
    Character(char aChar);
    Character(const Character &ch);
//    mutator
    void setChar(char c);
//    accessor
    char toChar() const;
    string toString() const;
    string toHexString() const;
    int toHex() const;
    int toInt() const;
//    Friend Functions
    friend istream &operator>> (istream &input, Character &c);
    friend ostream &operator<< (ostream &output, const Character &c);
    friend void setChar(Character &ch, char set);
};

#endif /* Character_hpp */
