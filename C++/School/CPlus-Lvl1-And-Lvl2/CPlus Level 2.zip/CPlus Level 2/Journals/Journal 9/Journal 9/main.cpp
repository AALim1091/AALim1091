#include <iostream>
using namespace std;

class Animal
{
public:
    void talk();
    virtual void speak() = 0;
};
void Animal::talk()
{
    speak();
}
class Cat : public Animal
{
    void speak();
};
void Cat::speak()
{
    cout << "Meow" << endl;
}
class Lion : public Animal
{
    void speak();
};
void Lion::speak()
{
    cout << "Rawr" << endl;
}
class Dog : public Animal
{
    void speak();
};
void Dog::speak()
{
    cout << "Wrow" << endl;
}

int main()
{
    Cat cat;
    Dog dog;
    Lion lion;
    Animal *an[3];
    an[0] = &cat;
    an[1] = &dog;
    an[2] = &lion;
    
    for(int i = 0; i < 3; i++)
    {
        an[i]->talk();
    }
    return 0;
}
