//
//  Calc.h
//  Journal 10.1
//
//  Created by Julio Lopez on 5/19/17.
//  Copyright © 2017 Julio Lopez. All rights reserved.
//

#ifndef Calc_h
#define Calc_h
#include <exception>
#include <string>

using std::string;
using std::exception;

class calcExeption : public exception
{
private:
    string message;
public:
    calcExeption(string msg) : message(msg){};
    virtual const char *what() {return message.c_str();}
    
};


template <class T>
class Calc
{
private:
    T x, y;
public:
    Calc() {x=0, y = 0;}
    Calc(T a, T b) {x = a, y = b;}
    
    T add();
    T sub();
    T mul();
    T div();
    
};

template <class T>
T Calc<T>::add()
{
    if(y<0)
    {
        throw (calcExeption("Invalid Number"));
     }
    return this->x + this->y;
}
template <class T>
T Calc<T>::sub()
{
    return this->x - this->y;
}
template <class T>
T Calc<T>::mul()
{
    return this->x * this->y;
}
template <class T>
T Calc<T>::div()
{
    if(y == 0)
        throw (calcExeption("Error: Trying to divide by 0"));
    return this->x / this->y;
}
#endif /* Calc_h */
