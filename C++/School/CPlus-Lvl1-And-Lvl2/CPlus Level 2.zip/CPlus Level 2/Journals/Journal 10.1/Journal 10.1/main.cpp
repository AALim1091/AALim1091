
#include "Calc.h"
#include <iostream>


using namespace std;
int main()
{
    Calc<double> c(6.6, -3);

    try
    {
         double d = c.add();
        
    }
    catch(calcExeption &msg)
    {
        cout<< msg.what() <<endl;
    }
    

    
    return 0;
}


