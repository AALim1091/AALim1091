
#ifndef CALC_h
#define CALC_h

class Calc
{
private:
    int x, y;
public:
    Calc() {x=0, y = 0;}
    Calc(int a, int b) {x = a, y = b;}
    
    int add();
    
};

#endif /* CALC_h */
