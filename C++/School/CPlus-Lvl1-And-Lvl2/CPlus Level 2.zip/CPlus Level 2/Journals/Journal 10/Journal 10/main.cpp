#include <iostream>
#include "CALC.h"
using namespace std;

int maint()
{
    Calc c(6, 2);
    double d = c.add();
    cout << "The sum is " << d << endl;
    return 0;
}

int Calc::add()
{
    return this->x + this->y;
}
