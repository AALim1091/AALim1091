#include "Fraction.h"
#include <iostream>
using namespace std;

int main()
{
    Fraction f1(3,4);
    Fraction *f2 = new Fraction(f1);
    
    cout<< Fraction::counter<<endl;
    
    delete f2;

    cout<< Fraction::counter<<endl;
    cout << *f2;
    
    return 0;
}
  
