#include <iostream>
#include <string>
#include "Fraction.h"
using namespace std;
using std::string;


void Move(int n, char source, char destination, char spare);

int sumAsci(string str, int i);

int main()
{
    string str = "Hello";
    int count = sumAsci(str, 0);
    
    cout << count << endl;
    
    
    return 0;
}

void Move(int n, char source, char destination, char spare)
{
    if(n<=1)
        cout <<"Move the top disk from " << source << " to " << destination << endl;
    else
    {
        Move(n -1, source, spare, destination);
        Move( 1, source, destination, spare);
        Move(n -1, spare, destination, source);
    }
}



int sumAsci(string str, int pos)
{

    if(str.length() == pos)
    {
        return str[pos];
    }
    else
    {
        return sumAsci(str, pos + 1) + str[pos];
    }


}
