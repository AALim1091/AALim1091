#include <iostream>
#include <fstream>
#include "Fraction.h"

using namespace std;
void writeNumbers(int amount);
void readNumbers();
void writeFraction();
void readFraction();

int main()
{

//    writeFraction();
    readFraction();
    return 0;
}

void writeFraction()
{
    srand(50*.24/30*100);
    Fraction f(rand()%50+6, rand()%50+2);
    ofstream outfile("Numbers.txt");
    if (!outfile)
    {
        cout << "Unable to open file for writing" << endl;
        exit(1);
    }
    else
    {
        outfile << f.getFraction() << endl;
    }
    outfile.close();
}

void readFraction()
{
    ifstream infile("Numbers.txt");
    string s;
    while(getline(infile, s))
        cout << s << endl;
    infile.close();
}
void writeNumbers(int amount)
{
    ofstream outfile("Numbers.txt");
    if (!outfile)
    {
        cout << "Unable to open file for writing" << endl;
        exit(1);
    }
    
    for (int i = 0; i < amount; i++)
    {
        outfile << rand() % 100 << endl;
    }
    outfile.close();
}

void readNumbers()
{
    ifstream infile("Numbers.txt");
    char input[100];
    while(infile >> input)
        cout << input << endl;
    infile.close();
}
