#ifndef Fraction_h
#define Fraction_h
#include <string>
#include <istream>
#include <ostream>
using std::string;
using std::istream;
using std::ostream;

class Fraction
{
private:
    int *num;
    int *den;
public:
    void setFraction(int n, int d);
    Fraction add(const Fraction &f);
    Fraction sub(const Fraction &f);
    Fraction mul(const Fraction &f);
    Fraction div(const Fraction &f);
    void printFraction();
    int getNum() const;
    int getDen() const;
    string getFraction() const;
    
//    constructors
    Fraction();
    Fraction(int num, int den);
    Fraction(const Fraction &f);
    Fraction(string s);
    ~Fraction();
    
//    Operator Overloading
    Fraction operator + (const Fraction &f);
    Fraction operator - ( const Fraction &f);
    Fraction &operator = (const Fraction &f);
    Fraction operator * (const Fraction &f);
    Fraction operator / (const Fraction &f);
    
//    Friend
    friend istream &operator>> (istream &input, Fraction &f);
    friend ostream &operator<< (ostream &output, Fraction &f);
    
//    New Memory Allocation
    void create();
    
//    Static Variable
    static int counter;
    
};

#endif 
