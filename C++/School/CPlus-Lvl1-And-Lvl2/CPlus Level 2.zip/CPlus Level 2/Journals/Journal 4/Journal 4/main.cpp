#include <iostream>
#include "Fraction.h"
using namespace std;

int main()
{
    Fraction f1, f2(1,2), f3;
    
    cin >> f1;
    
    f3 = f1 + f2;
    
    cout << f3;
    
    return 0;
}

