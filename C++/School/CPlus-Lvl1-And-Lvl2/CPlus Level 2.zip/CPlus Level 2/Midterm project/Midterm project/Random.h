#ifndef Random_h
#define Random_h
#include <vector>
#include "Double.h"
#include "Integer.h"

using std::vector;


class Random
{
private:
    vector<double> vec;
    int nextVec;
    const int maxSize = 250;
    void fillVect(double min, double max);
    void shuffle();
    
public:
    //Constructors
    Random();
    Random(double min, double max);
    Random(Double min, Double max);
    Random(int seed);

    //Functions
    int nextInt();
    Integer nextInteger();
    double nextDbl();
    Double nextDouble();
    void setRange(double min, double max);
    void setRange(Double min, Double max);
    void shuffl();
};

#endif /* Random_h */
