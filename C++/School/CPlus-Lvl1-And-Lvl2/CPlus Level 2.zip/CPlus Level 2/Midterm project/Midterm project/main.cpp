#include "Double.h"
#include "Integer.h"
#include "Random.h"
#include <iostream>
using namespace std;

int main()
{
    Double one(0.0),two(20.0);
    Random r(one, two);
    for (int i = 0; i < 5; i++)
    {
        cout << r.nextInteger().toInt() <<endl;
    }
    Integer i = r.nextInteger();
    cout << endl<< i.toInt();
    return 0;
}
