#include "Random.h"
#include "Double.h"
#include "Integer.h"
#include <iostream>
#include <vector>
#include <ctime>
#include <algorithm>
#include <cstdlib>

using namespace std;

//Constructors
Random::Random()
{
    srand(static_cast<unsigned int>(time(0)));
    fillVect(0.0, RAND_MAX);

}
Random::Random(double min, double max)
{
    srand(static_cast<unsigned int>(time(0)));
    fillVect(min, max);
}
Random::Random(Double min, Double max)
{
    srand(static_cast<unsigned int>(time(0)));
    fillVect(min.toDouble(), max.toDouble());
}
Random::Random(int seed)
{
    srand(seed);
    fillVect(0.0, RAND_MAX);
}


//functions
void Random::fillVect(double min, double max)
{
    vec.clear();
    for(int i = 0; i < maxSize; i++)
        if(vec.size() < maxSize)
        vec.push_back((((double) rand() / (double) RAND_MAX) * (max - min)) + min ) ;
    this->shuffl();
}
void Random::shuffl()
{
    random_shuffle(this->vec.begin(), this->vec.end());
    this->nextVec = 0;
}
int Random::nextInt()
{
    if (nextVec > maxSize*(.90))
    {
        this->shuffl();
        return static_cast<int>(this->vec[nextVec++]);
    }
    
    return static_cast<int>(this->vec[nextVec++]);
}
Integer Random::nextInteger()
{
    Integer i;
    if (nextVec > maxSize*(.90))
    {
        this->shuffl();
        i.equals(static_cast<int>(this->vec[nextVec++]));
        return i;
    }
    i.equals(static_cast<int>(this->vec[nextVec++]));
    return i;
}
double Random::nextDbl()
{
    if (nextVec > maxSize*(.90))
    {
        this->shuffl();
        return this->vec[nextVec++];
    }
    
    return this->vec[nextVec++];
}
Double Random::nextDouble()
{
    Double d;
    if (nextVec > maxSize*(.90))
    {
        this->shuffl();
        d.equals(this->vec[nextVec++]);
        return d;
    }
    d.equals(this->vec[nextVec++]);
    return d;
}
void Random::setRange(double min, double max)
{
    fillVect(min, max);
    this->shuffl();
}
void Random::setRange(Double min, Double max)
{
    fillVect(min.toDouble(), max.toDouble());
    this->shuffl();
}
