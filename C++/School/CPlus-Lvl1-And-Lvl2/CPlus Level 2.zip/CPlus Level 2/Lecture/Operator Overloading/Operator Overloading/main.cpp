#include <iostream>
#include "Character.h"

using namespace std;

int main()
{
    Character c('A');
    Character c2 = c;
    Character c3 = 'D';
    c3 += 2;
    
    
    cout <<  c2.toHex() << endl;
    cout << c3.toInt() << endl;
    cout << c3.toChar() << endl;
    
    if (c2 == c3)
        cout << "They are equeal"<< endl;
    else
        cout << "Not equeal"<< endl;

    return 0;
}
