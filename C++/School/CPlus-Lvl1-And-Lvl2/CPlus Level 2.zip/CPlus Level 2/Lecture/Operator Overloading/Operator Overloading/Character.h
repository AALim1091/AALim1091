#ifndef Character_h
#define Character_h
#include <string>
#include <stdio.h>
using std::string;

class Character
{
private:
    char ch;
public:
    Character();
    Character(char aChar);
    Character(const Character &ch);
//    mutator
    void setChar(char c);
//    accessor
    char toChar() const;
    string toString() const;
    string toHexString() const;
    int toHex() const;
    int toInt() const;
    Character &operator=(const Character &ch);
    Character &operator=(char ch);
    Character &operator += (int i);
    bool operator == (const Character &ch);
    bool operator == (char ch);
    bool operator != (const Character &ch);
    bool operator != (char ch);
};

#endif /* Character_hpp */
