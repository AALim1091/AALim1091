#include "Character.h"
#include <string>
#include <iostream>
#include <sstream>

using namespace std;

Character::Character()
{
    this->setChar(' ');
}

Character::Character(char aChar)
{
    this->setChar(aChar);
}

Character::Character(const Character &ch)
{
    this->setChar(ch.toChar());
}

void Character::setChar(char ch)
{
    this->ch = ch;
}


char Character::toChar() const
{
    return this->ch;
}
string Character::toString() const
{
    string st;
    st += this->ch;
    return st;
}
string Character::toHexString() const
{
    stringstream ss;
    ss << hex << static_cast<int>(this->ch);
    return ss.str();
}
int Character::toHex() const
{
    return stod(this->toHexString());
}
int Character::toInt() const
{
    return static_cast<int>(this->ch);
}
Character &Character::operator=(const Character &ch)
{
    this->setChar(ch.toChar());
    return *this;
}
Character &Character::operator=(char ch)
{
    this->setChar(ch);
    return *this;
}
Character &Character::operator += (int i)
{
    this->ch+= i;
    return *this;
}
bool Character::operator == (const Character &ch)
{
    return this->toChar() == ch.toChar();
}
bool Character::operator == (char ch)
{
    return this->toChar() == ch;
}
bool Character::operator != (const Character &ch)
{
    return this->toChar() != ch.toChar();
}
bool Character::operator != (char ch)
{
    return this->toChar() != ch;
}






