#include <iostream>
#include "Stack.h"
using namespace std;


int main()
{
    Stack x;
    x.push(1);
    x.push(2);
    x.push(3);
    
    
    
    return 0;
}
