//
//  Stack.h
//  stack
//
//  Created by Julio Lopez on 4/11/17.
//  Copyright © 2017 Julio Lopez. All rights reserved.
//

#ifndef Stack_h
#define Stack_h
#include <vector>
using std::vector;

class Stack
{
private:
    vector<int>::iterator pEnd;
    vector<int>v;
    int getElement(bool erase);
public:
    Stack();
    int pop();
    int peek();
    void push(int elem);
    
    
};

#endif /* Stack_h */
