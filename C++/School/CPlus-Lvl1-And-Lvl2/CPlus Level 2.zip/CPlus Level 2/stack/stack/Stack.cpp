#include <iostream>
#include <vector>
#include "Stack.h"

using namespace std;

Stack::Stack()
{
    
}
void Stack::push(int elem)
{
    v.push_back(elem);
}
int Stack::peek()
{
    return this->getElement(false);
}
int Stack::getElement(bool erase)
{
    pEnd = v.end() - 1;
    int tmp = 0;
    if (v.size() > 0)
    {
        tmp =*pEnd;
        if(erase)
            v.erase(pEnd);
    }
    return tmp;
}
