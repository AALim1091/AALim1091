/*
 Julio
 Lopez
 ID: 0338770
 4/29/17
 Assignment 8
 Due: 4/30/17 by 11:59pm
 This assignment is about namespaces and singelton
 */

#ifndef menu_h
#define menu_h
#include <string>
#include <vector>

using std::string;
using std::vector;

namespace julio
{
    const int MAXCOUNT = 20;
    
    struct menuItem
    {
        void (*func)();
        string descript;
    };
    
    class Menu
    {
    private:
        vector<menuItem> mi;
        int count;
        void runSelection();
        static Menu *pInstance;
        
    public:
        Menu();
        void addMenu(string Description, void (*f)());
        void runMenu();
        void waitKey();
        static Menu *Instace();
        
    };
}



#endif 
