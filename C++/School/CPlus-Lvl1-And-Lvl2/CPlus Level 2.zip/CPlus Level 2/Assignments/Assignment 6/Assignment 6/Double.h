/*
 Julio
 Lopez
 ID: 0338770
 4/20/17
 Assignment 6
 Due: 4/30/17 by 11:59pm
 This is assignment is about converting string to values and values to strings
 */
#ifndef Double_h
#define Double_h
#include "Integer.h"
#include <string>
using std::string;

class Double
{
private:
    double d;
    bool isNaN = false;
    bool isNAN(string str);
    
public:
    Double();
    Double(const Double &aDub);
    Double(double d);
    Double(Integer &i);
    Double(string str);
    
    Double &equals(const Double &aDub);
    void equals (double aDub);
    void equals (string str);
    Double add(const Double &aDub);
    Double add(double aDub);
    Double sub(const Double &aDub);
    Double sub(const double aDub);
    Double mul(const Double &aDub);
    Double mul(const double aDub);
    Double div(const Double &aDub);
    Double div(const double aDub);
    double toDouble() const;
    string toString() const;
    bool isNan() const;
    
    Double operator + (const Double &d);
    Double operator - ( const Double &d);
    Double operator * (const Double &d);
    Double operator / (const Double &d);
    Double &operator = (const Double &d);
    Double &operator = (double d);
    Double &operator = (string str);
    bool operator == (const Double &d);
    bool operator != (const Double &f);
    bool operator == (double d);
    bool operator != (double d);
    
};


#endif


