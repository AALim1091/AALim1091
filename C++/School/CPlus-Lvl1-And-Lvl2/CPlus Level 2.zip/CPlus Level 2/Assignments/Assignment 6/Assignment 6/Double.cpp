/*
 Julio
 Lopez
 ID: 0338770
 4/20/17
 Assignment 6
 Due: 4/30/17 by 11:59pm
 This is assignment is about converting string to values and values to strings
 */
#include "Double.h"
#include "Integer.h"
#include <iostream>
#include <string>
#include <sstream>

using namespace std;

//Constructors
Double::Double()
{
    this->equals(0.0);
}
Double::Double(const Double &aDub)
{
    this->equals(aDub.toDouble());
}
Double::Double(double aDub)
{
    this->equals(aDub);
}
Double::Double(Integer &anInt)
{
    this->equals(anInt.toInt());
}
Double::Double(string str)
{
    this->equals(str);
}

//Functions
bool Double::isNan() const
{
    return this->isNaN;
}
bool Double::isNAN(string str)
{
    int decCount=0;
    for(int i = 0; i < str.length(); i++)
    {
        if (str.at(i) == '.')
            decCount++; //keeps track of decimal points
        if (!isdigit(str.at(i)) && str.at(i) != '.')
            this->isNaN = true;
        if (decCount > 1)
            this->isNaN = true;
    }
    return this->isNaN;
}
void Double::equals(double aDub)
{
    this->d = aDub;
    this->isNaN = false;
}
void Double::equals(string str)
{
    this->isNAN(str);
    if (!isNaN)
        this->d = stod(str);
    else if(isNaN)
    {
        this->d = 0.0;
        cout << "Cannot assign a non-number to class Double" << endl;
    }
}
Double &Double::equals(const Double &aDub)
{
    this->equals(aDub.toDouble());
    return *this;
}
Double Double::add(const Double &aDub)
{
    return this->toDouble() + aDub.d;
}
Double Double::add(double aDub)
{
    return this->toDouble() + aDub;
}

Double Double::sub(const Double &aDub)
{
    return this->toDouble() - aDub.d;
}
Double Double::sub(const double aDub)
{
    return this->toDouble() - aDub;
}

Double Double::mul(const Double &aDub)
{
    return this->d * aDub.d;
}
Double Double::mul(const double aDub)
{
    return this->d * aDub;
}

Double Double::div(const Double &aDub)
{
    return this->d / aDub.d;
}
Double Double::div(const double aDub)
{
    return this->d / aDub;
}

double Double::toDouble() const
{
    double t = d;
    return t;
}
string Double::toString() const
{
    stringstream ss;
    ss << this->d;
    return ss.str();
}

//operators
Double Double::operator+(const Double &d)
{
    return this->add(d);
}
Double Double::operator-(const Double &d)
{
    return this->sub(d);
}
Double Double::operator*(const Double &d)
{
    return this->mul(d);
}
Double Double::operator/(const Double &d)
{
    return this->div(d);
}
Double &Double::operator=(const Double &d)
{
    return this->equals(d);
}
Double &Double::operator=(double d)
{
    this->equals(d);
    return *this;
}
Double &Double::operator=(string str)
{
    this->equals(str);
    return *this;
}
bool Double::operator==(const Double &d)
{
    return this->toDouble() == d.toDouble();
}
bool Double::operator==(double d)
{
    return this->toDouble() == d;
}
bool Double::operator!=(const Double &d)
{
    return this->toDouble() != d.toDouble();
}
bool Double::operator!=(double d)
{
    return this->toDouble() != d;
}




















