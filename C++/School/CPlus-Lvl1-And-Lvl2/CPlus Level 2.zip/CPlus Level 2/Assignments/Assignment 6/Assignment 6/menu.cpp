/*
 Julio
 Lopez
 ID: 0338770
 4/20/17
 Assignment 6
 Due: 4/30/17 by 11:59pm
 This is assignment is about converting string to values and values to strings
 */
#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include "menu.h"
using namespace std;


Menu::Menu()
: count(0)
{
    
}
void Menu::addMenu(string Description, void (*f)(void))
{
    if(count < MAXCOUNT)
    {
        menuItem tmp;  //= {Description, f} ;
       this->mi.push_back(tmp);
        this->mi[count].func = f;
        this->mi[count].descript = Description.data();
        count++;
    }
}

void Menu::runMenu()
{
    for(;;)
    {
        //system("CLS");
        for (int i = 0; i < count; i++)
        {
            cout << this->mi[i].descript << endl;
        }
        this->runSelection();
    }
}
void Menu::runSelection()
{
    int select;
    
    cin >> select;
    if(select <= count)
        this->mi[select - 1].func();
}
void Menu::waitKey()
{
    getchar();
}
