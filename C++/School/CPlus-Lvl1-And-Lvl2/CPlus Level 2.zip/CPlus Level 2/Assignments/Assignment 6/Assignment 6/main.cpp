/*
 Julio
 Lopez
 ID: 0338770
 4/20/17
 Assignment 6
 Due: 4/30/17 by 11:59pm
 This is assignment is about converting string to values and values to strings
 */
#include <iostream>
#include "Double.h"
#include "Integer.h"
using namespace std;

int main() {
    
    Double d, dd{"5.5"};
    Integer i, ii{"100"};
    
    string str{"12.34"}, str2, str3;
    
    d= str;
    i.equals("9876") ;
    str3 = d.toString();
    str2 = ii.toString();
    
    cout << d.toDouble() << endl;
    cout << dd.toDouble() << endl;
    cout << i.toInt() << endl;
    cout << ii.toInt() << endl;
    cout << str3 << endl;
    cout << str2 << endl;
    
    return 0;
}
