/*
 Julio
 Lopez
 ID: 0338770
 5/12/17
 Assignment 11
 Due: 5/14/17 by 11:59pm
 This is assignment is about inheretance
 */
#ifndef Number_hpp
#define Number_hpp
#include <string>
using std::string;

class Number:protected string
{
public:
    Number();
    Number(string str);
    
    
};

#endif /* Number_hpp */
