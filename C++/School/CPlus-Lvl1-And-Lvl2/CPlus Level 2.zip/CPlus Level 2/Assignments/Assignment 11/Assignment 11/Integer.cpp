/*
 Julio
 Lopez
 ID: 0338770
 5/12/17
 Assignment 11
 Due: 5/14/17 by 11:59pm
 This is assignment is about inheretance
 */
#include "Integer.h"
#include <iostream>
#include <string>
#include <sstream>

using namespace std;

    //Constructors
Integer::Integer()
{
    this->equals("0");
}
Integer::Integer(const Integer &anInt)
{
    this->equals(anInt.toInt());
}
Integer::Integer(int anInt)
{
    this->equals(anInt);
}
Integer::Integer(string str)
{
    this->equals(str);
}

//Functions

bool Integer::isNAN(string str)
{
    for(int i = 0; i < str.length(); i++)
    {
        if (!isdigit(str.at(i)) || str.at(i) == '.')
            this->isNaN = true;
    }
    return isNaN;
}
bool Integer::getNaN() const
{
    return isNaN;
}
void Integer::equals(int i)
{
    stringstream ss;
    ss << i;
    this->equals(ss.str());
}
void Integer::equals(string str)
{
    this->isNAN(str);
    if (!isNaN)
        this->assign(str);
}
Integer &Integer::equals(const Integer &i)
{
    this->equals(i.toInt());
    return *this;
}

Integer Integer::add(const Integer &i)
{
    Integer tmp = this->toInt() + i.toInt();
    return tmp;
}
Integer Integer::add(const int i)
{
    Integer tmp = this->toInt() + i;
    return tmp;
}

Integer Integer::sub(const Integer &i)
{
    Integer tmp = this->toInt() - i.toInt();
    return tmp;
}
Integer Integer::sub(const int i)
{
    return this->toInt() - i;
}

Integer Integer::mul(const Integer &i)
{
    Integer tmp = this->toInt() * i.toInt();
    return tmp;
}
Integer Integer::mul(const int i)
{
    Integer tmp = this->toInt() * i;
    return tmp;
}

Integer Integer::div(const Integer &i)
{
    Integer tmp = this->toInt() / i.toInt();
    return tmp;
}
Integer Integer::div(const int i)
{
    Integer tmp = this->toInt() / i;
    return tmp;
}
int Integer::toInt() const
{
    return stoi(*this);
}
string Integer::toString() const
{
    stringstream ss;
    ss << this->toInt();
    return ss.str();
}

//operators overloa
Integer Integer::operator+(const Integer &i)
{
    return this->add(i);
}
Integer Integer::operator-(const Integer &i)
{
    return this->sub(i);
}
Integer Integer::operator*(const Integer &i)
{
    return this->mul(i);
}
Integer Integer::operator/(const Integer &i)
{
    return this->div(i);
}
Integer &Integer::operator=(const Integer &i)
{
    return this->equals(i);
}
Integer &Integer::operator=(int i)
{
    this->equals(i);
    return *this;
}
Integer &Integer::operator=(string str)
{
    this->equals(str);
    return *this;
}
bool Integer::operator==(const Integer &i)
{
    return this->toInt() == i.toInt();
}
bool Integer::operator==(int i)
{
    return this->toInt() == i;
}
bool Integer::operator!=(const Integer &i)
{
    return this->toInt() != i.toInt();
}
bool Integer::operator!=(int i)
{
    return this->toInt() != i;
}


