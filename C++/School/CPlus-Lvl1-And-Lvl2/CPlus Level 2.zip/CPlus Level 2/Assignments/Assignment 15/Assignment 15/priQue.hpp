/*
 Julio
 Lopez
 ID: 0338770
 5/18/17
 Assignment 15
 Due: 5/21/17 by 11:59pm
 This is assignment is about tamplates
 */
#ifndef priQue_hpp
#define priQue_hpp

#include "Node.hpp"
#include <iostream>
#include <vector>
#include <algorithm>
using std::vector;
using std::cout;
using std::endl;
using std::sort;

template <class T>
class priQue
{
private:
    vector<Node<T>> data;
    void sortVec();
public:
    void enqueue(Node<T> node);
    void dequeue();
    T peek();
    int sizeOf();
    void printQue();
};

template <class T>
void priQue<T>::enqueue(Node<T> node)
{
    this->data.push_back(node);
    sortVec();
}

template <class T>
void priQue<T>::sortVec()
{
    
    sort( data.begin( ), data.end( ), [ ]( const Node<T>& lhs, const Node<T>& rhs )
    {
        return lhs.getPri() < rhs.getPri();
    });
}

template <class T>
void priQue<T>::dequeue()
{
    data.pop_back();
}
                        
                        
template <class T>
T priQue<T>::peek()
{
    Node <T> n = data.back();
    return n.getData();
    
}

template <class T>
int priQue<T>::sizeOf()
{
    return static_cast<int>(data.size());
}
template <class T>
void priQue<T>::printQue()
{
    for( int i = data.size() -1 ; i >= 0 ; i--)
    {
        cout << data[i].getPri() << " " <<data[i].getData() << endl;
    }
}


#endif /* priQue_hpp */
