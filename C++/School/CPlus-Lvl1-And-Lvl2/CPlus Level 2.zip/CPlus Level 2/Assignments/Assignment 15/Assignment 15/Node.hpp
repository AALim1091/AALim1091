/*
 Julio
 Lopez
 ID: 0338770
 5/18/17
 Assignment 15
 Due: 5/21/17 by 11:59pm
 This is assignment is about tamplates
 */
#ifndef Node_hpp
#define Node_hpp

template <class T>
class Node
{
private:
    int priority;
    T data;
    
public:
    Node();
    Node(int pri,T data);
    void setNode(int pri,T data);
    int getPri() const;
    T getData() const;
};

template <class T>
Node<T>::Node()
{
    
}
template <class T>
Node<T>::Node(int pri,T data)
{
    setNode(pri, data);
}
template <class T>
void Node<T>::setNode(int pri,T data)
{
    this->priority = pri;
    this->data = data;
}

template <class T>
int Node<T>::getPri() const
{
    return this->priority;
}
template <class T>
T Node<T>::getData() const
{
    return this->data;
}

#endif /* Node_hpp */
