/*
 Julio
 Lopez
 ID: 0338770
 5/18/17
 Assignment 15
 Due: 5/21/17 by 11:59pm
 This is assignment is about tamplates
 */

#include <iostream>
#include "Node.hpp"
#include "priQue.hpp"
using namespace std;

int main() {
    
    Node<string> n1, n2, n3 ,n4;
    n1.setNode(5, "IM");
    n2.setNode(9,"Hello");
    n3.setNode(8,"World");
    n4.setNode(2,"Awake");
    
    priQue<string> p;
    p.enqueue(n1);
    p.enqueue(n2);
    p.enqueue(n3);
    p.enqueue(n4);
    

    p.printQue();
    
    cout<< p.sizeOf();

    return 0;
}
