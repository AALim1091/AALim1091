/*
 Julio
 Lopez
 ID: 0338770
 5/06/17
 Assignment 9
 Due: 5/07/17 by 11:59pm
 This assignment is about File IO
 */

#include <iostream>
#include <fstream>
#include <vector>
#include "Double.h"
#include "Integer.h"
using namespace std;

vector<Double*> dNumbers;
vector<Integer*> iNumbers;

void readNumbers();
void writeNumbers(const vector<Integer*> &iN);
void writeNumbers(const vector<Double*> &dN);


int main()
{

    readNumbers();
    writeNumbers(iNumbers);
    writeNumbers(dNumbers);
    
    
    return 0;
}

void readNumbers()
{
    ifstream textLine("Numbers.txt");
    if (!textLine)
    {
        cout<< "Unable to open file for reading txt" << endl;
    }
    else{
        
    string str;
    while(textLine >> str) //another way of getting text instead of getline
    {
        Integer iTest(str);
        Double dTest(str);
        if(!iTest.getNaN())
        {
            iNumbers.push_back(new Integer(str));
        }
        else if (!dTest.getNaN())
        {
            dNumbers.push_back(new Double(str));
        }

    }
        }
    textLine.close();
    
}
void writeNumbers(const vector<Integer*> &iN)
{
    ofstream intsOut("Integer.txt");
    if(!intsOut)
    {
        cout << "unable to open Integer.txt"<< endl;
    }
    else
    {
        for(int i = 0; i < iN.size() ; i++)
        {
            intsOut << iN[i]->toString() << endl; //access pointer content of a complex type object and use its functions. see next function for other way
        }
    }
    intsOut.close();

}
void writeNumbers(const vector<Double*> &dN)
{
    ofstream doublesOut("Double.txt");
    if(!doublesOut)
    {
        cout << "unable to open Double.txt"<< endl;
    }
    else
    {
        for(int i = 0; i < dN.size() ; i++)
        {
            Double tmp = *dN[i];
            doublesOut << tmp.toString() << endl;// Other way to access objects in a pointer vector.
        }
        
    }
    doublesOut.close();
    
}

