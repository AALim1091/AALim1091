/*
 Julio
 Lopez
 ID: 0338770
 5/06/17
 Assignment 9
 Due: 5/07/17 by 11:59pm
 This assignment is about File IO
 */
#include "Double.h"
#include "Integer.h"
#include <iostream>
#include <string>
#include <sstream>

using namespace std;


    
Double::Double()
{
        this->create();
        this->equals(0.0);
}
Double::Double(const Double &aDub)
{
    this->create();
    this->equals(aDub.toDouble());
}
Double::Double(double aDub)
{
    this->create();
    this->equals(aDub);
}
Double::Double(Integer &anInt)
{
    this->create();
    this->equals(anInt.toInt());
}
Double::Double(string str)
{
    this->create();
    this->equals(str);
}

//Functions
void Double::create()
{
    this->d = new double;
}
bool Double::isNAN(string str)
{
    this->isNaN = this->recNan(str, 0);
//    int decCount=0;
//    for(int i = 0; i < str.length(); i++)
//    {
//        if (str.at(i) == '.')
//            decCount++; //keeps track of decimal points
//        if (!isdigit(str.at(i)) && str.at(i) != '.')
//            this->isNaN = true;
//        if (decCount > 1)
//            this->isNaN = true;
//    }
        return this->isNaN;
}
bool Double::getNaN() const
{
    return isNaN;
}
void Double::equals(double aDub)
{
    *this->d = aDub;
}
void Double::equals(string str)
{
    this->isNAN(str);
    if (!isNaN)
        *this->d = stod(str);
}
Double &Double::equals(const Double &aDub)
{
    this->equals(aDub.toDouble());
    return *this;
}
Double Double::add(const Double &aDub)
{
    return this->toDouble() + *aDub.d;
}
Double Double::add(double aDub)
{
    return this->toDouble() + aDub;
}
    
Double Double::sub(const Double &aDub)
{
    return this->toDouble() - *aDub.d;
}
Double Double::sub(const double aDub)
{
    return this->toDouble() - aDub;
}
    
Double Double::mul(const Double &aDub)
{
    return this->toDouble() * *aDub.d;
}
Double Double::mul(const double aDub)
{
    return this->toDouble() * aDub;
}
    
Double Double::div(const Double &aDub)
{
    return this->toDouble() / *aDub.d;
}
Double Double::div(const double aDub)
{
    return this->toDouble() / aDub;
}
    
double Double::toDouble() const
{
    return *this->d;
}
string Double::toString() const
{
    stringstream ss;
    ss << this->toDouble();
    return ss.str();
}
bool Double::recNan(string s, int dCount)
{
    if (s.empty())
        return false;
    else if(s[0] == '.')
    {
        if (++dCount >1)
        {
            return true;
        }
    }
    else if (!isdigit(s[0]))
    {
        return true;
    }
    return recNan(s.substr(1,s.length()), dCount);
}

    //operators
    Double Double::operator+(const Double &d)
    {
        return this->add(d);
    }
    Double Double::operator-(const Double &d)
    {
        return this->sub(d);
    }
    Double Double::operator*(const Double &d)
    {
        return this->mul(d);
    }
    Double Double::operator/(const Double &d)
    {
        return this->div(d);
    }
    Double &Double::operator=(const Double &d)
    {
        return this->equals(d);
    }
    Double &Double::operator=(double d)
    {
        this->equals(d);
        return *this;
    }
    Double &Double::operator=(string str)
    {
        this->equals(str);
        return *this;
    }
    bool Double::operator==(const Double &d)
    {
        return this->toDouble() == d.toDouble();
    }
    bool Double::operator==(double d)
    {
        return this->toDouble() == d;
    }
    bool Double::operator!=(const Double &d)
    {
        return this->toDouble() != d.toDouble();
    }
    bool Double::operator!=(double d)
    {
        return this->toDouble() != d;
    }
    
