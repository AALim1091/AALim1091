/*
 Julio
 Lopez
 ID: 0338770
 5/06/17
 Assignment 9
 Due: 5/07/17 by 11:59pm
 This assignment is about File IO
 */
#include "Integer.h"
#include <iostream>
#include <string>
#include <sstream>

using namespace std;

    //Constructors
Integer::Integer()
{
    this->create();
    this->equals(0);
}
Integer::Integer(const Integer &anInt)
{
    this->create();
    this->equals(anInt.toInt());
}
Integer::Integer(const int anInt)
{
    this->create();
    this->equals(anInt);
}
Integer::Integer(string str)
{
    this->create();
    this->equals(str);
}

//Functions
void Integer::create()
{
    this->val = new int;
}
bool Integer::isNAN(string str)
{
    for(int i = 0; i < str.length(); i++)
    {
        if (!isdigit(str.at(i)) || str.at(i) == '.')
            this->isNaN = true;
    }
    return isNaN;
}
bool Integer::getNaN() const
{
    return isNaN;
}
void Integer::equals(int anInt)
{
    *this->val = anInt;
}
void Integer::equals(string str)
{
    this->isNAN(str);
    if (!isNaN)
        *this->val = stoi(str);
}
Integer &Integer::equals(const Integer &i)
{
    this->equals(i.toInt());
    return *this;
}

Integer Integer::add(const Integer &anInt)
{
    return this->toInt() + *anInt.val;
}
Integer Integer::add(const int anInt)
{
    return this->toInt() + anInt;
}

Integer Integer::sub(const Integer &anInt)
{
    return this->toInt() - *anInt.val;
}
Integer Integer::sub(const int anInt)
{
    return this->toInt() - anInt;
}

Integer Integer::mul(const Integer &anInt)
{
    return this->toInt() * *anInt.val;
}
Integer Integer::mul(const int anInt)
{
    return this->toInt() * anInt;
}

Integer Integer::div(const Integer &anInt)
{
    return this->toInt() / *anInt.val;
}
Integer Integer::div(const int anInt)
{
    return this->toInt() / anInt;
}
int Integer::toInt() const
{
    return *this->val;
}
string Integer::toString() const
{
    stringstream ss;
    ss << *this->val;
    return ss.str();
}

//operators overloa
Integer Integer::operator+(const Integer &i)
{
    return this->add(i);
}
Integer Integer::operator-(const Integer &i)
{
    return this->sub(i);
}
Integer Integer::operator*(const Integer &i)
{
    return this->mul(i);
}
Integer Integer::operator/(const Integer &i)
{
    return this->div(i);
}
Integer &Integer::operator=(const Integer &i)
{
    return this->equals(i);
}
Integer &Integer::operator=(int i)
{
    this->equals(i);
    return *this;
}
Integer &Integer::operator=(string str)
{
    this->equals(str);
    return *this;
}
bool Integer::operator==(const Integer &i)
{
    return this->toInt() == i.toInt();
}
bool Integer::operator==(int i)
{
    return this->toInt() == i;
}
bool Integer::operator!=(const Integer &i)
{
    return this->toInt() != i.toInt();
}
bool Integer::operator!=(int i)
{
    return this->toInt() != i;
}


