/*
 Julio
 Lopez
 ID: 0338770
 5/18/17
 Assignment 14
 Due: 5/21/17 by 11:59pm
 This is assignment is about tamplates
 */
#ifndef Stack_h
#define Stack_h
#include <vector>
using std::vector;

template <class T>
class Stack:public vector<T>
{
public:
    void push(T data);
    T pop();
    T peek() const;
};

template <class T>
void Stack<T>::push(T data)
{
    this->push_back(data);
}

template <class T>
T Stack<T>::pop()
{
    T temp = this->back();
    this->pop_back();
    return temp;
}

template <class T>
T Stack<T>::peek() const
{
    return this->back();
}

#endif
