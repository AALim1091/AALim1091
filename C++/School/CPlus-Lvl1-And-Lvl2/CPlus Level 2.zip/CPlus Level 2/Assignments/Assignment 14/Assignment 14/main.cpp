/*
 Julio
 Lopez
 ID: 0338770
 5/18/17
 Assignment 14
 Due: 5/21/17 by 11:59pm
 This is assignment is about tamplates
 */
#include "Stack.h"
#include <iostream>
using namespace std;

int main() {
    Stack<int> ch;
    ch.push(1);
    ch.push(2);
    ch.push(3);
    
    cout<< ch.peek() <<endl;
    cout<< ch.pop() <<endl;
    cout<< ch.pop() <<endl;
    cout<< ch.pop() <<endl;
    
    return 0;
}
