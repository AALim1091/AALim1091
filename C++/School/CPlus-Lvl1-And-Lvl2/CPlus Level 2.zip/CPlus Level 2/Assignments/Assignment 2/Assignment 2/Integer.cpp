/*
 Julio
 Lopez
 ID: 0338770
 4/7/17
 Assignment 3
 Due: 4/9/17 by 11:59pm
 This is assignment challenges us to create overloaded constructors
 */
#include "Integer.h"

void Integer::equals(int anInt)
{
    val = anInt;
}

Integer Integer::add(const Integer &anInt)
{
    Integer t;
    t.val = val + anInt.val;
    return t;
}

Integer Integer::sub(const Integer &anInt)
{
    Integer t;
    t.val = val - anInt.val;
    return t;
}

Integer Integer::mul(const Integer &anInt)
{
    Integer t;
    t.val = val * anInt.val;
    return t;
}

Integer Integer::div(const Integer &anInt)
{
    Integer t;
    t.val = val / anInt.val;
    return t;
}

int Integer::toInt()
{
    int t;
    t = val;
    return t;
}
