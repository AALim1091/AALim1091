/*
 Julio
 Lopez
 ID: 0338770
 4/7/17
 Assignment 3
 Due: 4/9/17 by 11:59pm
 This is assignment challenges us to create overloaded constructors
 */
#include "Double.h"

Double::Double();
{
    
}
void Double::equals(const double aDub)
{
    d = aDub;
}

Double Double::add(const Double &aDub)
{
    Double t;
    t.d = d - aDub.d;
    return t;
}

Double Double::sub(const Double &aDub)
{
    Double t;
    t.d = d - aDub.d;
    return t;
}

Double Double::mul(const Double &aDub)
{
    Double t;
    t.d = d * aDub.d;
    return t;
}

Double Double::div(const Double &aDub)
{
    Double t;
    t.d = d / aDub.d;
    return t;
}

double Double::toDouble()
{
    double t = d;
    return t;
}
