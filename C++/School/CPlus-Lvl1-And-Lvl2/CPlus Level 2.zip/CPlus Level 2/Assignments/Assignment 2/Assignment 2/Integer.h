/*
 Julio
 Lopez
 ID: 0338770
 4/7/17
 Assignment 3
 Due: 4/9/17 by 11:59pm
 This is assignment challenges us to create overloaded constructors
 */
#ifndef Integer_h
#define Integer_h

class Integer
{
private:
    int val;
    
public:
    void equals(int anInt);
    Integer add(const Integer &anInt);
    Integer sub(const Integer &anInt);
    Integer mul(const Integer &anInt);
    Integer div(const Integer &anInt);
    int toInt();
    
};

#endif 
