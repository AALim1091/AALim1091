/*
 Julio
 Lopez
 ID: 0338770
 5/12/17
 Assignment 1
 Due: 5/14/17 by 11:59pm
 This is assignment is about inheretance
 */
#include "Number.h"

Number::Number()
{
    this->assign("0.0");
}
Number::Number(string str)
{
    this->assign(str);
}

const string Number::toString() 
{
    string str = *this;
    return str;
}

bool Number::isNaN(string str)
{
    this->isNAN = this->recNan(str, 0);
    return this->isNAN;
}

