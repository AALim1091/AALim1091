/*
 Julio
 Lopez
 ID: 0338770
 5/12/17
 Assignment 1
 Due: 5/14/17 by 11:59pm
 This is assignment is about inheretance
 */
#ifndef Number_hpp
#define Number_hpp
#include <string>
using std::string;

class Number:public string
{
    
public:
    bool isNAN = false;
    Number();
    Number(string str);
    virtual const string toString();
    virtual bool isNaN(string str);
    virtual bool recNan(string str, int i) = 0;

};

#endif /* Number_hpp */
