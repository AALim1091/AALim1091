/*
 Julio
 Lopez
 ID: 0338770
 5/12/17
 Assignment 1
 Due: 5/14/17 by 11:59pm
 This is assignment is about inheretance
 */
#ifndef Integer_h
#define Integer_h
#include <string>
#include "Number.h"
using std::string;

class Integer:public Number
    {
    private:
        bool isNaN = false;
        bool isNAN(string str);
        bool recNan(string str);
        
    public:
        Integer();
        Integer(const Integer &anInt);
        Integer(int anInt);
        Integer(string str);
        
        
        void equals(int anInt);
        void equals(string str);
        Integer &equals(const Integer &i);
        Integer add(const Integer &anInt);
        Integer add(const int anInt);
        Integer sub(const Integer &anInt);
        Integer sub(const int anInt);
        Integer mul(const Integer &anInt);
        Integer mul(const int anInt);
        Integer div(const Integer &anInt);
        Integer div(const int anInt);
        int toInt() const;
        bool getNaN() const;

        
        
        Integer operator + (const Integer &i);
        Integer operator - (const Integer &i);
        Integer operator * (const Integer &i);
        Integer operator / (const Integer &i);
        Integer &operator = (const Integer &i);
        Integer &operator = (int i);
        Integer &operator = (string str);
        bool operator == (const Integer &i);
        bool operator != (const Integer &i);
        bool operator == (int i);
        bool operator != (int i);
    };



#endif 
