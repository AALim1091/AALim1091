//
//  main.cpp
//  Assignment 14.1
//
//  Created by Julio Lopez on 5/18/17.
//  Copyright © 2017 Julio Lopez. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
