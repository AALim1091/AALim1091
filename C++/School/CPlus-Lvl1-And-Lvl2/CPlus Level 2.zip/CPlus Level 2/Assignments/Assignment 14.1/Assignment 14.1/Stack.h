#ifndef Stack_h
#define Stack_h
#include <vector>
using std::vector;

template <class T>
class Stack:public vector
{
public:
    void push(T data);
    T pop();
    T peek() const;
};

template <class T>
void Stack<T>::push(T data)
{
    this->push(data);
}
template <class T>
void Stack<T>::push(T data)
{
    
}


#endif
