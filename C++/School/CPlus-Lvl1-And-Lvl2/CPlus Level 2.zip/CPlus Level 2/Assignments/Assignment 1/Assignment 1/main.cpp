#include <iostream>
#include <cstdlib>
#include "menu.h"
using namespace std;

Menu m;

void func1();
void func2();
void func3();
void Exit();

int main()
{
    m.addMenu("1. Function1", func1);
    m.addMenu("2. Function2", func2);
    m.addMenu("3. Function3", func3);
    m.addMenu("4. Exit ", Exit);
    
    m.runMenu();
    
    return 0;
}

void func1()
{
    cout << "hello from function 1" << endl;
    m.waitKey();
}
void func2()
{
    cout << "hello from function 2" << endl;
    m.waitKey();
}
void func3()
{
    cout << "hello from function 3" << endl;
    m.waitKey();
}
void Exit()
{
    cout << "GoodBye" << endl;
    exit(0);
}

