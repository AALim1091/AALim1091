/*
 Julio
 Lopez
 ID: 0338770
 4/21/17
 Assignment 7
 Due: 4/23/17 by 11:59pm
 This is assignment is about Dynamic Memory
 */
#ifndef Integer_h
#define Integer_h
#include <string>
using std::string;

class Integer
{
private:
    int *val;
    bool isNaN = false;
    bool isNAN(string str);
    
public:
    Integer();
    Integer(const Integer &anInt);
    Integer(const int anInt);
    Integer(string str);
    
    void create();
    void equals(int anInt);
    void equals(string str);
    Integer &equals(const Integer &i);
    Integer add(const Integer &anInt);
    Integer add(const int anInt);
    Integer sub(const Integer &anInt);
    Integer sub(const int anInt);
    Integer mul(const Integer &anInt);
    Integer mul(const int anInt);
    Integer div(const Integer &anInt);
    Integer div(const int anInt);
    int toInt() const;
    string toString() const;
    
    
    Integer operator + (const Integer &i);
    Integer operator - (const Integer &i);
    Integer operator * (const Integer &i);
    Integer operator / (const Integer &i);
    Integer &operator = (const Integer &i);
    Integer &operator = (int i);
    Integer &operator = (string str);
    bool operator == (const Integer &i);
    bool operator != (const Integer &i);
    bool operator == (int i);
    bool operator != (int i);
};

#endif 
