/*
 Julio
 Lopez
 ID: 0338770
 4/13/17
 Assignment 4
 Due: 4/16/17 by 11:59pm
 This is assignment is about changing from array to vector and testing our Integer and Double classes
 */
#ifndef Double_h
#define Double_h
#include "Integer.h"

class Double
{
private:
    double d;
    
public:
    Double();
    Double(const Double &aDub);
    Double(double d);
    Double(Integer &i);
    
    void equals (const double aDub);
    Double add(const Double &aDub);
    Double add(const double aDub);
    Double sub(const Double &aDub);
    Double sub(const double aDub);
    Double mul(const Double &aDub);
    Double mul(const double aDub);
    Double div(const Double &aDub);
    Double div(const double aDub);
    double toDouble() const;
    
};


#endif
