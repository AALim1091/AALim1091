/*
 Julio
 Lopez
 ID: 0338770
 4/13/17
 Assignment 4
 Due: 4/16/17 by 11:59pm
 This is assignment is about changing from array to vector and testing our Integer and Double classes
 */
#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include "menu.h"
using namespace std;


Menu::Menu()
: count(0)
{
    
}
void Menu::addMenu(string Description, void (*f)(void))
{
    menuItem tmp = {f, Description};
       this->mi.push_back(tmp);
}

void Menu::runMenu()
{
    for(;;)
    {
        //system("CLS");
        for (int i = 0; i < this->mi.size(); i++)
        {
            cout << this->mi[i].descript << endl;
        }
        this->runSelection();
    }
}
void Menu::runSelection()
{
    int select;
    
    cin >> select;
    if(select <= this->mi.size())
        this->mi[select - 1].func();
}
void Menu::waitKey()
{
    getchar();
}
