/*
 Julio
 Lopez
 ID: 0338770
 4/13/17
 Assignment 4
 Due: 4/16/17 by 11:59pm
 This is assignment is about changing from array to vector and testing our Integer and Double classes
 */
#include <iostream>
#include "menu.h"
#include "Double.h"
#include "Integer.h"
using namespace std;

Menu m;

void addDouble();
void subDouble();
void mulDouble();
void divDouble();
void addInteger();
void subInteger();
void mulInteger();
void divInteger();
void Exit();

int main()
{
    m.addMenu("1. Add doubles", addDouble);
    m.addMenu("2. Subtract doubles", subDouble);
    m.addMenu("3. Multiply doubles", mulDouble);
    m.addMenu("4. Divide doubles", divDouble);
    m.addMenu("5. Add integers", addInteger);
    m.addMenu("6. subtract integers", subInteger);
    m.addMenu("7. Multiply integers", mulInteger);
    m.addMenu("8. Divide integers", divInteger);
    m.addMenu("9. Exit ", Exit);
    
    m.runMenu();
    
    return 0;
}

void addDouble()
{
    Double d1, d2;
    double x, y;
    cout << "Enter two doubles to add" << endl;
    cin >> x >> y;
    d1.equals(x);
    d2.equals(y);
    cout << "The result is " << d1.add(d2).toDouble() << endl;
}
void subDouble()
{
    Double d1, d2;
    double x, y;
    cout << "Enter two doubles to subtract" << endl;
    cin >> x >> y;
    d1.equals(x);
    d2.equals(y);
    cout << "The result is " << d1.sub(d2).toDouble() << endl;
}
void mulDouble()
{
    Double d1, d2;
    double x, y;
    cout << "Enter two doubles to multiply" << endl;
    cin >> x >> y;
    d1.equals(x);
    d2.equals(y);
    cout << "The result is " << d1.mul(d2).toDouble() << endl;
}
void divDouble()
{
    Double d1, d2;
    double x, y;
    cout << "Enter two doubles to multiply" << endl;
    cin >> x >> y;
    d1.equals(x);
    d2.equals(y);
    cout << "The result is " << d1.div(d2).toDouble() << endl;
}
void addInteger()
{
    Integer i1, i2;
    double x, y;
    cout << "Enter two ints to add" << endl;
    cin >> x >> y;
    i1.equals(x);
    i2.equals(y);
    cout << "The result is " << i1.add(i2).toInt() << endl;
}
void subInteger()
{
    Integer i1, i2;
    double x, y;
    cout << "Enter two ints to subtract" << endl;
    cin >> x >> y;
    i1.equals(x);
    i2.equals(y);
    cout << "The result is " << i1.sub(i2).toInt() << endl;
}
void mulInteger()
{
    Integer i1, i2;
    double x, y;
    cout << "Enter two ints to multiply" << endl;
    cin >> x >> y;
    i1.equals(x);
    i2.equals(y);
    cout << "The result is " << i1.mul(i2).toInt() << endl;
}
void divInteger()
{
    Integer i1, i2;
    double x, y;
    cout << "Enter two ints to divide" << endl;
    cin >> x >> y;
    i1.equals(x);
    i2.equals(y);
    cout << "The result is " << i1.div(i2).toInt() << endl;
}

void Exit()
{
    cout << "GoodBye" << endl;
    exit(0);
}

