
#include <iostream>
#include "Number.h"
#include "Double.h"
#include "Integer.h"
#include <string>

using namespace std;

int main()
{
    Double n(123);
    string str = n.toString();
    cout << str << endl;
    
    Integer x(456);
    string str1 = x.toString();
    cout << str1 << endl;
    return 0;
}
