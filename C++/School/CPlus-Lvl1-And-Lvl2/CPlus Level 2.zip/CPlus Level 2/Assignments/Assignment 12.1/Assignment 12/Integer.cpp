/*
 Julio
 Lopez
 ID: 0338770
 5/12/17
 Assignment 1
 Due: 5/14/17 by 11:59pm
 This is assignment is about inheretance
 */
#include "Integer.h"
#include <iostream>
#include <string>
#include <sstream>

using namespace std;

    //Constructors
Integer::Integer()
{
    this->Number::equals("0.0");
}
Integer::Integer(const Integer &anInt)
{
    this->equals(anInt.toInt());
}
Integer::Integer(int anInt)
{
    this->equals(anInt);
}
Integer::Integer(string str)
{
    this->equals(str);
}

//Functions

bool Integer::isNAN(string str)
{
    this->isNaN = recNan(str);
    return this->isNaN;
}

void Integer::equals(int i)
{
    stringstream ss;
    ss << i;
    this->equals(ss.str());
}

Integer &Integer::equals(const Integer &i)
{
    this->equals(i.toInt());
    return *this;
}

Integer Integer::add(const Integer &i)
{
    Integer tmp = this->toInt() + i.toInt();
    return tmp;
}
Integer Integer::add(const int i)
{
    Integer tmp = this->toInt() + i;
    return tmp;
}

Integer Integer::sub(const Integer &i)
{
    Integer tmp = this->toInt() - i.toInt();
    return tmp;
}
Integer Integer::sub(const int i)
{
    return this->toInt() - i;
}

Integer Integer::mul(const Integer &i)
{
    Integer tmp = this->toInt() * i.toInt();
    return tmp;
}
Integer Integer::mul(const int i)
{
    Integer tmp = this->toInt() * i;
    return tmp;
}

Integer Integer::div(const Integer &i)
{
    Integer tmp = this->toInt() / i.toInt();
    return tmp;
}
Integer Integer::div(const int i)
{
    Integer tmp = this->toInt() / i;
    return tmp;
}
int Integer::toInt() const
{
    return stoi(*this);
}
bool Integer::recNan(string str)
{
    if(str.empty())
        return false;
    else if (!isdigit(str[0]))
        return true;
    return recNan(str.substr(1, str.length()));
}


//operators overloa
Integer Integer::operator+(const Integer &i)
{
    return this->add(i);
}
Integer Integer::operator-(const Integer &i)
{
    return this->sub(i);
}
Integer Integer::operator*(const Integer &i)
{
    return this->mul(i);
}
Integer Integer::operator/(const Integer &i)
{
    return this->div(i);
}
Integer &Integer::operator=(const Integer &i)
{
    return this->equals(i);
}
Integer &Integer::operator=(int i)
{
    this->equals(i);
    return *this;
}
Integer &Integer::operator=(string str)
{
    this->equals(str);
    return *this;
}
bool Integer::operator==(const Integer &i)
{
    return this->toInt() == i.toInt();
}
bool Integer::operator==(int i)
{
    return this->toInt() == i;
}
bool Integer::operator!=(const Integer &i)
{
    return this->toInt() != i.toInt();
}
bool Integer::operator!=(int i)
{
    return this->toInt() != i;
}


