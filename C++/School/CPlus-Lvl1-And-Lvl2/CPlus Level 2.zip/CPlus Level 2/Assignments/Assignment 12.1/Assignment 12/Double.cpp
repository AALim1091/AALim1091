/*
 Julio
 Lopez
 ID: 0338770
 5/12/17
 Assignment 12
 Due: 5/14/17 by 11:59pm
 This is assignment is about inheretance
 */
#include "Double.h"
#include "Integer.h"
#include <iostream>
#include <string>
#include <sstream>

using namespace std;


    
Double::Double()
{
    this->Number::equals("0.0");
}
Double::Double(const Double &aDub)
{
    
    this->equals(aDub.toDouble());
}
Double::Double(double aDub)
{
    
    this->equals(aDub);
}
Double::Double(Integer &anInt)
{
    
    this->equals(anInt.toInt());
}
Double::Double(string str)
{
    this->Number::equals(str);
}


bool Double::isNAN(string str)
{
    this->isNaN = this->recNan(str, 0);
    return this->isNaN;
}

void Double::equals(double aDub)
{
    stringstream ss;
    ss << aDub;
    this->Number::equals(ss.str());
}
Double &Double::equals(Double &aDub)
{
    this->Number::equals(aDub.toString());
    return *this;
}
Double Double::add(const Double &aDub)
{
    Double tmp(this->toDouble() + aDub.toDouble());
    return tmp;
}
Double Double::add(double aDub)
{
    return this->toDouble() + aDub;
}
    
Double Double::sub(const Double &aDub)
{
    return this->toDouble() - aDub.toDouble();
}
Double Double::sub(const double aDub)
{
    return this->toDouble() - aDub;
}
    
Double Double::mul(const Double &aDub)
{
    return this->toDouble() * aDub.toDouble();
}
Double Double::mul(const double aDub)
{
    return this->toDouble() * aDub;
}
    
Double Double::div(const Double &aDub)
{
    return this->toDouble() / aDub.toDouble();
}
Double Double::div(const double aDub)
{
    return this->toDouble() / aDub;
}
    
double Double::toDouble() const
{
    return stod(*this);
}
bool Double::recNan(string s, int dCount)
{
    if (s.empty())
        return false;
    else if(s[0] == '.')
    {
        if (++dCount >1)
        {
            return true;
        }
    }
    else if (!isdigit(s[0]))
    {
        return true;
    }
    return recNan(s.substr(1,s.length()), dCount);
}
    
    //operators
    Double Double::operator+(const Double &d)
    {
        return this->add(d);
    }
    Double Double::operator-(const Double &d)
    {
        return this->sub(d);
    }
    Double Double::operator*(const Double &d)
    {
        return this->mul(d);
    }
    Double Double::operator/(const Double &d)
    {
        return this->div(d);
    }
    Double &Double::operator=(const Double &d)
    {
        this->Number::equals(d);
        return *this;
    }
    Double &Double::operator=(double d)
    {
        this->equals(d);
        return *this;
    }
    Double &Double::operator=(string str)
    {
        this->Number::equals(str);
        return *this;
    }
    bool Double::operator==(const Double &d)
    {
        return this->toDouble() == d.toDouble();
    }
    bool Double::operator==(double d)
    {
        return this->toDouble() == d;
    }
    bool Double::operator!=(const Double &d)
    {
        return this->toDouble() != d.toDouble();
    }
    bool Double::operator!=(double d)
    {
        return this->toDouble() != d;
    }
    
