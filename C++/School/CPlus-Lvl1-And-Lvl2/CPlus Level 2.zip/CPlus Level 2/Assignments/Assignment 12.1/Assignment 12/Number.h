/*
 Julio
 Lopez
 ID: 0338770
 5/12/17
 Assignment 1
 Due: 5/14/17 by 11:59pm
 This is assignment is about inheretance
 */
#ifndef Number_hpp
#define Number_hpp
#include <string>
using std::string;

class Number:public string
{
protected:
    bool isNaN = false;
    bool getNaN() const;
public:
    
    Number();
    Number(string str);
    void equals(string s);
    virtual const string toString();
    virtual bool isNAN(string s) = 0;
    

};

#endif /* Number_hpp */
