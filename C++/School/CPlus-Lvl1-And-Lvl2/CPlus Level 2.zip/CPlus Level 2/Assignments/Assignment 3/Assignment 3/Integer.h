/*
 Julio
 Lopez
 ID: 0338770
 4/7/17
 Assignment 3
 Due: 4/9/17 by 11:59pm
 This is assignment challenges us to create overloaded constructors
 */
#ifndef Integer_h
#define Integer_h

class Integer
{
private:
    int val;
    
public:
    Integer();
    Integer(const Integer &anInt);
    Integer(const int anInt);
    
    void equals(int anInt);
    Integer add(const Integer &anInt);
    Integer add(const int anInt);
    Integer sub(const Integer &anInt);
    Integer sub(const int anInt);
    Integer mul(const Integer &anInt);
    Integer mul(const int anInt);
    Integer div(const Integer &anInt);
    Integer div(const int anInt);
    int toInt() const;
    
};

#endif 
