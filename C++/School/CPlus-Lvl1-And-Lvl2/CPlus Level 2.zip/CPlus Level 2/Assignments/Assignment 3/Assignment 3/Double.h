/*
 Julio
 Lopez
 ID: 0338770
 4/7/17
 Assignment 3
 Due: 4/9/17 by 11:59pm
 This is assignment challenges us to create overloaded constructors
 */
#ifndef Double_h
#define Double_h
#include "Integer.h"

class Double
{
private:
    double d;
    
public:
    Double();
    Double(const Double &aDub);
    Double(double d);
    Double(Integer &i);
    
    void equals (const double aDub);
    Double add(const Double &aDub);
    Double add(const double aDub);
    Double sub(const Double &aDub);
    Double sub(const double aDub);
    Double mul(const Double &aDub);
    Double mul(const double aDub);
    Double div(const Double &aDub);
    Double div(const double aDub);
    double toDouble() const;
    
};


#endif
