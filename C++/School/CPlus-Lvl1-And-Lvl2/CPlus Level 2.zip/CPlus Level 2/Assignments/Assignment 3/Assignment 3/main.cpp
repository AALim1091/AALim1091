/*
 Julio
 Lopez
 ID: 0338770
 4/7/17
 Assignment 3
 Due: 4/9/17 by 11:59pm
 This is assignment challenges us to create overloaded constructors
 */
#include <iostream>
#include "Integer.h"
#include "Double.h"
using namespace std;

int main()
{

    
    int theInt = 20;
    Integer i1(10), i2(theInt), i3, i4;
    
    
    i3 = i1.add(theInt);
    int y = i3.toInt();
    
    
    i4 = i1.mul(i2);
    int z = i4.toInt();

    cout << y << endl;
    cout << z << endl;
    
    Double d1(2.5),d2,d3,d4;
    d2.equals(3.8);
    
    d3 = d2.sub(d1);
    double w = d3.toDouble();
    
    d4 = d2.div(d1);
    double x = d4.toDouble();
    
    cout << w << endl;
    cout << x << endl;
    
    
    
    
    
    return 0;
}
