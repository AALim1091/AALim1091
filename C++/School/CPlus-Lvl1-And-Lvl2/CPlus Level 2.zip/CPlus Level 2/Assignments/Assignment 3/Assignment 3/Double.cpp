/*
 Julio
 Lopez
 ID: 0338770
 4/7/17
 Assignment 3
 Due: 4/9/17 by 11:59pm
 This is assignment challenges us to create overloaded constructors
 */
#include "Double.h"
#include "Integer.h"
#include <iostream>
#include <string>

using namespace std;


Double::Double()
{
    this->equals(0.0);
}
Double::Double(const Double &aDub)
{
    this->equals(aDub.toDouble());
}
Double::Double(Integer &anInt)
{
    this->equals(anInt.toInt());
}
void Double::equals(const double aDub)
{
    this->d = aDub;
}

Double Double::add(const Double &aDub)
{
    Double t;
    t.d = this->toDouble() + aDub.d;
    return t;
}
Double Double::add(const double aDub)
{
    Double t;
    t.d = this->toDouble() + aDub;
    return t;
}

Double Double::sub(const Double &aDub)
{
    Double t;
    t.d = this->toDouble() - aDub.d;
    return t;
}
Double Double::sub(const double aDub)
{
    Double t;
    t.d = this->toDouble() - aDub;
    return t;
}

Double Double::mul(const Double &aDub)
{
    Double t;
    t.d = d * aDub.d;
    return t;
}
Double Double::mul(const double aDub)
{
    Double t;
    t.d = d * aDub;
    return t;
}

Double Double::div(const Double &aDub)
{
    Double t;
    t.d = d / aDub.d;
    return t;
}
Double Double::div(const double aDub)
{
    Double t;
    t.d = d / aDub;
    return t;
}

double Double::toDouble() const
{
    double t = d;
    return t;
}
