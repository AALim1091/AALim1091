/*
 Julio
 Lopez
 ID: 0338770
 4/7/17
 Assignment 3
 Due: 4/9/17 by 11:59pm
 This is assignment challenges us to create overloaded constructors
 */
#include "Integer.h"
#include <iostream>
#include <string>

using namespace std;


Integer::Integer()
{
    this->equals(0);
}
Integer::Integer(const Integer &anInt)
{
    this->equals(anInt.toInt());
}
Integer::Integer(const int anInt)
{
    this->equals(anInt);
}


void Integer::equals(int anInt)
{
    this->val = anInt;
}

Integer Integer::add(const Integer &anInt)
{
    Integer t;
    t.val = this->toInt() + anInt.val;
    return t;
}
Integer Integer::add(const int anInt)
{
    Integer t;
    t.val = this->toInt() + anInt;
    return t;
}

Integer Integer::sub(const Integer &anInt)
{
    Integer t;
    t.val = this->toInt() - anInt.val;
    return t;
}
Integer Integer::sub(const int anInt)
{
    Integer t;
    t.val = this->toInt() - anInt;
    return t;
}

Integer Integer::mul(const Integer &anInt)
{
    Integer t;
    t.val = this->toInt() * anInt.val;
    return t;
}
Integer Integer::mul(const int anInt)
{
    Integer t;
    t.val = this->toInt() * anInt;
    return t;
}

Integer Integer::div(const Integer &anInt)
{
    Integer t;
    t.val = this->toInt() / anInt.val;
    return t;
}
Integer Integer::div(const int anInt)
{
    Integer t;
    t.val = this->toInt() / anInt;
    return t;
}

int Integer::toInt() const
{
    return this->val;
}
