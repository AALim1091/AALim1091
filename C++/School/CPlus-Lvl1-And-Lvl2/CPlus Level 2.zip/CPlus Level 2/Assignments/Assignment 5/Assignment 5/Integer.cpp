/*
 Julio
 Lopez
 ID: 0338770
 4/15/17
 Assignment 5
 Due: 4/16/17 by 11:59pm
 This is assignment is about operatir Overloading
 */
#include "Integer.h"
#include <iostream>
#include <string>

using namespace std;

//Constructors
Integer::Integer()
{
    this->equals(0);
}
Integer::Integer(const Integer &anInt)
{
    this->equals(anInt.toInt());
}
Integer::Integer(const int anInt)
{
    this->equals(anInt);
}

//Functions
void Integer::equals(int anInt)
{
    this->val = anInt;
}
Integer &Integer::equals(const Integer &i)
{
    this->equals(i.toInt());
    return *this;
}

Integer Integer::add(const Integer &anInt)
{
    return this->toInt() + anInt.val;
}
Integer Integer::add(const int anInt)
{
    return this->toInt() + anInt;
}

Integer Integer::sub(const Integer &anInt)
{
    return this->toInt() - anInt.val;
}
Integer Integer::sub(const int anInt)
{
    return this->toInt() - anInt;
}

Integer Integer::mul(const Integer &anInt)
{
    return this->toInt() * anInt.val;
}
Integer Integer::mul(const int anInt)
{
    return this->toInt() * anInt;
}

Integer Integer::div(const Integer &anInt)
{
    return this->toInt() / anInt.val;
}
Integer Integer::div(const int anInt)
{
    return this->toInt() / anInt;
}
int Integer::toInt() const
{
    return this->val;
}

//operators overloa
Integer Integer::operator+(const Integer &i)
{
    return this->add(i);
}
Integer Integer::operator-(const Integer &i)
{
    return this->sub(i);
}
Integer Integer::operator*(const Integer &i)
{
    return this->mul(i);
}
Integer Integer::operator/(const Integer &i)
{
    return this->div(i);
}
Integer &Integer::operator=(const Integer &i)
{
    return this->equals(i);
}
Integer &Integer::operator=(int i)
{
    this->equals(i);
    return *this;
}
bool Integer::operator==(const Integer &i)
{
    return this->toInt() == i.toInt();
}
bool Integer::operator==(int i)
{
    return this->toInt() == i;
}
bool Integer::operator!=(const Integer &i)
{
    return this->toInt() != i.toInt();
}
bool Integer::operator!=(int i)
{
    return this->toInt() != i;
}
