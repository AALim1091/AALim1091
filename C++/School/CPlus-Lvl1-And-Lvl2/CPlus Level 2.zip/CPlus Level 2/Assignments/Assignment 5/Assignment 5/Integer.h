/*
 Julio
 Lopez
 ID: 0338770
 4/15/17
 Assignment 5
 Due: 4/16/17 by 11:59pm
 This is assignment is about operatir Overloading
 */
#ifndef Integer_h
#define Integer_h

class Integer
{
private:
    int val;
    
public:
    Integer();
    Integer(const Integer &anInt);
    Integer(const int anInt);
    
    void equals(int anInt);
    Integer &equals(const Integer &i);
    Integer add(const Integer &anInt);
    Integer add(const int anInt);
    Integer sub(const Integer &anInt);
    Integer sub(const int anInt);
    Integer mul(const Integer &anInt);
    Integer mul(const int anInt);
    Integer div(const Integer &anInt);
    Integer div(const int anInt);
    int toInt() const;
    
    //operator overload
    Integer operator + (const Integer &i);
    Integer operator - (const Integer &i);
    Integer operator * (const Integer &i);
    Integer operator / (const Integer &i);
    Integer &operator = (const Integer &i);
    Integer &operator = (int i);
    bool operator == (const Integer &i);
    bool operator != (const Integer &i);
    bool operator == (int i);
    bool operator != (int i);
};

#endif 
