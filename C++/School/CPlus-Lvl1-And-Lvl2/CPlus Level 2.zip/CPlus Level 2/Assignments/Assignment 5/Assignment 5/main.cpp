/*
 Julio
 Lopez
 ID: 0338770
 4/15/17
 Assignment 5
 Due: 4/16/17 by 11:59pm
 This is assignment is about operatir Overloading
 */
#include <iostream>
#include "menu.h"
#include "Double.h"
#include "Integer.h"
using namespace std;

Menu m;

void addDouble();
void subDouble();
void mulDouble();
void divDouble();
void addInteger();
void subInteger();
void mulInteger();
void divInteger();
void isEqual4Int();
void isNotEqual4Int();
void Exit();

int main()
{
    m.addMenu("1. Add doubles", addDouble);
    m.addMenu("2. Subtract doubles", subDouble);
    m.addMenu("3. Multiply doubles", mulDouble);
    m.addMenu("4. Divide doubles", divDouble);
    m.addMenu("5. Add integers", addInteger);
    m.addMenu("6. subtract integers", subInteger);
    m.addMenu("7. Multiply integers", mulInteger);
    m.addMenu("8. Divide integers", divInteger);
    m.addMenu("9. Are these ints they equal?", isEqual4Int);
    m.addMenu("10. Are these ints not equeal?", isNotEqual4Int);
    m.addMenu("11. Exit ", Exit);
    
    m.runMenu();
    
    return 0;
}

void addDouble()
{
    Double d1, d2;
    double x, y;
    cout << "Enter two doubles to add" << endl;
    cin >> x >> y;
    d1 = x;
    d2 = y;
    cout << "The result is " << (d1 + d2).toDouble() << endl;
}
void subDouble()
{
    Double d1, d2;
    double x, y;
    cout << "Enter two doubles to subtract" << endl;
    cin >> x >> y;
    d1=x;
    d2=y;
    cout << "The result is " << (d1-d2).toDouble() << endl;
}
void mulDouble()
{
    Double d1, d2;
    double x, y;
    cout << "Enter two doubles to multiply" << endl;
    cin >> x >> y;
    d1=x;
    d2=y;
    cout << "The result is " << (d1*d2).toDouble() << endl;
}
void divDouble()
{
    Double d1, d2;
    double x, y;
    cout << "Enter two doubles to multiply" << endl;
    cin >> x >> y;
    d1=x;
    d2=y;
    cout << "The result is " << (d1/d2).toDouble() << endl;
}
void addInteger()
{
    Integer i1, i2;
    double x, y;
    cout << "Enter two ints to add" << endl;
    cin >> x >> y;
    i1=x;
    i2=y;
    cout << "The result is " << (i1+i2).toInt() << endl;
}
void subInteger()
{
    Integer i1, i2;
    double x, y;
    cout << "Enter two ints to subtract" << endl;
    cin >> x >> y;
    i1=x;
    i2=y;
    cout << "The result is " << (i1-i2).toInt() << endl;
}
void mulInteger()
{
    Integer i1, i2;
    double x, y;
    cout << "Enter two ints to multiply" << endl;
    cin >> x >> y;
    i1=x;
    i2=y;
    cout << "The result is " << (i1*i2).toInt() << endl;
}
void divInteger()
{
    Integer i1, i2;
    double x, y;
    cout << "Enter two ints to divide" << endl;
    cin >> x >> y;
    i1=x;
    i2=y;
    cout << "The result is " << (i1/i2).toInt() << endl;
}

void isEqual4Int()
{
    Integer i1, i2;
    double x, y;
    cout << "Enter two Ints to compare equallity" << endl;
    cin >> x >> y;
    i1=x;
    i2=y;
    if (i1 == i2)
    cout << "The ints enetered are equal" <<endl;
    else
        cout << "Not equal" << endl;
}
void isNotEqual4Int()
{
    Integer i1, i2;
    double x, y;
    cout << "Enter two Ints to compare equallity" << endl;
    cin >> x >> y;
    i1=x;
    i2=y;
    if (i1 != i2)
        cout << "The ints enetered are not equal" <<endl;
    else
        cout << "They are equal" << endl;
}
void Exit()
{
    cout << "GoodBye" << endl;
    exit(0);
}

