/*
 Julio
 Lopez
 ID: 0338770
 4/15/17
 Assignment 5
 Due: 4/16/17 by 11:59pm
 This is assignment is about operatir Overloading
 */
#ifndef Double_h
#define Double_h
#include "Integer.h"

class Double
{
private:
    double d;
    
public:
    Double();
    Double(const Double &aDub);
    Double(double d);
    Double(Integer &i);
    
    Double &equals(const Double &aDub);
    void equals (double aDub);
    Double add(const Double &aDub);
    Double add(double aDub);
    Double sub(const Double &aDub);
    Double sub(const double aDub);
    Double mul(const Double &aDub);
    Double mul(const double aDub);
    Double div(const Double &aDub);
    Double div(const double aDub);
    double toDouble() const;
    
    Double operator + (const Double &d);
    Double operator - ( const Double &d);
    Double operator * (const Double &d);
    Double operator / (const Double &d);
    Double &operator = (const Double &d);
    Double &operator = (double d);
    bool operator == (const Double &d);
    bool operator != (const Double &f);
    bool operator == (double d);
    bool operator != (double d);
    
    
    
};


#endif
