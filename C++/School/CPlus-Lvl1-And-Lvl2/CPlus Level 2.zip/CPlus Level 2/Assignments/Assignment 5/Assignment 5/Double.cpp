/*
 Julio
 Lopez
 ID: 0338770
 4/15/17
 Assignment 5
 Due: 4/16/17 by 11:59pm
 This is assignment is about operatir Overloading
 */
#include "Double.h"
#include "Integer.h"
#include <iostream>
#include <string>

using namespace std;


Double::Double()
{
    this->equals(0.0);
}
Double::Double(const Double &aDub)
{
    this->equals(aDub.toDouble());
}
Double::Double(double aDub)
{
    this->equals(aDub);
}
Double::Double(Integer &anInt)
{
    this->equals(anInt.toInt());
}
void Double::equals(double aDub)
{
    this->d = aDub;
}
Double &Double::equals(const Double &aDub)
{
    this->equals(aDub.toDouble());
    return *this;
}

Double Double::add(const Double &aDub)
{
    return this->toDouble() + aDub.d;
}
Double Double::add(double aDub)
{
    return this->toDouble() + aDub;
}

Double Double::sub(const Double &aDub)
{
    return this->toDouble() - aDub.d;
}
Double Double::sub(const double aDub)
{
    return this->toDouble() - aDub;
}

Double Double::mul(const Double &aDub)
{
    return this->d * aDub.d;
}
Double Double::mul(const double aDub)
{
    return this->d * aDub;
}

Double Double::div(const Double &aDub)
{
    return this->d / aDub.d;
}
Double Double::div(const double aDub)
{
    return this->d / aDub;
}

double Double::toDouble() const
{
    double t = d;
    return t;
}

//operators
Double Double::operator+(const Double &d)
{
    return this->add(d);
}
Double Double::operator-(const Double &d)
{
    return this->sub(d);
}
Double Double::operator*(const Double &d)
{
    return this->mul(d);
}
Double Double::operator/(const Double &d)
{
    return this->div(d);
}
Double &Double::operator=(const Double &d)
{
    return this->equals(d);
}
Double &Double::operator=(double d)
{
    this->equals(d);
    return *this;
}
bool Double::operator==(const Double &d)
{
    return this->toDouble() == d.toDouble();
}
bool Double::operator==(double d)
{
    return this->toDouble() == d;
}
bool Double::operator!=(const Double &d)
{
    return this->toDouble() != d.toDouble();
}
bool Double::operator!=(double d)
{
    return this->toDouble() != d;
}




















