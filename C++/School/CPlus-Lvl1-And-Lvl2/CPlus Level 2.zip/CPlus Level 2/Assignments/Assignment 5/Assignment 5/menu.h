/*
 Julio
 Lopez
 ID: 0338770
 4/15/17
 Assignment 5
 Due: 4/16/17 by 11:59pm
 This is assignment is about operatir Overloading
 */
#ifndef menu_h
#define menu_h
#include <string>
#include <vector>

using std::string;
using std::vector;


const int MAXCOUNT = 20;

struct menuItem
{
    void (*func)();
    string descript;
};

class Menu
{
private:
    vector<menuItem> mi;
    int count;
    void runSelection();
    
public:
    Menu();
    void addMenu(string Description, void (*f)());
    void runMenu();
    void waitKey();

    
};


#endif 
