#include <iostream>
#include "Stack.hpp"
using namespace std;

int main()
{
    Stack st;
    st.push("hello");
    st.push("goodbye");
    cout << "The value at the top of the stack is " << st.peek() << endl;
}
