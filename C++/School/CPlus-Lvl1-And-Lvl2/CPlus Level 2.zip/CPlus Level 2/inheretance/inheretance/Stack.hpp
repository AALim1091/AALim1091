//
//  Stack.hpp
//  inheretance
//
//  Created by Julio Lopez on 5/9/17.
//  Copyright © 2017 Julio Lopez. All rights reserved.
//

#ifndef Stack_hpp
#define Stack_hpp

#include <stdio.h>
#include <vector>
#include <string>
using std::vector;
using std::string;

class Stack : public vector<string>
{
private:
    string getElement(bool erase);
    vector<string>::iterator pEnd;
public:
    Stack();
    string pop();
    string peek();
    void push(string elem);
    
};

#endif /* Stack_hpp */
