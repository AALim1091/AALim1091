//
//  Stack.cpp
//  inheretance
//
//  Created by Julio Lopez on 5/9/17.
//  Copyright © 2017 Julio Lopez. All rights reserved.
//

#include "Stack.hpp"
#include <iostream>

using namespace std;

Stack::Stack()
{
    
}

void Stack::push(string elem)
{
    this->push_back(elem);
}

string Stack::peek()
{
    return this->getElement(false);
}
string Stack::pop()
{
    return this->getElement(true);
}
string Stack::getElement(bool erase)
{
    this->pEnd = this->end() -1;
    string tmp = "";
    if(this->size() > 0)
    {
        tmp = *this->pEnd;
        if (erase)
            this->erase(pEnd);
    }
    return tmp;
}
