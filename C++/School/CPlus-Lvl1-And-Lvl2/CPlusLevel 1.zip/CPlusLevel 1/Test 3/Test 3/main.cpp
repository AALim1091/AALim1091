#include <iostream>
using namespace std;
bool lastDescending(int one, int two, int three);

int main()
{
    cout << "Enter three values" << endl;
    int a, b, c;
    cin >>a>>b>>c;
    
    if(lastDescending(a, b, c))
    {
        cout << "The values entered are in descending order" <<endl;
    }
    else
    {
        cout << "The values entered are not in descending order" <<endl;
    }
    
    
    return 0;
}

bool lastDescending(int one, int two, int three)
{
    bool descending;
    if(one > two && two > three)
    {
        descending = true;
    }
    else
        descending = false;
    return descending;
}





#include <iostream>
using namespace std;
string copyUcase(string one);
string copyUcase(string one, string two);

int main()
{
    string a, b;
    cout << "Enter a string with a variety of upper and lower case letteres" << endl;
    getline(cin, a);
    cout << "Enter a second string with same criteria" << endl;
    getline(cin, b);
    
    string copyOfAll = copyUcase(a,b);
    cout << "The upercase leters in both strings are "<< endl;
    cout << copyOfAll << endl;
    return 0;
}


string copyUcase(string one)
{
    string copyOfUpper = "\b";
    for(int i = 0; i < one.length(); i++)
    {
        if(isupper(one.at(i)))
        {
            copyOfUpper += one.at(i);
        }
    }
    return copyOfUpper;
}

string copyUcase(string one, string two)
{
    string copyOfUpper = copyUcase(one) + copyUcase(two);
    return copyOfUpper;
}




#include <iostream>
using namespace std;
void strMetric(string str, int &digit, int &vowel);
bool isVowel(char a);

int main()
{
    int numOfDigits = 0;
    int numOfVowels = 0;
    string a;
    cout << "Enter a string with a variety of digitd and letters" << endl;
    getline(cin, a);
    
    strMetric(a, numOfDigits, numOfVowels);
    
    cout << "There are "<<numOfDigits<<" digits and "<<numOfVowels<< " vowels in the string" <<endl;
    return 0;
}


void strMetric(string str, int &digit, int &vowel)
{
    for(int i = 0; i < str.length(); i++)
    {
        if(isdigit(str.at(i)))
        {
            digit++;
        }
        else if(isVowel(str.at(i)))
        {
            vowel++;
        }
    }
}

bool isVowel(char a)
{
    switch(tolower(a))
    {
        case 'a':
        case 'e':
        case 'i':
        case 'o':
        case 'u':
            return true;
        default:
        {
            return false;
        }
    }
}
