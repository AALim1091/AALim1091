
#include <iostream>
#include <iomanip>
using namespace std;
double sum3 (double a, double b, double c);
bool isVowel (char test);

int main()
{
//    double x, y, z;
//    cout << "Enter 3 integers" << endl;
//    cin >> x >> y >> z;
//
//    double sumAll = sum3(x,y,z);
//    cout << "The sum is  " << sumAll << endl;
//    return 0;
    
    char ch;
    cout << "Enter a character" << endl;
    cin >> ch;
    
    if (isVowel(ch))
    {
        cout << "The character is a vowel" << endl;
    }
    else
        cout << "The character is not a vowel" << endl;
    
        
    return 0;
    
}


double sum3 (double a, double b, double c)
{
    
    return a + b + c;
    
}

bool isVowel (char test)
{
    switch (toupper(test))
    {
            case 'A':
            case 'E':
            case 'I':
            case 'O':
            case 'U':
            return true;
    }
    return false;
}

void lights()
{
    static bool Switch = true; // Keeps the value after the function is terminated.
    Switch = !Switch;
    
    if (Switch)
        cout << "Lights On" << endl;
    else
        cout << "Lights Off" << endl;
    return;
    
}
