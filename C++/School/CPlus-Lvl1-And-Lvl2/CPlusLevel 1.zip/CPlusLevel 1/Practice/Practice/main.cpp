#include <iostream>
#include <string>
using namespace std;
int countVal(char *p);


int main()
{
    cout << 1234 % 100 << endl;
    cout << 123 % 10 << endl;
    cout << 12 % 10 << endl;
    cout << 1 % 10 << endl;
    cout << (1234/ 10) % 10 << endl;
    
    return 0;
}

int countVal(char *p)
{
    int count = 0;
    while(*p)
        switch(toupper(*p))
    {
        case 'A':
        case 'E':
        case 'I':
        case 'O':
        case 'U':
        count ++;
            p++;
        break;
    }
    return count;
}




//&str[strlen(str) - 1]
