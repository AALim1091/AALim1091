int countOccurrences(int arr[], int search, int sizeOfArr)
{
    int count;
    for(int i = 0; i < sizeOfArr; i++)
    {
        if(arr[i] == search)
            count++;
    }
    return count;
}


#include <iostream>
#include <string>
#include <iomanip>
using namespace std;


int main()
{
    
    string aStr = "Hello";
    cout << tolower(aStr.at(1)) << endl;
    
    
    return 0;
}

int capFirst(char *str, int size)
{
    int count = 0;
    str[0] = toupper(str[0]);
    for(int i = 1; i < size; i++)
    {
        if(str[i] == ' ')
        {
            i++;
            str[i] = toupper(str[i]);
            count++;
        }
    }
    return count;
}



#ifndef CHARACTER
#define CHARACTER


class Character
{
private:
    char data;
public:
    Character(): data(' ') {}
    Character(char data): data(data) {}
    
    setChar(char a);
    getint() const;
    getString() const;
    toUpper() const;
    toLower() const;
};

#endif


