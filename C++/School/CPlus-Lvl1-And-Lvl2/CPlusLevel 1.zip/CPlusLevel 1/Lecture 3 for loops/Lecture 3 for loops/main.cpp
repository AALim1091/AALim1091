#include <iostream>
#include <string>
using namespace std;

int main() {
    int n;
    cout << "enter a number" <<endl;
    cin >> n;
    int sum;
    for (int i = 0; i <= n ; i++ )
    {
        if (i % 2 == 0)
            sum += i;
    }
    cout << "The sum of the even numbers is " << sum <<endl;
    
    //this prints your text backwards
    string sentence;
    
    cout << "enter some text" << endl;
    getline(cin,sentence);
    
    for (int i = sentence.length() - 1; i >= 0; i--)
        cout << sentence.at(i);
    
    cout << endl;

    return 0;
}
