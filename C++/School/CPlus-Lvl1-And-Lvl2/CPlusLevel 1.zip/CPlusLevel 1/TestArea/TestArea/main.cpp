#include <iostream>
#include <string>
#include <iomanip>
using namespace std;
int capFirst(char *str, int size);

int main()
{
char str[] = "hello world of the";
    capFirst(str, 11);
    cout << capFirst(str, 17);
    for(int i = 0; i < 18; i++)
    {
        cout << str[i];
    }
    return 0;
}

int capFirst(char *str, int size)
{
    int count = 0;
    str[0] = toupper(str[0]);
    for(int i = 1; i < size; i++)
    {
        if(str[i] == ' ')
        {
            i++;
        str[i] = toupper(str[i]);
            count++;
        }
    }
    return count;
}
