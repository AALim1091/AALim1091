#include <iostream>
#include <string>
using namespace std;

int main()
{
    string input;
    int sumOfVow = 0;
    cout << "Please eneter some text" << endl;
    getline(cin,input);
    
    for (int i = 0; i < input.length(); i++)
    {
        switch (tolower(input.at(i)))
        {
            case 'a':
            case 'e':
            case 'i':
            case 'o':
            case 'u':
            {
                sumOfVow++;
                break;
            }
        }
        
    }
    cout << "Your text has " << sumOfVow << " vowels in it" << endl;
    return 0;
}



#include <iostream>
using namespace std;

int main()
{
    int firstNum, largestNum = 0, input;
    cout << "Eneter a number" << endl;
    cin >> firstNum;
    cout << "Enter another number" << endl;
    cin >> input;
    
    while (input != firstNum)
    {
        cout << "Enter another number" << endl;
        cin >> input;
        
        if ( largestNum < input && input != firstNum)
        {
            largestNum = input;
        }
    }
    
    cout << "The largest number entered was " << largestNum << endl;
    
    return 0;
}


#include <iostream>
using namespace std;

int main()
{
    int input, factorial = 1;
    cout << "Enter a number and I will compute the factorial " << endl;
    cin >> input;
    
    do
    {
        factorial *= input;
        input--;
        
    }while (input != 0);
    
    cout << "The factorial is " << factorial << endl;
    
    return 0;
}

