
#include <iostream>
using namespace std;

int main()
{
    
#include <iostream>
    using namespace std;
    
    int main()
    {
        int num1, num2;
        
        cout << "Please enter two whole numbers" <<endl;
        cin >> num1 >> num2;
        
        int square1 = (num1 * num1), square2 = (num2 * num2);
        
        cout << num1 << " squared is " << square1 <<endl;
        cout << num2 << " squared is " << square2 <<endl;
        cout << "Adding both squared values eaquals " << square1 + square2 <<endl;
        cout << "The average of the sum of the squares is " << ((square1 + square2) / 2) <<endl;
        return 0;
    }
    
#include <iostream>
        using namespace std;
        
        int main()
        {
            double cottonWeigh = 0, total;
            cout << "Please enter the weight of the cotton in pounds that you would like to sell?" <<endl;
            cin >> cottonWeigh;
            
            if (cottonWeigh <= 100)
            {
                total = (22.75 * cottonWeigh);
            }
            else if (cottonWeigh > 100)
            {
                total = ((22.75 * 100) + ((cottonWeigh-100)*22.90));
            }
            cout << "Your total pay is $" << total << endl;
            return 0;
        }

        
#include <iostream>
        using namespace std;
        
        int main()
        {
            int dayNum;
            
            cout << "Enter a number from 1 to 7 and I will output the day of the week corresponding to the number" <<endl;
            cin >> dayNum;
            switch (dayNum)
            {
                case 1:
                {
                    cout << "Monday" << endl;
                    break;
                }
                case 2:
                {
                    cout << "Tuesday" << endl;
                    break;
                }
                case 3:
                {
                    cout << "Wednesday" << endl;
                    break;
                }
                case 4:
                {
                    cout << "Thursday" << endl;
                    break;
                }
                case 5:
                {
                    cout << "Friday" << endl;
                    break;
                }
                case 6:
                {
                    cout << "Saturday" << endl;
                    break;
                }
                case 7:
                {
                    cout << "Sunday" << endl;
                    break;
                }
                default:
                {
                    cout << "Invalid input" << endl;
                }
            }
            return 0;
        }

        
#include <iostream>
#include <string>
        using namespace std;
        
        int main()
        {
            int num;
            
            cout << "Enter a value" <<endl;
            cin >> num;
            
            string oddOrEven = num % 2 ? "Odd" : "Even";
            
            cout << num << " is an " << oddOrEven << " number" <<endl;
            return 0;
        }

        return 0;
    }

    return 0;
}
