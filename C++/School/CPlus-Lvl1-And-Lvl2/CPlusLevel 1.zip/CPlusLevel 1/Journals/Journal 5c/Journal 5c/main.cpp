/*
 Julio
 Lopez
 ID: 0338770
 2/17/17
 Journal 5c
 Due: 2/19/17 by 11:59pm
 */

#include <iostream>
using namespace std;

int sumInt(int a, int b, int c, int d);
int sumInt(int a, int b, int c);
int sumInt(int a, int b);


int main()
{
    int n1, n2, n3 ,n4;
    cout << "Enter four numbers and I will add them" << endl;
    cin >> n1 >> n2 >> n3 >> n4;
    
    int mySum = sumInt(n1, n2, n3, n4);
    cout << "The sum is " << mySum <<endl;
    
    return 0;
}

int sumInt(int a, int b, int c, int d)
{
    return sumInt(sumInt(a,b,c),d);
}

int sumInt(int a, int b, int c)
{
    return sumInt(sumInt(a,b),c);
}

int sumInt(int a, int b)
{
    return a + b;
}

