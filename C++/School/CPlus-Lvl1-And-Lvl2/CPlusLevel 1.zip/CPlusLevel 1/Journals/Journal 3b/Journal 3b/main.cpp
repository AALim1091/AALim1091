/*
 Julio
 Lopez
 ID: 0338770
 2/3/17
 Journal 3b
 Due: 2/5/17 by 11:59pm
 */

#include <iostream>
#include <ctime>
using namespace std;

int main()
{
    int min, max;
    double randRange = (rand() % (1 + max-min) + min);
    srand((unsigned int)time(0));

    cout << "Enter your min value " << endl;
    cin >> min;
    cout << "Enter your max value " << endl;
    cin >> max;

    for (int j = 1; j < 10; j++)
    {
        for (int i = 1; i < 10; i++)
        {
        double randRange = (rand() % (1 + max-min) + min);
        cout << randRange << "\t";   
        }
        cout <<endl;
    }
    return 0;
}
