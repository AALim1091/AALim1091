/*
 Julio
 Lopez
 ID: 0338770
 3/4/17
 Journal 7b
 Due: 3/4/17 by 11:59pm
 */

#include <iostream>
using namespace std;
int xChars(char s[], char search);

int main()
{
    char s[] = "ap35aaslpa94ouhfaaiiya973yzz";
    char search;
   
    cout << "Enter a leter to look for " <<endl;
    cin >> search;
    
    int cnt = xChars(s, search);
    
    cout << "Modified "<<cnt<<" characters, here is the string "<<endl;
    cout << s<< endl;
    
    return 0;
}

int xChars(char *str, char search)
{
    int countD = 0;
    
    char *p = str;
    while(*p)
    {
        if(*p == search)
        {
           *p = 'X';
            countD++;
        }
        p++;
        
    }
    return countD;
}
