/*
 Julio
 Lopez
 ID: 0338770
 2/3/17
 Journal 3a
 Due: 2/5/17 by 11:59pm
 */

#include <iostream>
using namespace std;

int main ()
{
    for (int row = 1; row <10 ; row++ )
    {
        for (int col = 1; col <10 ; col++ )
        {
        cout << col * row << "\t";
        }
        cout << endl;
    }
    return 0;
}
