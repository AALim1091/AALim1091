/*
 Julio
 Lopez
 ID: 0338770
 2/3/17
 Journal 3c
 Due: 2/5/17 by 11:59pm
 */

#include <iostream>
#include <ctime>
using namespace std;

int main ()
{
    srand(static_cast<unsigned int>(time(0)));
    
    bool playAgain = true;
    
    while(playAgain == true)
    {
        int num, guess, count = 1;
        num = rand() % 10 + 1 ;
        cout << "Guess a number between 1 and 10 " << endl;
        cin >> guess;
        while (guess != num)
        {
            count++ ;
            cout << "Sorry, not it. Guess number between 1 and 10 again " << endl;
            cin >> guess;

        }
        cout << "It took you " << count << " tries to guess the number" <<endl<<endl;
        cout << "Would you like to play again? (y/n)" << endl;
        char maybe;
        cin >> maybe;
        playAgain = maybe == 'n' ? false : true ;
        
    }
    return 0;
}
