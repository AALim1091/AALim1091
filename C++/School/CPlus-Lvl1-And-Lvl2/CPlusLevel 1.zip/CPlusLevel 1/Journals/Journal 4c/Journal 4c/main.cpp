/*
 Julio
 Lopez
 ID: 0338770
 2/9/17
 Journal 4c
 Due: 2/12/17 by 11:59pm
 */

#include <iostream>
using namespace std;
double sumIt(double a, double b, double c);

int main()
{
    double val1, val2, val3;
    cout << "Enter 3 values \n";
    cin >> val1 >> val2 >> val3;
    
    double sum = sumIt(val1, val2, val3);
    cout << "The sum of the 3 values is " << sum << endl;
    
    return 0;
}

double sumIt(double a, double b, double c)
{
    return a + b + c;
}
