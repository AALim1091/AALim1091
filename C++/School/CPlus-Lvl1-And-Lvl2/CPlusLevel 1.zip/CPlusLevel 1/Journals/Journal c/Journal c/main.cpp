/*
 Julio
 Lopez
 ID: 0338770
 3/9/17
 Journal 8c
 Due: 3/12/17 by 11:59pm
 */


#include <iostream>
#include "PLAYER.h"
using namespace std;

int main()
{
    Player p;
    
    cout << "The average for "<< p.getName()<< " is " << p.getAvg() << endl;
    
    return 0;
}
