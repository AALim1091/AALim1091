#include <iostream>
#include "PLAYER.h"

Player::Player()
:name("Joe"), average(5.5)
{
}

Player::Player(string name)
:name(name), average(5.5)
{
}

Player::Player(string name, double average)
:name(name), average(average)
{
}
void Player::setPlayer(double avg, string name)
{
    this->average = avg;
    this->name = name;
    
}

double Player::getAvg()
{
    return this->average;
}

string Player::getName()
{
    return this->name;
}
