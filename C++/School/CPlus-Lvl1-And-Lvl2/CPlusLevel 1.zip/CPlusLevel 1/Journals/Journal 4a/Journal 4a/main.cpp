/*
 Julio
 Lopez
 ID: 0338770
 2/9/17
 Journal 4a
 Due: 2/12/17 by 11:59pm
 */
#include <iostream>
using namespace std;
void printName();
int printDate();

int main()
{
    printName();
    printDate();
    return 0;
}

void printName()
{
    cout << "Hello From Julio" << endl;
    return;
}

int printDate()
{
    cout << "Today is February 9, 2017" <<endl;
    return 0;
}
