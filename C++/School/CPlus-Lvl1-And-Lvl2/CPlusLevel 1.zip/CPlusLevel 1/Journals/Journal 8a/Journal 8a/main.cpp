/*
 Julio
 Lopez
 ID: 0338770
 3/8/17
 Journal 8a
 Due: 3/12/17 by 11:59pm
 */

#include <iostream>
using namespace std;


struct Player
{
    char Name[50];
    double average;
};

void fillPlayer(Player plr[]);
void printPlayerAvg(const Player plr[]);

int main()
{
    Player p[3];
    fillPlayer(p);
    printPlayerAvg(p);
    
    return 0;
}

void fillPlayer(Player plr[])
{
    for(int i = 0; i<3; i++)
    {
    cout << "Enter a players name" << endl;
    cin >> plr[i].Name;
    cout << "Enter a players average" << endl;
    cin >> plr[i].average;
    }
}

void printPlayerAvg(const Player plr[])
{
    for(int i = 0; i<3; i++)
    cout << plr[i].Name << " is hitting a " << plr[i].average << " average."<<endl;
}
