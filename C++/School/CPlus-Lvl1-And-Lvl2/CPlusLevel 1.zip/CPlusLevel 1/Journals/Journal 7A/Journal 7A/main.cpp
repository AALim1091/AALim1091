/*
 Julio
 Lopez
 ID: 0338770
 3/4/17
 Journal 7a
 Due: 3/4/17 by 11:59pm
 */

#include <iostream>
using namespace std;

int main()
{
    int *p;
    int ar[] = {1,2,3,4,5,6,7,8,9,10};
    p = &ar[9];
    
    for(int i = 0; i < 10; i++, p--)
        cout << *p << endl;
    
    return 0;
}
