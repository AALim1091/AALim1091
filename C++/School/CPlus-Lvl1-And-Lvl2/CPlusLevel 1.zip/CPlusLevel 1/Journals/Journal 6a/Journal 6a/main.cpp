/*
 Julio
 Lopez
 ID: 0338770
 2/24/17
 Journal 6a
 Due: 2/26/17 by 11:59pm
 */

#include <iostream>
using namespace std;
void fillArr(int arr[], int size);
void printArr(const int arr[], int size);

int main()
{
    int ar[10];
    fillArr(ar, 10);
    printArr(ar, 10);
    return 0;
}

void fillArr(int arr[], int size)
{
    for (int i = 0; i < size; i++)
        arr[i] = rand() % 10 + 1;
}

void printArr(const int arr[], int size)
{
    for (int i = 0; i < size; i++)
        cout << arr[i]<< endl;
}
