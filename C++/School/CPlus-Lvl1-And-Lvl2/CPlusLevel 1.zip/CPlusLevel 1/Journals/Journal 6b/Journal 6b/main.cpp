/*
Julio
Lopez
ID: 0338770
2/24/17
Journal 6b
Due: 2/26/17 by 11:59pm
*/

#include <iostream>
using namespace std;
void fillArr(int arr[], int size);
void printArr(const int arr[], int size);
int countOccur(int arr[], int size, int search);

int main()
{
    int ar[10];
    int search = 9;
    int numOcurrences;
    fillArr(ar, 10);
    printArr(ar, 10);
    numOcurrences =  countOccur(ar, 10, search);
    cout << "The number " << search << " had "<< numOcurrences << " in the list of random numbers"<<  endl;
    return 0;
}

void fillArr(int arr[], int size)
{
    for (int i = 0; i < size; i++)
        arr[i] = rand() % 10 + 1;
}

void printArr(const int arr[], int size)
{
    for (int i = 0; i < size; i++)
        cout << arr[i]<< endl;
}

int countOccur(int arr[], int size, int search)
{
    int count = 0;
    for (int i = 0; i < size; i++)
    {
        if (arr[i] == search)
            count ++;
    }
    return count;
}
