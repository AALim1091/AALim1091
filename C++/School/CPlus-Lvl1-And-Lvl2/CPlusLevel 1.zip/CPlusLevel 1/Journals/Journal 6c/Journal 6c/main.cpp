/*
 Julio
 Lopez
 ID: 0338770
 2/24/17
 Journal 6c
 Due: 2/26/17 by 11:59pm
 */

#include <iostream>
using namespace std;
void fillAr(int ar[][5], int size);
void printAr(int ar[][5], int size);
int countNums(int ar[][5], int size, int search);

int main()
{
    int ar[5][5];
    fillAr(ar, 5);
    printAr(ar, 5);
    
    cout << "What number would you like to search for? " <<endl;
    int num;
    cin >> num;
    int count = countNums(ar, 5, num);
    cout << "Your number appeared for a total of " << count << " times" <<endl;
    
    return 0;
}

void fillAr(int ar[][5], int size)
{
    for(int row = 0; row < size; row++)
    {
        for(int col = 0; col < size; col++)
        {
            ar[row][col] = rand() % 10 + 1;
        }
    }
}

void printAr(int ar[][5], int size)
{
    for(int row = 0; row < size; row++)
    {
        for(int col = 0; col < size; col++)
        {
            cout << ar[row][col] << "\t";
        }
        cout << endl;
    }
}

int countNums(int ar[][5], int size, int search)
{
    int count;
    for(int row = 0; row < size; row++)
    {
        for(int col = 0; col < size; col++)
        {
            if (ar[row][col] == search)
            {
                cout << search << " apears in row "<<row <<" col "<<col <<"." <<endl;
                count++;
            }
        }
    }

    return count;
}
