/*
 Julio
 Lopez
 ID: 0338770
 3/9/17
 Journal 8b
 Due: 3/12/17 by 11:59pm
 */

#include <iostream>
#include "PLAYER.h"
using namespace std;

int main()
{
    Player p;
    p.setPlayer(.750, "Julio");
    
    cout << "The average for "<< p.getName()<< " is " << p.getAvg() << endl;
    
    return 0;
}
