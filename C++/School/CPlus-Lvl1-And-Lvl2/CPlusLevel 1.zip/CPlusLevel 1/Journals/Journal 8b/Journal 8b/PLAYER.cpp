#include <iostream>
#include "PLAYER.h"

void Player::setPlayer(double avg, string name)
{
    this->average = avg;
    this->name = name;
    
}

double Player::getAvg()
{
    return this->average;
}

string Player::getName()
{
    return this->name;
}
