#include <string>
using std::string;

#ifndef PLAYER
#define PLAYER

class Player
{
private:
    string name;
    double average;

public:
    void setPlayer(double avg, string name);
    double getAvg();
    string getName();
    
};

#endif
