/*
 Julio
 Lopez
 ID: 0338770
 1/27/17
 Journal 2c
 Due: 1/29/17 by 11:59pm
 */

#include <iostream>
using namespace std;

int main ()
{
    cout << "Enter two values plese" << endl;
    double val1, val2;
    cin >> val1 >> val2;
    cout << "Enter 1 to add them \n" << "Enter 2 to Subtract them \n";
    cout << "Enter 3 to multiply them \n" << "Enter 4 to divide them \n";
    int choice;
    cin >> choice;
    switch (choice)
    {
        case 1:
            cout << "Adding the values gives you " << val1 + val2 <<endl;
            break;
        case 2:
            cout << "Subtracting the values gives you " << val1 - val2 <<endl;
            break;
        case 3:
            cout << "Multiplying the values gives you " << val1 * val2 <<endl;
            break;
        case 4:
            cout << "Dividing the values gives you " << val1 / val2 <<endl;
            break;
        default:
            cout << "Invalid operation"<<endl;
    }
    
    
    
    return 0;
}

