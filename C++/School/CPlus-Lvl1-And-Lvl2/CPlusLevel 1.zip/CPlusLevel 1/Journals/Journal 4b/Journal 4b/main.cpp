/*
 Julio
 Lopez
 ID: 0338770
 2/9/17
 Journal 4b
 Due: 2/12/17 by 11:59pm
 */
#include <iostream>
#include <cmath>
using namespace std;
void squareValue();
int getValue();

int main ()
{
    squareValue();
    
    return 0;
}

int getValue()
{
    int val;
    cout << "Enter a value" << endl;
    cin >> val;
    return val;
}

void squareValue()
{
    int squared = pow(getValue(),2);
    cout << "The number squared is " << squared <<endl;
    return;
}

