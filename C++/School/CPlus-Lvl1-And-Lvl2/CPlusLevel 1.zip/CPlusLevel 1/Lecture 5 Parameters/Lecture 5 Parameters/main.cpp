#include <iostream>
#include <cmath>
using namespace std;
int sumAscii(string x);
int sumAscii(string x, string y);

int main()
    {

        string one, two;
        cout << "What is your name?" <<endl;
        getline(cin,one);
        cout << "What is your Last name?" <<endl;
        getline(cin,two);
        
        cout << sumAscii(one) << endl;
        cout << sumAscii(one,two) << endl;
        
        
        return 0;
    }

int sumAscii(string x)
{
    int sum=0;
    for (int i = 0; i < x.length(); i++)
    sum += static_cast<int>(x.at(i));
    return sum;
}

int sumAscii(string x, string y)
{
    return sumAscii(x) + sumAscii(y);
}





//int x = 3, y = 5;
//cout << "A1" << calArea(x);
//cout << "A2" << calArea(x, y);
//
//
//int calArea(int lenght, int with)
//{
//    int area = lenght * with;
//    
//    return area;
//    
//}
