#ifndef AVLTREE
#define AVLTREE

#include "Tree.h"
#include <string>

using namespace std;


template <class T>
class AvlTree : protected Tree<T>
{
public:
	void printAvl();
	void makeEmpty();
	void insert(T x);
	void remove(T x);
	T findMin();
	T findMax();
	T find(T x);

	Node<T>* returnRoot();

private:
	Node<T> *root;
	void insert(const T &data, Node<T> *&rt);
	void remove(T x, Node<T> *&root);
	T elementAt(Node<T> *rt);
	void printAvl(Node<T> *&root);
	int max(int lhs, int rhs);
	int height(Node<T> *t);

	void rotateLeft(Node<T> *&k2);
	void rotateRight(Node<T> *&k4);
	void doubleLeft(Node<T> *&k3);
	void doubleRight(Node<T> *&k1);

	Node<T>* findMin(Node<T> *t);
	Node<T>* findMax(Node<T> *t);
	Node<T>* find(T x, Node<T> *t);
};


template <class T>
void AvlTree<T>::insert(T x)
{
	this->insert(x, this->root);
}


//template <class T>
//void AvlTree<T>::insert(T x, Node<T> *&root) 
//{
//	if (root == NULL)
//	{
//		root = new Node <T>;
//		root->element = x;
//		root->left = NULL;
//		root->right = NULL;
//
//	}
//	else if (x < root->element)
//	{
//		insert(x, root->left);
//		if (height(root->left) - height(root->right) == 2)
//			if (x < root->left->element)
//				rotateLeft(root);
//			else
//				doubleLeft(root);
//	}
//	else if (root->element < x)
//	{
//		insert(x, root->right);
//		if (height(root->right) - height(root->left) == 2)
//			if (root->right->element < x)
//				rotateRight(root);
//			else
//				doubleRight(root);
//	}
//	if (root != NULL)
//		root->height = max(height(root->left), height(root->right)) + 1;
//}

// This is the problem here<--------------------
template <class T>
void AvlTree<T>::insert(const T &x, Node<T> *&root) //const
{
	if (root == NULL)
	{
		root = new Node <T>;
		root->element = x;
		root->left = NULL;
		root->right = NULL;
	}
	else if (x < root->element)
	{
		insert(x, root->left);
		if (height(root->left) - height(root->right) == 2)
			if (x < root->left->element)
				rotateLeft(root);
			else
				doubleLeft(root);
	}
	else if (root->element < x)
	{
		insert(x, root->right);
		if (height(root->right) - height(root->left) == 2)
			if (root->right->element < x)
				rotateRight(root);
			else
				doubleRight(root);
	}

	if (root != NULL)
		root->height = max(height(root->left), height(root->right)) + 1;
}


template <class T>
int AvlTree<T>::height(Node<T> *root)
{
	return root == NULL ? -1 : root->height;
}


template <class T>
void AvlTree<T>::rotateLeft(Node<T> *&k2)
{
	/*if (k2->left == NULL)
	return;*/

	Node<T> *k1 = k2->left;
	k2->left = k1->right;
	k1->right = k2;
	k2->height = max(height(k2->left), height(k2->right)) + 1;
	k1->height = max(height(k1->left), k2->height) + 1;
	k2 = k1;
}


template <class T>
void AvlTree<T>::rotateRight(Node<T> *&k1)
{
	/*if (k1->right == NULL)
	return;*/

	Node<T> *k2 = k1->right;
	k1->right = k2->left;
	k2->left = k1;
	k1->height = max(height(k1->left), height(k1->right)) + 1;
	k2->height = max(height(k2->right), k1->height) + 1;
	k1 = k2;
}


template <class T>
void AvlTree<T>::doubleLeft(Node<T> *&k3)
{
	rotateRight(k3->left);
	rotateLeft(k3);
}


template <class T>
void AvlTree<T>::doubleRight(Node<T> *&k1)
{
	rotateLeft(k1->right);
	rotateRight(k1);
}


template <class T>
void AvlTree<T>::printAvl()
{
	this->printAvl(root);
}


template <class T>
void AvlTree<T>::printAvl(Node<T> *&root)
{
	if (root != NULL)
	{
		cout << root->element << endl;
		cout << "left of " << root->element << ":" << endl; this->printAvl(root->left);
		cout << "right of " << root->element << ":" << endl; this->printAvl(root->right);
	}
}


template <class T>
int AvlTree<T>::max(int lhs, int rhs)
{
	return lhs > rhs ? lhs : rhs;
}


template <class T>
void AvlTree<T>::remove(T x)
{
	remove(x, this->root);
}


template <class T>
void AvlTree<T>::remove(T x, Node<T> *&root)
{
	if (root == NULL)
		return;

	else if (x < root->element)
	{
		remove(x, root->left);
		if (height(root->right) - height(root->left) > 1)
		{
			if (height(root->right->right) >= height(root->right->left))
				rotateRight(root);
			else
				doubleRight(root);
		}
	}

	else if (x > root->element)
	{
		remove(x, root->right);
		if (height(root->left) - height(root->right) > 1)
		{
			if (height(root->left->left) >= height(root->left->right))
				rotateLeft(root);
			else
				doubleLeft(root);
		}
	}

	else
	{

		if (root->left == NULL || root->right == NULL)
		{
			Node<T> *temp = root->left ? root->left : root->right;

			if (temp == NULL)
			{
				temp = root;
				root = NULL;
			}
			else
			{
				*root = *temp;
			}
			delete temp;
		}
		else
		{
			Node<T> *temp = findMin(root->right);
			root->element = temp->element;
			remove(temp->element, root->right);
		}
		if (root != NULL)
			root->height = max(height(root->left), height(root->right)) + 1;
	}
}


template <class T>
T AvlTree<T>::findMin()
{
	return elementAt(findMin(root));
}


template <class T>
T AvlTree<T>::findMax()
{
	return elementAt(findMax(root));
}

template <class T>
T AvlTree<T>::find(T x)
{
	return elementAt(find(x, root));
}


template <class T>
Node<T>* AvlTree<T>::findMin(Node<T> *t)
{
	if (t == NULL)
		return t;

	while (t->left != NULL)
		t = t->left;
	return t;
}


template <class T>
Node<T>* AvlTree<T>::findMax(Node<T> *t)
{
	if (t == NULL)
		return t;

	while (t->right != NULL)
		t = t->right;
	return t;
}


template <class T>
Node<T>* AvlTree<T>::find(T x, Node<T> *t)
{
	while (t != NULL)
		if (x < t->element)
			t = t->left;
		else if (t->element < x)
			t = t->right;
		else
			return t;    // Match

		return NULL;   // No match
}


template <class T>
Node<T>* AvlTree<T>::returnRoot()
{
	return root;
}
#endif

