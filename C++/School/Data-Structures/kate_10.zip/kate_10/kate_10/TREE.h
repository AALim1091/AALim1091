#ifndef TREE
#define TREE

#include <string>
using namespace std;

#include <iostream>

template <class T>
struct Node
{
public:
	T element;
	Node *left;
	Node *right;
	int height;

};


template <class T>
class Tree
{
protected:

	Node<T> *Root;
	void insert(T data, Node<T> *&n);
	void remove(T data, Node<T> *&n);
	int findMin(Node<T> *left);
	int findMax(Node<T> *right);
	bool contains(T data, Node<T> *n);
	void printTree(Node<T> *n);
	Tree(const Tree & rhs);

public:

	Tree();
	bool isEmpty();
	int findMin();
	int findMax();
	void insert(T data);
	void remove(T data);
	bool contains(T data);
	void printTree();
};


template <class T>
Tree<T>::Tree(const Tree<T> &rhs) :
	ITEM_NOT_FOUND(rhs.ITEM_NOT_FOUND), root(NULL)
{
	*this = rhs;
}


template <class T>
Tree<T>::Tree()
{
	this->Root = NULL;
}


template <class T>
bool Tree<T>::isEmpty()
{
	return this->Root == NULL;
}


template <class T>
int Tree<T>::findMin()
{
	return this->findMin(this->Root);
}


template <class T>
int Tree<T>::findMin(Node<T> *root)
{
	if (root->left == NULL)
		return root->element;
	else
		return findMin(root->left);

}


template <class T>
int Tree<T>::findMax()
{
	return this->findMax(this->Root);
}


template <class T>
int Tree<T>::findMax(Node<T> *root)
{
	if (root->right == NULL)
		return root->Data;
	else
		return findMax(root->right);

}



template <class T>
bool Tree<T>::contains(T data)
{
	return this->contains(data, this->Root);
}



template <class T>
bool Tree<T>::contains(T data, Node<T> *n)
{

	if (n == NULL)
		return false;
	else if (data < n->element)
		return contains(data, n->left);
	else if (data > n->element)
		return contains(data, n->right);
	else
		return true;

}


template <class T>
void Tree<T>::printTree()
{
	this->printTree(this->Root);
}



template <class T>
void Tree<T>::printTree(Node<T> *n)
{
	if (n != NULL)
	{
		cout << n->element << endl;
		this->printTree(n->left);
		this->printTree(n->right);
	}
}


template <class T>
void Tree<T>::insert(T data)
{
	this->insert(data, this->Root);
}


template <class T>
void Tree<T>::insert(T Ele, Node<T> * &n)
{

	if (n == NULL)
	{
		n = new Node<T>;
		n->element = Ele;
		n->left = NULL;
		n->right = NULL;
	}
	else if (Ele< n->element)
	{
		insert(Ele, n->left);
	}
	else if (Ele > n->element)
	{
		insert(Ele, n->right);
	}
	return;
}


template <class T>
void Tree<T>::remove(T data)
{
	this->remove(data, this->Root);
}


template <class T>
void Tree<T>::remove(T data, Node<T> * &n)
{
	if (Root == NULL)
		return;
	if (data < n->Data)
		this->remove(data, n->left);
	else if (data > n->Data)
		this->remove(data, n->right);
	else if (n->left != NULL && n->right != NULL)
	{
		n->Data = findMin(n->right);
		remove(n->Data, n->right);
	}
	else
	{
		Node<T> *oldNode = n;
		n = (n->left != NULL) ? n->left : n->right;
		delete oldNode;
	}
}
#endif


