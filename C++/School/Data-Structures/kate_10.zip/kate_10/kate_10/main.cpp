#include "AvlTree.h"
//#include "TREE.h"

using namespace std;
#include <string>

int main()
{

	//Tree<int> tmp1;
	//tmp1.insert(1);
	//tmp1.printTree();
	//AvlTree<string> avl;
	AvlTree<int> avl2;
	avl2.insert(23);
	avl2.insert(18);
	avl2.insert(20);
	avl2.insert(12);
	avl2.insert(8);
	avl2.insert(14);
	avl2.insert(44);
	avl2.insert(52);
	avl2.insert(6);
	//avl2.insert(2);
	avl2.printAvl();
	//avl.returnRoot();
	//avl.insert("1");



	return 0;
}
