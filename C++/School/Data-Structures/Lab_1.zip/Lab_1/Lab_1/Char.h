/*
Aaron Lim
Student number: 0353402
Date:August 22, 2015
Data Structures
Lab 1: Char class
*/
#ifndef CHAR
#define CHAR

#include <string>
#include <sstream>
using std::string;

class Char
{
	
	private:
		char data;

	public:
		//Constructors
		Char();								//Default constructor that sets the data section of the class to null (binary 0)
		Char(char c);						//Overloaded constructor that takes a primitive char as an argument. It should set the data section of the class to the argument.
		Char(int c);						//Overloaded constructor that takes a primitive int as a parameter. The data section of the class should be set as a character from the argument.
		Char(const Char &c);				//Overloaded constructor that takes the complex Char type as a parameter.  The data section of the class should be set with the data section of the argument
		Char(string c);						//Overloaded Constructor that takes a string type as a parameter. The data section of the class should be set to the first character in the string.

		//Mutators
		void equals(const Char &c);			//Sets the data section to the data section of the argument
		void equals(char c);				//Sets the data section to the primitive argument
		void equals(int c);					//Sets the data section of the class  as a character from the int argument.

		//Accessors
		char toChar() const;				//Returns the data section of the class as a char.
		int toInt() const;					//Returns the data section of the class as an int.
		string toString();					//Returns the data section of the class as a string
		string toHexString();				//Returns the data section of the class as a hexadecimal valued string
		string operator + (char c);			//Concatenates the data section of the class with the parameter and returns the two characters as a string.
		string operator + (const Char &c);	//Concatenates the data section of the class with the data section of the  parameter and returns the two characters as a string.
};

#endif
