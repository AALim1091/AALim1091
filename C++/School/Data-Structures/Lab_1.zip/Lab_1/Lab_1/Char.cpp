/*
Aaron Lim
Student number: 0353402
Date:August 22, 2015
Data Structures
Lab 1: Char class
*/
#include <iostream>
#include<sstream>
#include<string>
#include "Char.h"

using namespace std;

Char::Char()
{
	this->data = 0;
	//this->equals(data);
}

Char::Char(char c)
{
	this->data = c;
}

Char::Char(int c)
{

	this->data = (char)c;
}

Char::Char(const Char &c)
{
	this->data = c.data;
}

void Char::equals(char c)
{
	this->equals(c);
}

void Char::equals(int c)
{
	//stringstream ss;
	//ss << c;
	this->equals(data);
}
void Char::equals(const Char &c)
{
	this->equals(data);
}

Char::Char(string c)
{
	for (int i = 0; i < c.length(); i++)
	{
		this->data = c.at(i);
	}
}

char Char::toChar() const
{
	return (char)this->data;
}

int Char::toInt() const
{
	return (int)this->data;
}

string Char::toString()
{
	stringstream ss;
	ss << this->data;

	string s = ss.str();
	return s;
}

string Char::toHexString()
{
	stringstream ss;
	ss << hex << this->data;

	string s = ss.str();
	return s;
}

string Char::operator + (char c)
{
	//this->data.toString();
	//return *this;
	
}

string Char::operator + (const Char &c)
{
	//this->data = c.data;
	//return *this;
}

