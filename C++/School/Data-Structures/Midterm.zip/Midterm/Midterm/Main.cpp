/*
file: main.cpp
Author : Aaron Lim
10/21/15 lab 9:  Palindrome, in/outfile
Description : reads infile and
Outputs:  palindromes into pal.txt
*/
#include <iostream>
#include <cctype>
//#include "DblyLinkedList.h"
//#include "Stack.h"
//#include "Queue.h"
//#include "BigDecimal.h"
//#include "RPNCalculator.h"
//#include "InfixCalculator.h"

using namespace std;

void BigOhOne();
void BigOhTwo();
void BigOhThree();
void BigOhFour();
void BigOhFive();
void BigOhSix();


int main()
{
	//Call each function containing seperate code fragments
	cout << endl;
	BigOhOne();
	cout << "BigOhOne's Big-Oh notation is O(n) (plz read comments for analysis of code) " << endl;
	BigOhTwo();
	cout << "BigOhTwo's Big-Oh notation is O(n^2) (plz read comments for analysis of code) " << endl;
	BigOhThree();
	cout << "BigOhThree's Big-Oh notation is O(n^3) (plz read comments for analysis of code) " << endl;
	BigOhFour();
	cout << "BigOhFour's Big-Oh notation is O(n^2) (plz read comments for analysis of code) " << endl;
	BigOhFive();
	cout << "BigOhFive's Big-Oh notation is O(n^5) (plz read comments for analysis of code) " << endl;
	BigOhSix();
	cout << "BigOhSix's Big-Oh notation is O(n^3) (plz read comments for analysis of code) " << endl;

	cout << endl;

	//test for bigohsix
	//int mod;
	//int a = 4;
	//int b = 5;
	//mod = a % b;
	//cout << "the mod is " << mod << endl;

	return 0;
}

//Answer: O(n)
void BigOhOne()
{
	//int n = 100;
	//int n = 10000;
	int n = 10;//variable can be an number 1 -> infinity, executes 'n' times. declaration O(1)
	int i; // simple declaration O(1)

	int sum = 0; // simple declaration O(1)
	for (i = 0; i < n; i++) // O(n)
		sum++; // simple declaration O(1)
			cout << sum << endl; // simple declaration O(1)

			   //analysis:
			   // O(1) * O(1) * O(1) * O(n) * O(1)
			   //alg = O(1) * O(n) = O(n)
			   //Answer: O(n)
}

//Answer: O(n^2)
void BigOhTwo()
{
	//int n = 100;
	//int n = 10000;
	int n = 10;//variable can be an number 1 -> infinity, executes 'n' times. declaration O(1)
	int i; // simple declaration O(1)
	int j; // simple declaration O(1), goes from 0 -> n
	int sum = 0; // simple declaration O(1)
	for (i = 0; i < n; i++) // O(n)
		for (j = 0; j < n; j++)  // O(n)    or (n - 1 ) but constants are ignored
			sum++; // does something basic O(1)
				   cout << sum << endl;

				   //analysis:
				   // O(1) * O(1) * O(1) * O(1) * O(n) * O(n) * O(1)
				   //alg = O(1) * O(n) O(n) = O(N^2)
				   //Answer: O(n^2)
}

//Answer: O(n^3)
void BigOhThree()
{
	//int n = 100;
	//int n = 10000;
	int n = 10;//variable can be an number 1 -> infinity, executes 'n' times. declaration O(1)
	int sum = 0; // O(1)
	for (int i = 0; i < n; i++) // O(n)
		for (int j = 0; j < n * n; j++)// O(n^2)
			sum++; // O(1)
				   cout << sum << endl;
				   //analysis:
				   // O(1) * O(1) * O(n) * O(n^2) * O(1)
				   //O(1) * O(n^3)
				   //Answer: O(n^3)
}


//Answer: O(n^2)
void BigOhFour()
{
	//int n = 100;
	//int n = 10000;
	int n = 10;//variable can be an number 1 -> infinity, executes 'n' times. declaration O(1)
	int sum = 0; // O(1)
	for (int i = 0; i < n; i++) // O(n)
		for (int j = 0; j < i; j++) // O(n - 1) / 2 = O(n)    j<i but i goes n times, so i = n, thus (j = 0; j < n;j++)
			sum++; // O(1)
				cout << sum << endl;
				   //analysis:
				//n(n -1) / 2 
				   // O(1) * O(1) * O(n(n - 1) / 2) * O(1)
				   //O(1) * O((n^2 - n) / 2 ) = O(n^2) 
				   //Answer: O(n^2)
}

//Answer: O(n^5)
void BigOhFive()
{
	//int n = 100;
	//int n = 10000;
	int n = 10;//variable can be an number 1 -> infinity, executes 'n' times. declaration O(1)
	int sum = 0; // O(1)
	for (int i = 0; i < n; i++) //O(n)
		for (int j = 0; j < i * i; j++) // O(n^2 - 1) / 2 because i goes to n so i = n;  j < n * n = n^2
			for (int k = 0; k < j; k++) //O(n^2 - 1) / 3
				sum++; //O(1)
					cout << sum << endl;
					   //analysis:
					   // O(1) * O(1) * O(n) * O(n^2) * O(n^2) * O(1)
					   // O(1) * O(n^5)
					   //Answer: O(n^5)
}

//Answer: O(n^3)
void BigOhSix()
{
	//int n = 100;
	//int n = 10000;
	int n = 10;//variable can be an number 1 -> infinity, executes 'n' times. declaration O(1)
	int sum = 0; // O(1)
	for (int i = 1; i < n; i++) //O(n)
		for (int j = 1; j < i * i; j++) // O(n^2 - 1)
			if (j % i == 0) // will never be zero i is always 1 more than j thus % != 0
				for (int k = 0; k < j; k++) // O(n)
					sum++;  //O(1)

	cout << sum << endl;
	//analysis:
	// O(1) * O(1) * O(n) * O(n^2 - 1)    *  (O(n^2) * O(1))   invalid, will never run this loop because of if statement
	//O(1) * O(n) * O(n^2 - 1)
	//Answer: O(n^3)
	
	

}

/*

CSIS 211 Midterm - Alogrithm Analysis

Implement the following six code fragments in the language of your choosing (Java or C++). For each algorithm give an analysis of the running time using Big-Oh notation

1. sum = 0
for( i = 0; i < n;  i++)
sum++

2. sum = 0;
for(i = 0; i < n; i++)
for(j = 0; j < n; j++)
sum++;

3. sum =0;
for(i = 0; i < n; i++)
for(j = 0;  j < n *n; j++)
sum++

4. sum = 0;
for(i = 0; i < n; i++)
for(j = 0; j < i; j++)
sum++;

5. sum = 0;
for(i = 0; i < n; i++)
for(j = 0; j < i * i; j++)
for(k = 0; k < j; k++)
sum++;

6.  sum = 0;
for(i = 1; i < n; i++)
for(j = 1; j < i * i; j++)
if(j % i == 0
for(k = 0; k < j; k++)
sum++
*/


/*
int main()
{
try
{
int i;
cout << "Welcome which Calculator would you like to use???" << endl;
cout << "1.) RPN Calculator (+,-,*,/, sine,cos,tan)" << endl;
cout << "2.) Infix Calculator (+,-,*,/, sine,cos,tan) " << endl;
cin >> i;

if (i == 1)
{
//RPNcalculator functions :

RPNCalculator calc;
calc.startRPN();
calc.printRPN();
}
else if (i == 2)
{
InfixCalculator Icalc;
Icalc.startInfix();
}
else
cout << "Sorry you have to enter either '1' or '2' for this program to work" << endl;

//RPNcalculator functions:

//RPNCalculator calc;
//calc.startRPN();
//calc.printRPN();


//Infixcalculator functions:
//InfixCalculator Icalc;
//Icalc.startInfix();
//Icalc.printInfix();
}

catch (calcError e)
{
cout << e.getMessage().c_str() << endl;
}


return 0;
}
*/

/*
int main()
{
try
{

cout << "****Int List****" << endl;
DblyLinkedList<int> list;
list.addNode(1);
list.addNode(2);
list.addNode(3);
list.addNode(4);
list.addNode(5);
list.addNFront(6); // should be printed last
list.insert(3, 13);

list.printList();
cout << endl;

list.deleteNode(3);
list.printList();
cout << endl;

//please choose 1 find function (not both at same time)
cout << list.Find(2) << endl;
cout << endl;
cout << list.reverseFind(4) << endl;

list.printListReverse();
cout << endl;

cout << "****String List****" << endl;
DblyLinkedList<string> lists;
lists.addNode("A");
lists.addNode("B");
lists.addNode("C");
lists.addNode("D");
lists.addNode("E");
lists.addNFront("Z"); // should be printed last
lists.insert("C", "X");

lists.printList();
cout << endl;

lists.deleteNode("C");
lists.printList();
cout << endl;

//please choose 1 find function (not both at same time)
cout << lists.Find("B") << endl;
cout << endl;
cout << lists.reverseFind("D") << endl;

lists.printListReverse();
cout << endl;

cout << "****Char List****" << endl;
DblyLinkedList<char> lst;
lst.addNode('A');
lst.addNode('B');
lst.addNode('C');
lst.addNode('D');
lst.addNode('E');
lst.addNFront('Z'); // should be printed last
lst.insert('C', 'X');

lst.printList();
cout << endl;

lst.deleteNode('C');
lst.printList();
cout << endl;

//please choose 1 find function (not both at same time)
cout << lst.Find('B') << endl;
cout << endl;
cout << lst.reverseFind('D') << endl;

lst.printListReverse();
cout << endl;


}
catch (DblyLinkedListError e)
{
cout << e.getMessage().c_str() << endl;
}

cout << endl;

try
{
cout << "****Stack Test****" << endl;

DblyLinkedList<BigDecimal> dl;
BigDecimal one, two, three, four, five;
one.equals("1.0");
dl.addNode(one);
two.equals("2.0");
dl.addNode(two);
three.equals("3.0");
dl.addNode(three);
four.equals("4.0");
dl.addNode(four);
five.equals("5.0");
dl.addNode(five);

Stack<BigDecimal> stk;
stk.push(one);
stk.push(two);
stk.push(three);
stk.push(four);
stk.push(five);

stk.printStack(); // doesnt work fully yet/ used to see there is elements in stack/que
cout << endl;
cout << (stk.peek()).toString() << endl; // stack is full
cout << endl;

cout << (stk.pop()).toString() << endl;
cout << (stk.pop()).toString() << endl;
cout << (stk.pop()).toString() << endl;
cout << (stk.pop()).toString() << endl;
cout << (stk.pop()).toString() << endl;

//stk.printStack(); // doesnt work fully yet/ used to see there is elements in stack/que
cout << endl;
stk.peek(); // stack is empty

}

catch (StackError e)
{
cout << e.getMessage().c_str() << endl;
}
cout << endl;

try
{
cout << "****Queue Test****" << endl;


DblyLinkedList<BigDecimal> d;
BigDecimal one, two, three, four, five;
one.equals("1.0");
d.addNode(one);
two.equals("2.0");
d.addNode(two);
three.equals("3.0");
d.addNode(three);
four.equals("4.0");
d.addNode(four);
five.equals("5.0");
d.addNode(five);

Queue<BigDecimal> q;
q.enqueue(one);
q.enqueue(two);
q.enqueue(three);
q.enqueue(four);
q.enqueue(five);

q.printQue(); // doesnt work fully yet/ used to see there is elements in stack/que
cout << endl;
cout << (q.peek()).toString() << endl; // que is full
cout << endl;

q.dequeue();
q.dequeue();
q.dequeue();
q.dequeue();
q.dequeue();
cout << endl;

q.printQue(); // doesnt work fully yet/ used to see there is elements in stack/que
cout << endl;
cout << (q.peek()).toString() << endl; // que is empty
}

catch (QueError e)
{
cout << e.getMessage().c_str() << endl;
}
cout << endl;

return 0;
}


/*
CSIS 211 Data Structures Assignment 7

In a previous learning unit of the lecture material linked lists are presented. This assignment is geared to get you working  more with lists, stacks, and queues. There are two tasks in this assignment you are going to have to work out.

Task 1. Doubly  Linked List Class

From the lecture material create a doubly linked list class. This class should be generic so that it will operate on any given type.

Your class should have the ability to add to the front, add to the rear, insert (you can insert before or after a node), delete, and find. Your list class should also implement functionality that will allow you traverse the list forward and backward.

As for the naming conventions and interface into the list I will leave all of that up to you.

Task 2. Stack and Queue

Using the linked list class you created in Task 1 create stack and queue classes. I will leave it up to you as to whether to use composition or inheritance but whatever way you choose to go you should be able to explain why you chose the relationship type you did.

The stack class should have the following interface

push
pop
peek
The queue should have the following interface

enqueue
dequeue
peek
Again I will leave it up to you as to the parameters to the functions and the return type. As usual please have good reasoning for why you have been doing things.

Task 3.

Test your Stack and Queue classes with the BigDecimal class. I will leave it up to you as to how you are to test things but make sure you document what you are doing.
*/
