/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rm109
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Methods extends JApplet implements ActionListener
{

    Container content = this.getContentPane();
    JLabel lblOutput = new JLabel ("Hello");
    JTextField tfNum = new JTextField(10);
    JButton btn = new JButton("Speak");
    
    @Override
    public void init()
    {
        content.setLayout(new FlowLayout());
        content.add(tfNum);
        content.add(lblOutput);
        content.add(btn);
        btn.addActionListener(this);
        
        
    }
    
    @Override
    public void actionPerformed(ActionEvent e) 
    {
        int val = Integer.parseInt(tfNum.getText());
        int sq = this.square(val);
        this.setMessage("The Square is " + sq);
    }
    private void sayGoodbye()
    {
        lblOutput.setText("Good Bye");
    }
    
    private int square(int x)
    {
        return x * x;
        
    }
    private void setMessage (String msg)
    {
        lblOutput.setText(msg);
        
    }
}
