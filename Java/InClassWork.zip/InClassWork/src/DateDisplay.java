/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Aaron
 */
import java.awt.*;
import java.applet.*;
import java.util.*;
import java.awt.event.*;
import java.text.*;
import javax.swing.*;


public class DateDisplay extends Applet implements Runnable
{
        
        static final int UPDATE_INTERVAL = 1000;
        private Thread thread;
       
        Font myFont = new Font("TimesRoman",Font.BOLD, 48);
	   
        public void init()
		{
                    
                    
                    this.setFont(myFont);
                    this.setForeground(Color.BLUE);
                    this.setBackground(Color.WHITE);
		
                }
		//Write your methods here
	   public void paint(Graphics g)
           {
               super.paint(g); 
               String sDate; 
               sDate = getDateString();
               int x;
               int y;
               x = getXPos(g,sDate);
               y = getYPos();
               g.drawString(sDate,x , y);
                                                                     
               
           }
               
          public String getDateString()
          {
             Date now = new Date();
             String strDate = DateFormat.getTimeInstance(DateFormat.MEDIUM).format(now);
             return strDate;
               
               
               
           }
          
          public int getXPos( Graphics g, String strDate)
          {
              FontMetrics fm = g.getFontMetrics();
              int strWidth = fm.stringWidth(strDate);
              int width = getSize().width;
              int pixle = (width - strWidth) / 2;
              return pixle;
              
          }
          
          public int getYPos()
          {                        
             int height = getSize().height;
             height = height - 10;
             return height;
          }

	   
	  // Do not modify the code below or your animation will not work properly
	  public void run()
	  {
		//Starts thread to establish repaint interval
		Thread me = Thread.currentThread();
		while (thread == me)
		{
		  repaint();
		  try
		  {
			//Sleep (or pause) interval set to 1,000 mSec
			thread.sleep(UPDATE_INTERVAL);
						  }catch(InterruptedException e)
						  {
							break;
						  }
		}
		thread = null;
	  }
	  public synchronized void stop()
	  {
		thread = null;
	  }
	  public void start()
	  {
		thread = new Thread(this);
		thread.setPriority(Thread.MIN_PRIORITY);
		thread.start();
	  }

    

   

   
}
