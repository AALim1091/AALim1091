/*
 *Aaron Lim
 * Lab 12
 * 0353402
 * CSIS-113B
 * May 5, 2013
 */

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class Lab13 extends JApplet implements ActionListener, MouseListener
{
  // ------------------------------------------------------------
  // 1. Create your fields
  // ------------------------------------------------------------
  //  a. Arrays
  //  -- A 3 x 3 array of JLabel objects. Call it grid
    JLabel[][] grid = new JLabel[3][3];
  //  -- A 3 x 3 array of chars. Call it game
    char[][] game = new char[3][3];
  //  b. Other graphical fields
  //  -- A JButton named restart
    JButton restart = new JButton("Restart");
  //  -- A JPanel named p
    JPanel p = new JPanel();
  //  -- A JLabel named status
    JLabel status = new JLabel("Welcome to tic-tac-toe");
  //  c. Primitive variables
  //  -- an int named numClicks  (number of clicks in game)
    int numClicks;
  //  -- a boolean named isDone  (set to false)
    boolean isDone = false;
  //  -- a boolean named isXTurn (set to true)
    boolean isXTurn = true;
    // Get a reference to the applet window
    Container content = getContentPane();
// COMPILER CHECK # 1
 
  // ------------------------------------------------------------
  // 2. The init() method
  // ------------------------------------------------------------
  public void init()
  {
     // a. Set the layout for the JApplet (BorderLayout()), send the container content the setLayout message
        content.setLayout(new BorderLayout());
 
      // b. Add and hook up the restart button  
           content.add(status, BorderLayout.NORTH);
    // c. Add your status label to the top of the applet
    //    -- Send the status label the setOpaque message passing a parameter of true
           status.setOpaque(true);
    //    -- Set background to yellow, foreground to blue
           status.setBackground(Color.yellow);
           status.setForeground(Color.BLUE);
    //    -- Set font to 12 point bold Helvetica
           Font font = new Font("Helvetica",Font.BOLD,12);
           status.setFont(font);
    // d. Initialize your main Panel
    //    -- set the layout (GridLayout(3, 3, 3, 3));
           p.setLayout(new GridLayout(3,3,3,3));
 
    //    -- set a nice font
 
    //    -- initialize the background to black
           p.setBackground(Color.BLACK);
    //    -- add the JPanel to the center of your applet
          content.add(p,BorderLayout.CENTER);
    // e. Create and initialize your JLabel objects
    //    -- Start with a nested loop (row, col)
          for(int row=0; row<3;row++)
          {
            for(int col=0;col<3;col++)
            {
    //    -- Inside the inner loop
    //       > Create a new JLabel object (blank), place in array
                grid[row][col]= new JLabel(" ",JLabel.CENTER);
    //         grid[row][col] = new JLabel(" ", JLabel.CENTER);
    //       > Attach a MouseListener to it
               grid[row][col].addMouseListener(this);
    //      > Send the JLabel the setOpaque message passing a paramter of true
               grid[row][col].setOpaque(true);
    //       > Set the background color (white)
                grid[row][col].setBackground(Color.WHITE);
    //         > Set the font of the JLabel to Change to a 32 point, bold Helvetica font
                 Font font2 = new Font("Helvetica", Font.BOLD, 32);
                grid[row][col].setFont(font2);
    //       > Add it to your JPanel
                   p.add(grid[row][col]);
    //       > Put a blank in each element of your game array
 
 
 
             game[row][col] = ' ';
 
 
 
 
            }
          }
           content.add(restart, BorderLayout.SOUTH);
           restart.addActionListener(this);
  }
// COMPILER CHECK # 2
  // ------------------------------------------------------------
  // 3. Handle the Mouse Clicked Event
  // ------------------------------------------------------------
  public void mouseClicked(MouseEvent e)
  {
    if (isDone) resetGame();
    JLabel clicked = (JLabel) e.getSource();
 
    next:
    for (int row = 0; row < 3; row++)
    {
      for (int col = 0; col < 3; col++)
      {
        if (clicked == grid[row][col])
        {
          // a. if text in clicked is not " "
          if(clicked.getText() != " ")
           {
                status.setText("Invalid Move");
          break next;
           }
          //    then print "Invalid Move" using status()
          //    and break next; [a labeled break]
          // b. if text in clicked is " " and isXTurn is true
          if(clicked.getText() == " "&& isXTurn== true)
          {
              clicked.setText("X");
              clicked.setForeground(Color.RED);
              game[row][col]= 'X';
              isXTurn= false;
          }
          //  -- set the text in clicked to "X"
          //  -- set the foreground in clicked to red
          //  -- set the game[row][col] to 'X'
          // c. Otherwise (previous two false)
          else if(clicked.getText()== " " && isXTurn == false)
          {
              clicked.setText("O");
              clicked.setForeground(Color.BLUE);
              game[row][col]='O';
              isXTurn = true;
          }
          //  -- set the text in clicked to "O"
          //  -- set the foreground to blue
          //  -- set the game[row][col] to 'O'
          // d. Toggle isXTurn, incrment numClicks
 
          // Check to see if game is over after each click
          gameOver();
        }
      }
    }
  }
// COMPILER CHECK # 3
  // ------------------------------------------------------------
  // 4. The resetGame() method
  // ------------------------------------------------------------
  void resetGame()
  {
    // a. Write a nested for loop (row, col)
      for(int row = 0; row <3; row++)
      {
          for(int col=0; col<3;col++)
          {
              grid[row][col].setText(" ");
              game[row][col] = ' ';
          }
      }
    // b. For each element in grid, set text to " "
    // c. For each element in game, set value to ' '
    // d. Set numClicks to zero
    int  numclicks = 0;
    // e. Set isXTurn to true
    isXTurn = true;
  }
// COMPILER CHECK # 4
  // ------------------------------------------------------------
  // The actionPerformed() method (resets the game)
  // ------------------------------------------------------------
  public void actionPerformed(ActionEvent ae)
  {
    resetGame();
  }
  // ------------------------------------------------------------
  // The gameOver() method [see if there is a winner]
  // ------------------------------------------------------------
  void gameOver()
  {
    char winner = ' ';
    //  Check values in array named game
    // a. Check the first diagonal (upper-left to lower right)
    //    Set winner to upper-left if all are equal.
    if (game[0][0] == game[1][1] &&
        game[1][1] == game[2][2])
      winner = game[0][0];
    // b. if no winner, then check second diagonal
    //    (lower-left to upper-right). If all three are the
    //    same then winner is lower-right corner
    else if (game[2][0] == game[1][1] &&
             game[1][1] == game[0][2])
      winner = game[2][0];
    // c. if no winner on diagonals, then check rows
    //    -- start by creating a loop for rows
    //    -- on each row check if all three columns are same
    //    -- if they are, then winner is game[i][0]
    //    -- if not, use rows to represent the columns
    //       and check if each row is the same
    else
    {
      for (int row = 0; row < 3; row++)
      {
        if (game[row][0] != ' ' &&
            game[row][0] == game[row][1] &&
            game[row][1] == game[row][2])
          winner = game[row][0];
        else if (game[0][row] != ' ' &&
                 game[0][row] == game[1][row] &&
                 game[1][row] == game[2][row])
          winner = game[0][row];
      }
    }
    // Assume game is finished
    isDone = true;
    // Check for tie
    if (winner == ' ' && numClicks == 9)
      status.setText("Tie Game");
    // Check for game done
    else if (winner != ' ')
      status.setText("Game Over: " + winner + " Won!!!");
    // Otherwise a continuing game
    else
    {
      status.setText((isXTurn ? "X's Turn" : "O's Turn"));
      isDone = false;
    }
  }
  // -------------------------------------------------------
  //  Dummy methods for MouseListener interface
  // -------------------------------------------------------
  public void mouseEntered(MouseEvent e)  { }
  public void mouseExited(MouseEvent e)   { }
  public void mousePressed(MouseEvent e)  { }
  public void mouseReleased(MouseEvent e) { }
}