/*
 *Aaron Lim
 * Lab 10
 * CSIS-113B
 * April 16, 2013
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.text.*;
import java.util.*;
import java.net.URL;
import java.util.Random;

public class Dice extends JApplet implements ActionListener
{
   
    Container content = getContentPane();
    
    Font font = new Font("TimesRoman",Font.BOLD,28);
 
    JLabel lblTxt = new JLabel("Roll the dice, Test your luck");
    JLabel  lblBank = new JLabel();
    JLabel die = new JLabel();
  
    JTextField tfBet = new JTextField(10);
    JTextField tfGuess = new JTextField(10);
  
    JButton play = new JButton("Play");
    JLabel lblStatus = new JLabel(); 
    
    Border blackBorder = BorderFactory.createLineBorder(Color.BLACK);
    double bank = 100.00;
   
    private URL image;
  
    public void init()
    {
       content.setLayout(new BorderLayout());
     
       lblTxt.setFont(font);
       lblTxt.setForeground(Color.BLUE);
       content.add(lblTxt,BorderLayout.NORTH);
       lblTxt.setHorizontalAlignment(SwingConstants.CENTER);
  
       JPanel pDice = new JPanel();
    
       content.add(pDice,BorderLayout.CENTER);
       pDice.add(die);
       pDice.setLayout(new FlowLayout());
     
       JPanel p2 = new JPanel();
       content.add(p2, BorderLayout.SOUTH);
       p2.setLayout(new GridLayout(4,2,5,5));
       
       p2.add(new JLabel("Your Bank: "));
       p2.add(lblBank);     
       lblBank.setEnabled(false);
       lblBank.setBackground(Color.WHITE);
       lblBank.setBorder(blackBorder);
       lblBank.setEnabled(false);
       lblBank.setBackground(Color.WHITE);
     
       p2.add(new JLabel("Your Bet: "));
       p2.add(tfBet);
       p2.add(new JLabel("Your Guess: "));
       p2.add(tfGuess);
     
       p2.add(play);
       p2.add(lblStatus);
       play.addActionListener(this);
       setImage(rollDice());
       lblBank.setText("$100.00");
      
    }
      
    @Override
    public void actionPerformed(ActionEvent e)
    {
       int r =rollDice();
       double bet = Double.parseDouble(tfBet.getText());
       double guess = Double.parseDouble(tfGuess.getText());
       lblStatus.setForeground(Color.RED);
     
       NumberFormat fmt = NumberFormat.getCurrencyInstance();
       lblBank.setText(fmt.format(bank));
       setImage(r);
       if(bank <= 0.0)
       {
           lblStatus.setText("Sorry you are broke");
       }
       else if (bet > bank)
       {
           lblStatus.setText("Sorry, bet is too big");
       }
                              
      else if(guess == r)
       {
           lblStatus.setText("Winner, pays: " + bet);
            bank += bet;
            lblBank.setText(""+ bank);
       }
      else if (guess != r)
       {
           lblStatus.setText("Loser, house wins: " + bet);
           bank -= bet;
           lblBank.setText(""+ bank);
       }
       
                 
    }
  
protected URL getURL(String filename)
    {
     URL codeBase = getCodeBase();
     URL url = null;
 
         try
     {
        url = new URL(codeBase, filename);
     }
     catch (java.net.MalformedURLException e)
    {
         return null;
    }
    return url;
    }
public void loadImage1()
{
  try
    {
   image = getURL("Die1.png");
   ImageIcon Die1 = new ImageIcon(image);
   die.setIcon(Die1);
    }
    catch(Exception ex){}
}

    public void loadImage2()
{
  try
    {
   image = getURL("Die2.png");
   ImageIcon Die2 = new ImageIcon(image);
   die.setIcon(Die2);
    }
    catch(Exception ex){}
}
  
    public void loadImage3()
{
  try
    {
   image = getURL("Die3.png");
   ImageIcon Die3 = new ImageIcon(image);
   die.setIcon(Die3);
    }
    catch(Exception ex){}
}
  
  
    public void loadImage4()
{
  try
    {
   image = getURL("Die4.png");
   ImageIcon Die4 = new ImageIcon(image);
   die.setIcon(Die4);
    }
    catch(Exception ex){}
}
  
  
    public void loadImage5()
{
  try
    {
   image = getURL("Die5.png");
   ImageIcon Die5 = new ImageIcon(image);
   die.setIcon(Die5);
    }
    catch(Exception ex){}
}
  
  
    public void loadImage6()
{
  try
    {
   image = getURL("Die6.png");
   ImageIcon Die6 = new ImageIcon(image);
   die.setIcon(Die6);
    }
    catch(Exception ex){}
}
    public int setImage(int die)
    {
  
        switch(die)
        {
            case 1:
               loadImage1();
                break;
            case 2:
                loadImage2();
                break;
            case 3:
                loadImage3();
                break;
            case 4:
                loadImage4();
                break;
            case 5:
                loadImage5();
                break;
            case 6:
                loadImage6();
                break;
          
           
        }
    return 0;
    }
public int rollDice()
{
 Random r = new Random();
 int roll = r.nextInt(6) + 1;
 
 return roll;
}
}
