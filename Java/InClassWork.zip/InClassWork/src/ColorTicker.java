/*
 *Aaron Lim
 * Lab 11
 * CSIS-113B
 * April 21, 2013
 */
import java.awt.*;
import java.applet.*;

public class ColorTicker extends Applet
{   
    String motd = new String ("The true sign of intelligence is not knowledge but imagination."); //"The true sign of intelligence is not knowledge but imagination."
    int waitTime = 100;
    int stepRed = 2;
    int stepBlue = 3;
    int stepGreen = 7;
    Color msgColor = (Color.PINK);
   
    public void init()
    {
        String fontName = ("TimesRoman");
        int fontSize = 36;
        Font myFont = new Font(fontName,Font.BOLD,fontSize);
        this.setFont(myFont);
       
        String message = this.getParameter("message");
        if(message == null)
        {
            message = motd;
        }
        else
        {
            motd = message;
        }
       
        String red = this.getParameter("stepRed");
        if(red == null)
        {
           message = motd;
        }
            else
        {
          stepRed = Integer.parseInt(red);
        }
      
        String blue = this.getParameter("stepBlue");
        if(blue == null)
        {
            message = motd;
        }
        else
        {
          stepBlue = Integer.parseInt(blue);
        }
       
        String green = this.getParameter("stepGreen");
        if(green == null)
        {
            message = motd;   
        }
        else
        {
          stepGreen = Integer.parseInt(green);
        }
       
        String fontsize = this.getParameter("fontSize");
        if(fontsize == null)
        {
            message = motd;
        }
        else
        {
          fontSize = Integer.parseInt(fontsize);
        }
        String fontname = this.getParameter("fontName");
        if(fontname == null)
        {
          message = motd;
        }
        else
        {
            motd = fontName;
        }
       
        String waittime = this.getParameter("waitTime");
        if(waittime == null)
        {
            message = motd;
        }
        else
        {
          waitTime = Integer.parseInt(waittime);
        }
     
 

       
    }
    public void paint(Graphics g)
    {
        FontMetrics fm = g.getFontMetrics();
       
        int pixWidth = fm.stringWidth(motd);
        int appWidth = getSize().width;
        int xPos = (appWidth - pixWidth) / 2;
       
        int yPos = getSize().height;
        yPos = yPos - 25;
       
        int len = motd.length();
       
        int red = msgColor.getRed();
        int blu = msgColor.getBlue();
        int grn = msgColor.getGreen();
       
        for(int i = 0; i < len ; i++)
        {
          
            red += stepRed;
            blu += stepBlue;
            grn += stepGreen;
           
            red %= 255;
            blu %= 255;
            grn %= 255;
           
            msgColor = new Color(red,blu,grn);
            g.setColor(msgColor);
           
           
           
           
          char ch = motd.charAt(i);
          g.drawString("" + ch,xPos,yPos);
          xPos += fm.charWidth(ch);
         
         
          
        }
  
        char first = motd.charAt(0);
        String r = motd.substring(1);
        motd = r + first;
       
       
        try
        {
           
        Thread.sleep(waitTime);
       
        }
        catch(InterruptedException e)
        {
       
        }
       
        repaint();
       
       
       
       
       
       
    }
   
}
