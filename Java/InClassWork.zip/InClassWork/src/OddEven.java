/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Aaron
 */
import java.awt.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.text.*;
import java.util.*;

public class OddEven extends JApplet implements ActionListener
{
    TextField tfInput = new TextField(10);
    JLabel lblOutput = new JLabel();
    JButton btnCompute = new JButton("Compute");
    Container content = this.getContentPane();
    public void init()
    {
     content.setLayout (new FlowLayout());
     content.add(new JLabel("Enter a Number: "));
     content.add(tfInput);
     content.add(lblOutput);
     content.add(btnCompute);
     btnCompute.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
      int num = Integer.parseInt(tfInput.getText());
      if(num % 2 == 0)
      {
          lblOutput.setText("That is an Even Number");
      }
      else
      {          
          lblOutput.setText("That is an Odd Number");
      }
      
    }
    
    
    
    
    
    
    
}
