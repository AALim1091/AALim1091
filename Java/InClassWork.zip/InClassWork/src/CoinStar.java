/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rm109
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class CoinStar extends JApplet implements ActionListener
{
    JTextField tfPennies = new JTextField (10);
    JTextField tfNickels = new JTextField (10);
    JTextField tfDimes = new JTextField (10);
    JTextField tfQuarters = new JTextField (10);
    JLabel lblDollars = new JLabel ();
    JButton btnCalculate = new JButton ("Calculate");
    
    Container content =getContentPane();
    
    public void init()
    {
        content.setLayout(new GridLayout (5,2));
        content.add(new JLabel("Pennies"));
        content.add (tfPennies);
        content.add(new JLabel("Nickles"));
        content.add (tfNickels);
        content.add(new JLabel("Dimes"));
        content.add (tfDimes);
        content.add(new JLabel("Quarters"));
        content.add (tfQuarters);
        content.add(btnCalculate);
        content.add(lblDollars);
        btnCalculate.addActionListener(this);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
      double pennies = Double.parseDouble(tfPennies.getText());
      double nickels = Double.parseDouble(tfNickels.getText()) * 5;
      double dimes = Double.parseDouble(tfDimes.getText()) * 10;
      double quarters = Double.parseDouble(tfQuarters.getText()) * 25;
      
      double totPennies = pennies + nickels + dimes + quarters;
      double totDollars = totPennies / 100;
      
      lblDollars.setText("$" +totDollars);
      
      
    }
    
}
