/*
 *Aaron Lim
 * Lab 12
 * 0353402
 * CSIS-113B
 * April 30, 2013
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.text.*;
import java.util.*;
import java.net.URL;
import java.util.Random;

public class Lab12 extends JApplet implements Runnable, ActionListener
{
    Thread theThread = null;
    Container content = this.getContentPane();
    
    
    JLabel lblRed = new JLabel("Red");
    JLabel lblGreen = new JLabel("Green");
    JLabel lblBlue = new JLabel("Blue");
    
    JTextField tfRed = new JTextField(10);
    JTextField tfGreen = new JTextField(10);
    JTextField tfBlue = new JTextField(10);
    
    JLabel lblIt = new JLabel("Iterations");
    JLabel lblAmount = new JLabel("Step Amount");
    JLabel lblDelay = new JLabel("Delay");
    
    JTextField tfIt = new JTextField(10);
    JTextField tfAmount = new JTextField(10);
    JTextField tfDelay = new JTextField(10);
    
    JCheckBox cbRed = new JCheckBox("Red");
    JCheckBox cbGreen = new JCheckBox("Green");
    JCheckBox cbBlue = new JCheckBox("Blue");
    
    JButton btnStart = new JButton("Start");
    JLabel lblColor = new JLabel("");

public void init()
{
    content.setLayout(new BorderLayout());
    
    JPanel p1 = new JPanel();
    p1.setLayout(new GridLayout(4,3,5,5));
    content.add(p1,BorderLayout.CENTER);
    p1.add(lblRed);
    p1.add(lblGreen);
    p1.add(lblBlue);
    p1.add(tfRed);
    p1.add(tfGreen);
    p1.add(tfBlue);
    p1.add(lblIt);
    p1.add(lblAmount);
    p1.add(lblDelay);
    p1.add(tfIt);
    p1.add(tfAmount);
    p1.add(tfDelay);
    
    JPanel p2 = new JPanel();
    p2.setLayout(new GridLayout(2,3,2,2));
    content.add(p2,BorderLayout.SOUTH);
    p2.add(cbRed);
    p2.add(cbGreen);
    p2.add(cbBlue);
    p2.add(btnStart);
    btnStart.addActionListener(this);
    
    p2.add(lblColor);
    lblColor.setOpaque(true);

            
    
    cbRed.setSelected(true);
    cbGreen.setSelected(true);
    cbBlue.setSelected(true);

       
    tfRed.setText("40");
    tfGreen.setText("50");
    tfBlue.setText("60");
    tfIt.setText("10");
    tfAmount.setText("20");
    tfDelay.setText("1000");
    
    
    
}
    @Override
    public void run()
    {
        int R = Integer.valueOf(tfRed.getText());
        int G = Integer.valueOf(tfGreen.getText());   
        int B = Integer.valueOf(tfBlue.getText());
        
        int It = Integer.parseInt(tfIt.getText());
        int Amt = Integer.parseInt(tfAmount.getText());
        int Delay = Integer.parseInt(tfDelay.getText());
        
        for(int i = 0; i <= It ; i++)
        {
           if(cbRed.isSelected() == true)
           {
              R += Amt;
           }
           if(R > 255)
           {
              R = 0;
           }
              
           if(cbGreen.isSelected() == true)
           {
              G += Amt;
           }
           if(G > 255)
           {
              G = 0;
           }
        
           if(cbBlue.isSelected() == true)
           {
              B += Amt;
           }
           if(B > 255)
           {
              B = 0;
           }
        
        
                try
                {
                Thread.sleep(Delay);
                }
                    catch(InterruptedException ex)
                    {
   
                     }
        
            lblColor.setText("" + R + "," + G + "," + B);
            Color color = new Color (R,G,B);
            lblColor.setOpaque(true); 
            lblColor.setBackground(color);
   
   
         
                }
    
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
    if(theThread==null)
      {
         
      theThread = new Thread(this);
      theThread.start();
      btnStart.setText("Stop");
      }
    else
      {
     theThread.stop();
      theThread = null;
      btnStart.setText("Start");
      }
        
    }
    
    
}
