/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Aaron
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.text.*;
import java.util.*;

public class MyColor extends JApplet implements ActionListener
{
    JLabel lblHello = new JLabel("Hello");
    Container content =this.getContentPane();
    JButton btnGreen = new JButton ("Green");
    JButton btnBlue = new JButton ("Blue");

    public void init()
    {
        content.setLayout( new FlowLayout());
        Font fnt = new Font("TimesRoman", Font.BOLD, 42);
        lblHello.setFont(fnt);
        content.add(lblHello);
        content.add(btnGreen);
        content.add(btnBlue);
        btnGreen.addActionListener(this);
        btnBlue.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == btnGreen)
        {
            lblHello.setForeground(Color.GREEN);
        }
        else
        {
            lblHello.setForeground(Color.BLUE);
        }
       
       
    }
   
}

