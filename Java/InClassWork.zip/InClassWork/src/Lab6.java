 /*
 *Aaron Lim
 * Lab 3
 * CSIS-113B
 * March 4, 2013
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Lab6 extends JApplet implements ActionListener
{
    Container content = this.getContentPane();
    
    JTextField Num = new JTextField(10);
    JTextField AVal = new JTextField(10);
    JTextField Cubert = new JTextField(10);
    JTextField Squarert = new JTextField(10);
    JTextField Expo = new JTextField(10);
    JTextField Log = new JTextField(10);
    JTextField Log10 = new JTextField(10);
    JTextField Bin = new JTextField(10);
    JTextField Hex = new JTextField(10);
    JButton btnCalc = new JButton ("Calculate");
    
    public void init()
    {
        content.setLayout(new GridLayout(10,2,10,5));
        content.add(new JLabel("Enter a Number", JLabel.RIGHT));
        content.add(Num);
        content.add(new JLabel("Absolute Value", JLabel.RIGHT));
        content.add(AVal);
        content.add(new JLabel("Cube Root", JLabel.RIGHT));
        content.add(Cubert);
        content.add(new JLabel("Square Root", JLabel.RIGHT));
        content.add(Squarert);
        content.add(new JLabel("Exponent", JLabel.RIGHT));
        content.add(Expo);
        content.add(new JLabel("Log", JLabel.RIGHT));
        content.add(Log);
        content.add(new JLabel("Log 10", JLabel.RIGHT));
        content.add(Log10);
        content.add(new JLabel("Binary", JLabel.RIGHT));
        content.add(Bin);
        content.add(new JLabel("Hex", JLabel.RIGHT));
        content.add(Hex);
        content.add(btnCalc);
        btnCalc.addActionListener(this);
        
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        double a = Double.parseDouble (Num.getText());
        double b = Math.abs(a);
        double c = Math.cbrt(a);
        double d = Math.sqrt(a);
        double x = Math.exp(a);
        double f = Math.log(a);
        double g = Math.log10(a);
        double h = Math.round(a);
        int bin =(int)Math.round(h);
        String binStr = Integer.toBinaryString(bin);
        double i = Math.round(a);
        int hex =(int)Math.round(i);
        String hexStr = Integer.toHexString(hex);
         
        AVal.setText("" + b);
        Cubert.setText("" + c);
        Squarert.setText("" + d);
        Expo.setText("" + x);
        Log.setText("" + f);
        Log10.setText("" + g);
        Bin.setText("" + binStr);
        Hex.setText("" + hexStr);
                      
        AVal.setEnabled(false);
        Cubert.setEnabled(false);
        Squarert.setEnabled(false);
        Expo.setEnabled(false);
        Log.setEnabled(false);
        Log10.setEnabled(false);
        Bin.setEnabled(false);
        Hex.setEnabled(false);
        
    }
    
    
    
    
    
    
}