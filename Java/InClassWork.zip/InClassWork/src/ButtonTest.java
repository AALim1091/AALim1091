/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rm109
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
 
public class ButtonTest extends JApplet implements ActionListener
{
   
    JButton btnOK = new JButton ("click ME");
    JLabel lblName = new JLabel ("Aaron Lim");
    Container content = getContentPane();
    
    public void init ()
    {
        
      content.setLayout(new FlowLayout());
      content.add(lblName);
      btnOK.addActionListener(this);
      content.add(btnOK);  
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
      lblName.setText("Stop Clicking ME!");  
    }
   
}
