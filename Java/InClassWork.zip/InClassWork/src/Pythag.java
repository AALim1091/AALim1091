/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rm109
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Pythag extends JApplet implements ActionListener
{
    Container content = this.getContentPane();
    JTextField tfA = new JTextField(10);
    JTextField tfB = new JTextField(10);
    JLabel lblC = new JLabel();
    JButton btnCalc = new JButton ("Calculate");
    
    public void init()
    {
        content.setLayout (new FlowLayout ());
        content.add (new JLabel ("A:"));
        content.add(tfA);
        content.add (new JLabel ("B:"));
        content.add(tfB);
        content.add (new JLabel ("="));
        content.add(lblC);
        content.add(btnCalc);
        btnCalc.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) 
    {
        double a = Double.parseDouble (tfA.getText());
        double b = Double.parseDouble (tfB.getText());
        
        a = Math.pow(a, 2.0);
        b = Math.pow(b, 2.0);
        double sqSum = a + b;
        double sqrt = Math.sqrt (sqSum);
        lblC.setText("" + sqrt);
        
    }
    
}
