/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rm109
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.text.*;
import java.util.*;

public class Game extends JApplet implements ActionListener
{
    Container content = this.getContentPane();
    JTextField tfGuess = new JTextField(10);
    JLabel lblBank = new JLabel();
    JButton btnPlay = new JButton ("Play");
    JLabel lblStatus = new JLabel();
    
    double bank = 10.0;
    
    
    public void init()
    {
        content.setLayout(new GridLayout(3,2));
        content.add(new JLabel("Guess: "));
        content.add(tfGuess);
        
        Border blackBorder = BorderFactory.createLineBorder(Color.BLACK,1);
        lblBank.setBorder(blackBorder);
        lblBank.setOpaque(true);
        lblBank.setBackground(Color.WHITE);
        
        content.add(new JLabel ("Bank: "));
        content.add(lblBank);
        content.add(btnPlay);
        content.add(lblStatus);
        this.outputBank();
        btnPlay.addActionListener(this);
        
    }
    
    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (bank <= 0.0)
        {
            lblStatus.setText("Sorry You are out of money");
            return;
        }
        Random r = new Random();
        int dice = r.nextInt(6) + 1;
        int guess = Integer.parseInt(tfGuess.getText());
        
        
        if(guess == dice)
        {
            bank += 2.0; // winner adds two to the bank
            lblStatus.setText("Winner dice rolled " + dice);
        }
        else
        {
            bank -= 1;
            lblStatus.setText("You lose dice rolled " + dice);
        }
        outputBank();
        tfGuess.requestFocus();
        tfGuess.selectAll();
    }
    
    public void outputBank()
    {
        NumberFormat fmt = NumberFormat.getCurrencyInstance();
        lblBank.setText(fmt.format(bank));
    }
}
