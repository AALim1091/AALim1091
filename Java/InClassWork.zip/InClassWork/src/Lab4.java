/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rm109
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Lab4 extends JApplet implements MouseListener
{
    JLabel lblName = new JLabel ("Aaron Lim");
    Font myFont = new Font("TimesRoman",Font.BOLD, 48);
    
    Color onC = new Color (55,120,200);
    Color offC = new Color (0,25,180);
    Container content = getContentPane();
    public void init()
    {
       content.setBackground(onC);
       lblName.setForeground(offC);
       content.add(lblName);
       content.addMouseListener(this);
    }
     public void mousePressed(MouseEvent e)
     {

     }

    public void mouseReleased(MouseEvent e)
    {

    }

    public void mouseEntered(MouseEvent e)
    {
       lblName.setText("Hello");
       lblName.setForeground(onC);
       content.setBackground(Color.BLACK);
       

    }

    public void mouseExited(MouseEvent e)
    {
       lblName.setText("Goodbye");
       lblName.setForeground(offC);
       content.setBackground(Color.yellow);

    }

    public void mouseClicked(MouseEvent e)
    {

    }


}
