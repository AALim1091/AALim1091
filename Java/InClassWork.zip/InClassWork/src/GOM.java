/*
 *Aaron Lim
 * Lab 9
 * CSIS-113B
 * April 4, 2013
 */
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import java.awt.*;

public class GOM extends JApplet implements ActionListener
{
  // ------------------------------------------------------
  // 1. Attributes
  // ------------------------------------------------------

  // a. Top Panel components
    JTextField theGuess = new JTextField(10);
    JLabel bankRoll = new JLabel("100.00 Zipoids");

  // b. Bottom Panel components
    JButton newPlayer = new JButton("New Player");
    JButton newNumber = new JButton("New Number");
    JTextField thePlayer = new JTextField(20);
    
  // c. Center Panel components
    JTextArea theOutput = new JTextArea();
  // d. Other attributes
    String playerName;
    int theNumber = 20;
    int numTries = 0;
    int numGames = 0;
    double amtRemaining = 100.0;
    Random randomizer = new Random();
    
    
  // COMPILE CHECK # 1 HERE

  // ------------------------------------------------------
  // 2. Initialization
  // ------------------------------------------------------
  Container content = this.getContentPane();

  public void init()
  {
    System.out.println("init() method called.");

    // a. Set the layout to border layout
      content.setLayout(new BorderLayout());
    // b. Add components to the top of the applet
       JPanel p1 = new JPanel();
       JLabel guess = new JLabel("Make your guess :");
       p1.add(guess);
       p1.add(theGuess);
       p1.add(bankRoll);
       content.add(p1,BorderLayout.NORTH);
       
    // c. Add components to the south of the applet
       JPanel p2 = new JPanel();
       p2.add(newPlayer);
       p2.add(thePlayer);
       p2.add(newNumber);
       content.add(p2,BorderLayout.SOUTH);
    // d. Add some spacers to the east and west
       JLabel dummy1 = new JLabel();
       JLabel dummy2 = new JLabel();
       content.add(dummy1,BorderLayout.WEST);
       content.add(dummy2,BorderLayout.EAST);
       JScrollPane scrollArea = new JScrollPane(theOutput);
    // e. Add the output to the Center
       content.add(scrollArea,BorderLayout.CENTER);
    // f. addActionListener to thePlayer, theGuess, newPlayer, newNumber
       thePlayer.addActionListener(this);
       theGuess.addActionListener(this);
       newPlayer.addActionListener(this);
       newNumber.addActionListener(this);
    // g. Call the newPlayer() method
        newPlayer();
    // COMPILE CHECK # 2 HERE
  }

  // ------------------------------------------------------
  // 3. The newPlayer() Method
  // ------------------------------------------------------
  private void newPlayer()
  {
    System.out.println("newPlayer() method called.");

    // a. Ask user to enter name and press ENTER
    theOutput.setText("");
    theOutput.append("Enter your name \nPress ENTER key to start playing");
    

    // b. Disable all components except for thePlayer
        theOutput.setEnabled(false);
        theGuess.setEnabled(false);
        newPlayer.setEnabled(false);
        newNumber.setEnabled(false);
    // c. Enable thePlayer, set it's text to ""
        thePlayer.setEnabled(true);
        thePlayer.setText("");        
    // d. Set theGuess background to white
        theGuess.setBackground(Color.WHITE);
    //    Set thePlayer background to yellow
        thePlayer.setBackground(Color.YELLOW);
        
    //    Set focus on the player
        thePlayer.requestFocus();
        thePlayer.selectAll();

    // COMPILE CHECK # 3 HERE
  }

  // ------------------------------------------------------
  // 4. The actionPerforme() Method
  // ------------------------------------------------------
  public void actionPerformed(ActionEvent e)
  {
    System.out.println("action() method called.");

    // a. Handle the newPlayer Button    
    //    If the newPlayer button was pressed
    //      Then call the newPlayer method
    if(e.getSource() == newPlayer)
    {
    newPlayer();	
    }

    // b. Handle thePlayer TextField
    //    If thePlayer TextField generated the event
    //      Then call the addPlayer() method
    else if(e.getSource() == thePlayer)
    {
        addPlayer();
    }
    // c. Handle the newNumber Button
    //    If the newNumber button was pressed
    //      Call the newGame() method
    else if(e.getSource() == newNumber)
    {    
        newGame(); 
    //      Enable theGuess component
        theGuess.setEnabled(true);
    //      Set focus to theGuess textfield
        theGuess.requestFocus();
        theGuess.selectAll();
    //      Set background color of theGuess to yellow
        theGuess.setBackground(Color.YELLOW);
    }
    // d. Handle theGuess TextField
    //    If this TextField theGuess generated the event
    //      Call the newGuess() method
    
    else if(e.getSource()== theGuess)
    {
        newGuess();
    }
    // COMPILE CHECK # 4 HERE

  }

  // ------------------------------------------------------
  // 5. The addPlayer() Method
  // ------------------------------------------------------
  private void addPlayer()
  {
    System.out.println("addPlayer() method called.");

    // a. Retrieve text from thePlayer, store in playerName
    playerName = thePlayer.getText();
    


    // b. Check to see if playerName is ""
      // If it is, then:
      //    Print error message to theOutput
     if(playerName.equals(""))
     {
         theOutput.setText("");
         theOutput.append("Sorry,You must enter a name to play \nEnter your name \nPress ENTER key to start playing");
     }
     else
     {
      // If not then:
      //    1. Set the amount remaining to 100
         amtRemaining = 100;
      //    2. Set the number of games played to 0
         numGames = 0;
      //    3. Call the newGame() method
         newGame();
      //    4. Call the updateScore() method
         updateScore();
      //    5. Disable thePlayer TextField. Set its
      //       background color to white
         thePlayer.setEnabled(false);
         thePlayer.setBackground(Color.WHITE);
      //    6. Enable all other components.
         newPlayer.setEnabled(true);
         newNumber.setEnabled(true);
         theGuess.setEnabled(true);

      //    7. Set focus to theGuess textfield
         theGuess.requestFocus();
         theGuess.selectAll();
      //    8. Set background color of theGuess to yellow
         theGuess.setBackground(Color.YELLOW);
     }
      // COMPILE CHECK # 5 HERE
  }

  // ------------------------------------------------------
  // 6. The newGame() Method
  // ------------------------------------------------------
  private void newGame()
  {
    System.out.println("newGame() method called");

    // a. Increment the number of games played [numGames]
        numGames++;
    // b. Calculate a random number between 0 and 100
    //    Store the random number in the field theNumber
    //    Use your Random object [randomizer] to generate
    //    the number, using the instructions from class
        theNumber = Math.abs(randomizer.nextInt(100) + 1);
    // c. Set the number of tries to 0 [numTries]
       numTries = 0;
    // d. Call the displayInstructions() method
        displayInstructions();
        amtRemaining -= 1;
        updateScore();
    // COMPILE CHECK # 6 HERE
  }


  // ------------------------------------------------------
  // 7. The displayInstructions() Method
  // ------------------------------------------------------
  private void displayInstructions()
  {
    System.out.println("displayInstructions() method called");

    // a. Run the sample applet and read instructions
    //    displayed on the screen after name is typed
    theOutput.setText("");
       theOutput.append("I'm Guessing a number between 0 and 100 "
               + "\n If you guess the number in fewer than 9 tries,you'll earn"
               + "\n                               1 try    2.00 Zipoids"
               + "\n                               2 tries  1.75 Zipoids"               
               + "\n                               3 tries  1.50 Zipoids"
               + "\n                               4 tries  1.25 Zipoids"
               + "\n                               5 tries  1.00 Zipoids"
               + "\n                               6 tries  0.75 Zipoids"
               + "\n                               7 tries  0.50 Zipoids"
               + "\n                               8 tries  0.25 Zipoids" );
    // b. Use the necessary TextArea methods to display
    //    those instructions in the center of the screen
       

    // COMPILE CHECK # 7 HERE
  }

  // ------------------------------------------------------
  // 8. The updateScore() Method
  // ------------------------------------------------------
  private void updateScore()
  {
    System.out.println("updateScore() method called");

    // a. Set the text in thePlayer textfield to the
    //    player's name [playerName], along with the
    //    the number of the current game [numGames]
          thePlayer.setText(playerName +(", Game # " + numGames));

    // b. Set the text in the bankRoll Label to the
    //    amount remaining in the player's account
    //    amtRemaining
          bankRoll.setText(amtRemaining + " Zipoids");
    // COMPILE CHECK # 8 HERE
  }

  // ------------------------------------------------------
  // 9. The newGuess() Method
  // ------------------------------------------------------
 private void newGuess()
  {
    System.out.println("newGuess() method called.");

      // a. Retrieve the text from theGuess
        String curStr = theGuess.getText();
      // b. Convert the text to a local int [curGuess]
        int curGuess = Integer.parseInt(curStr);
      // c. Increment the number of tries
        numTries ++;
      // d. Print the number of guesses and the current guess
      //    to theOutput
        theOutput.append("\nGuess " + numTries + "=" + curGuess);
      // e. Test to see if curGuess is equal to theNumber
        if(curGuess == theNumber)
        {
      //    If so, then:
      //      Call the method gameWon()
            gameWon();
        }
      //    Otherwise:
      //      Test to see if curGuess is greater than theNumber.
        else if(curGuess > theNumber)
        { 
      //      If so then
      //        Print "Sorry, too high. Try lower"
            
            theOutput.append(" \nSorry, too high. Try lower");
            
        }
      //      Otherwise
      //        Print "Sorry, too low. Try higher"
        else if (curGuess != theNumber)
        {
            
            theOutput.append(" \nSorry, too low. Try higher");
        }

      //      Set the focus to theGuess text field
        theGuess.requestFocus();
      //      Set the background color of the field to yellow
        theGuess.setBackground(Color.YELLOW);
      //      Select all of the text in the text field
        theGuess.selectAll();
      // COMPILE CHECK # 9 HERE
  }


  // ------------------------------------------------------
  // 10. The gameWon() Method
  // ------------------------------------------------------
  private void gameWon()
  {
    System.out.println("gameWon() method called");

    // a. Print "************** WINNER ***************"
    //    Clear the screen when this is printed.
    theOutput.setText("");
        theOutput.append("******* WINNER ********");

    // b. Print out the amount wagered (always 1 Zipoid)
    //    and the number of tries
        theOutput.append("\n Wagered: 1 Zipoid");
        theOutput.append("\nNumber of Tries: " + numTries);
    // c. Calculate the current winnings using a switch
    //    statment. Use the field numTries in your
    //    switch statement. If numTries is 1, then the
    //    current winnings is 2, if 2 the 1.75, etc. Store
    //    the current winnings in a local variable
        String output;
        switch(numTries)
        {
            case 1:
                output = "2.00";
                    break;
            case 2:
                output = "1.75";
                    break;
            case 3:
                output = "1.50";    
                    break;
            case 4:
                output = "1.25";
                    break;
            case 5:
                output = "1.00";
                    break;
            case 6:
                output = "0.75";
                    break;
            case 7:
                output = "0.50";    
                    break;
            case 8:
                output = "0.25";
                    break;                
            default:
                        output = " 0";
                
        }
        double curWinnings = Double.parseDouble(output);
    // d. Print the current winnings on theOutput
        theOutput.append("\nAmount Won: " + curWinnings);
        
 
    // e. Add the current winnings to the amount remaining. 
    //    Store the result back in amtRemaining.
        amtRemaining = amtRemaining + curWinnings;
    // f. Print the player name + the amount left to output
        theOutput.append("\n" + playerName + "'s bankroll: " + amtRemaining);
    // g. Instruct the player to press the New Number button
        theOutput.append("\nPress 'New Number' to continue...");
    // h. Call the updateScore() method
        updateScore();
    // i. Clear theGuess textfield, disable it, set its
    //    background to white, and set focus to the
    //    newNumber button.
        theGuess.setText("");
        theGuess.setBackground(Color.WHITE);
        newNumber.requestFocus();
    
    // COMPILE CHECK # 10 HERE
  }

}