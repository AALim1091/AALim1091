/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rm109
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Side extends JApplet implements ActionListener 
{
    Container content = this.getContentPane();
    JTextField tfArea = new JTextField(10);
    JLabel lblSide = new JLabel();
    JButton btnCalc = new JButton ("Calculate");
    
    public void init ()
    {
     content.setLayout (new FlowLayout());
     content.add (new JLabel ("Area:"));
     content.add(tfArea);
     content.add (new JLabel ("Side:"));
     content.add(lblSide);
     content.add(btnCalc);
     btnCalc.addActionListener(this);
     
    }
    @Override
    public void actionPerformed(ActionEvent e) 
    {
        double area =Double.parseDouble(tfArea.getText());
        lblSide.setText("" + Math.sqrt(area));
    }
    
}
