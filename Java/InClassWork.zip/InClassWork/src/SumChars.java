/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Aaron
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SumChars extends JApplet implements ActionListener
{
    JTextField tfInput = new JTextField(20);
    JLabel lblOutput = new JLabel();
    JButton btn = new JButton ("Click Me");
   
    Container content = this.getContentPane();
   
    @Override
    public void init()
    {
       content.setLayout(new FlowLayout());
       content.add(new JLabel("Input a String"));
       content.add(tfInput);
       content.add(btn);
       content.add(lblOutput);
       btn.addActionListener(this);
    }
   
    @Override
    public void actionPerformed(ActionEvent e)
    {
       String s = tfInput.getText();     
       lblOutput.setText("The sum of chars is " + sumChar(s));
    }
    int sumChar(String s)
    {
        int sum = 0;
        String reverse = "";
      
       for (int i = s.length()- 1; i >= 0; i--)
       {
          sum+= (int) s.charAt(i);
          reverse+= s.charAt(i);
         
       }
       System.out.println(reverse);
       return sum;
    }
   
}