/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Aaron
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SumNums extends JApplet implements ActionListener
{
    JTextField tfNum1 = new JTextField(10);
    JTextField tfNum2 = new JTextField(10);
    JLabel lblOutput = new JLabel();
    JButton Go = new JButton("Go");
    
    Container content = this.getContentPane();
    public void init()
    {
        content.setLayout(new FlowLayout());
        content.add(tfNum1);
        content.add(tfNum2);
        content.add(lblOutput);
        content.add(Go);
        Go.addActionListener(this);
                
        
        
    }
    @Override
    public void actionPerformed(ActionEvent e)
    {
     int num1 = Integer.parseInt(tfNum1.getText());
     int num2 = Integer.parseInt(tfNum2.getText());
     int sum = sumTo(num1, num2);
     lblOutput.setText("The sum of the numbers is " + sum);
    }
    
    public int sumTo (int num1, int num2)
    {
       int small = num1 < num2 ? num1 : num2;
       int large = num1 > num2 ? num1 : num2;
       int sum = 0;
        
        for(int i = num1; i <= num2; i++)
        {
           sum+=i;
        }
        return sum;
    }
    
}

