/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rm109
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FirstApplet extends JApplet implements MouseListener
{
   JLabel lblName = new JLabel ("Aaron Lim");
      Container content = getContentPane();
    public void init()
    {
        Font myFont = new Font("TimesRoman",Font.BOLD, 48);
        lblName.setFont(myFont);
        lblName.setForeground(Color.MAGENTA);
        lblName.setOpaque(true);
        lblName.setBackground(Color.YELLOW);
        lblName.addMouseListener(this);
        content.add(lblName);
    }

    @Override
    public void mouseClicked(MouseEvent e) 
    {
        lblName.setForeground(Color.RED);
        lblName.setBackground(Color.BLACK);
        lblName.setText("Ouch!");
        
    }

    @Override
    public void mousePressed(MouseEvent e) 
    {
        
    }

    @Override
    public void mouseReleased(MouseEvent e) 
    {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) 
    {
        lblName.setText("Hello");
    }

    @Override
    public void mouseExited(MouseEvent e) 
    {
       lblName.setText("GoodBye");
    }
    
}
