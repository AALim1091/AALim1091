import javax.swing.*;
import java.awt.*;
import java.applet.*;
import java.util.*;
import java.awt.event.*;
import java.net.URL;
import java.text.DateFormat;
import javax.swing.*;
import javax.swing.border.*;
import java.text.*;


public class Assignment12 extends JApplet implements Runnable, ActionListener
{
    Thread theThread = null;
   
    Container content = getContentPane();
   
    JTextField txtRed = new JTextField(10);
    JTextField txtGreen = new JTextField(10);
    JTextField txtBlue = new JTextField(10);
   
    JTextField txtIt = new JTextField(10);
    JTextField txtStepAm = new JTextField(10);
    JTextField txtDel = new JTextField(10);
   
    JCheckBox red = new JCheckBox("Red");
    JCheckBox green = new JCheckBox("Green");
    JCheckBox blue = new JCheckBox("Blue");
 
    Color msgColor= new Color(150,100,50);
   
    JPanel top = new JPanel();
    JPanel bot = new JPanel();
   
    JButton srt = new JButton("START");
    JLabel lblCol = new JLabel();
   
    public void init()
    {
        content.setLayout(new BorderLayout());
        content.add(top,BorderLayout.CENTER);  
        top.setLayout(new GridLayout(4,3));
        top.add(new JLabel("RED"));
        top.add(new JLabel("GREEN"));
        top.add(new JLabel("BLUE"));
        top.add(txtRed);
        top.add(txtGreen);
        top.add(txtBlue);
        top.add(new JLabel("Itterations"));
        top.add(new JLabel("Step Amount"));
        top.add(new JLabel("Delay"));
        top.add(txtIt);
        top.add(txtStepAm);
        top.add(txtDel);
        content.add(bot,BorderLayout.SOUTH);
        bot.setLayout(new GridLayout(2,3));
        bot.add(red);
        bot.add(green);
        bot.add(blue);
        bot.add(srt);
        bot.add(lblCol);
        lblCol.setOpaque(true);
        red.setSelected(true);
        green.setSelected(true);
        blue.setSelected(true);
        srt.addActionListener(this);
       
        txtRed.setText("40");
        txtGreen.setText("50");
        txtBlue.setText("60");
        txtIt.setText("10");
        txtStepAm.setText("20");
        txtDel.setText("1000");
    }
    @Override
    public void run()
    {
      int tRed = Integer.parseInt(txtRed.getText());
      int tGreen = Integer.parseInt(txtGreen.getText());
      int tBlue = Integer.parseInt(txtBlue.getText());
     
      int tItt = Integer.parseInt(txtIt.getText());
      int tStep = Integer.parseInt(txtStepAm.getText());
      int tDel = Integer.parseInt(txtDel.getText());
     
      for(int i=0; i<= tItt;i++)
      {
          if(red.isSelected()== true)
          { 
           tRed+=tStep;
          }
          if(tRed>255)
          {
              tRed = 0;
          }
         
          if(blue.isSelected()== true)
             tBlue+=tStep;
          if(tBlue>255)
              tBlue = 0;
         
          if(green.isSelected()== true)
             tGreen+=tStep;
          if(tGreen>255)
              tGreen = 0;
        try
        {
            Thread.sleep(tDel);
        }
        catch(InterruptedException ex){}
       
        String f = (tRed+", "+tGreen+", "+tBlue );
        System.out.println(f);
      lblCol.setText(f);
      Color col = new Color(tRed,tGreen,tBlue);
      lblCol.setOpaque(true);
      lblCol.setBackground(col);
           
      }
     
       
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
      if(theThread==null)
      {
         
      theThread = new Thread(this);
      theThread.start();
      srt.setText("Stop");
      }
       else
    {
     theThread.stop();
      theThread = null;
      srt.setText("Start");
    }
    }
   
}
