/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * Aaron Lim
 * Midterm
 * CSIS-113B
 * April 1, 2013
 */
import java.awt.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.text.*;
import java.util.*;


public class colorConverter extends JApplet implements ActionListener

{

    Container content = this.getContentPane();
    JLabel lblRed = new JLabel("Red");
    JLabel lblGreen = new JLabel ("Green");
    JLabel lblBlue = new JLabel ("Blue");
    
    JTextField tfRed = new JTextField(10);
    JTextField tfGreen = new JTextField(10);
    JTextField tfBlue = new JTextField(10);
   
    JLabel pRed = new JLabel("");
    JLabel pGreen = new JLabel("");
    JLabel pBlue = new JLabel("");
    JLabel wRed = new JLabel();
    JLabel wGreen = new JLabel("");
    JLabel wBlue = new JLabel("");
   
   
    JLabel lblColor = new JLabel("Color");
    JButton btnColor = new JButton ("Show Color");  
   
   
   
   
    public void init()
    {
        content.setLayout(new GridLayout(5,3,5,5));
        
        
        content.add(lblRed);
        content.add(lblGreen);
        content.add(lblBlue);
        
        content.add(tfRed);        
        content.add(tfGreen);        
        content.add(tfBlue);
        
       Border blackBorder = BorderFactory.createLineBorder(Color.BLACK,0);
       

        content.add(pRed);      
        pRed.setBorder(blackBorder);
        pRed.setOpaque(true);
       
        
        content.add(pGreen);      
        pGreen.setBorder(blackBorder);
        pGreen.setOpaque(true);
                     
        
        content.add(pBlue);      
        pBlue.setBorder(blackBorder);
        pBlue.setOpaque(true);
       
        
        content.add(wRed);      
        wRed.setBorder(blackBorder);
        wRed.setOpaque(true);
        
       
      
        content.add(wGreen);      
        wGreen.setBorder(blackBorder);
        wGreen.setOpaque(true);
       
       
        content.add(wBlue);      
        wBlue.setBorder(blackBorder);
        wBlue.setOpaque(true);
              
        content.add(btnColor);
        btnColor.addActionListener(this);
        
        content.add(lblColor);
        lblColor.setBorder(blackBorder);
        lblColor.setOpaque(true);               
                                               
    }
      
    @Override
    public void actionPerformed(ActionEvent e)
    {
       // DecimalFormat fmt = new DecimalFormat(".##");
       
        int R = Integer.valueOf(tfRed.getText(),16);
        int G = Integer.valueOf(tfGreen.getText(),16);   
        int B = Integer.valueOf(tfBlue.getText(),16);
   


        this.Percent();
        this.Whole();
        
        Color color = new Color (R,G,B);
        
        lblColor.setBackground(color);
        
   
    }
    
     public void Percent()
    {
       DecimalFormat fmt = new DecimalFormat("#.##");
       
       int R = Integer.valueOf(tfRed.getText(),16);
       int G = Integer.valueOf(tfGreen.getText(),16);   
       int B = Integer.valueOf(tfBlue.getText(),16);
       
       double r = Math.round(R);      
       pRed.setText("" + fmt.format(r/255));
       double g = Math.round(G);      
       pGreen.setText("" + fmt.format(g/255));
       double b = Math.round(B);      
       pBlue.setText("" + fmt.format(b/255));
       
       
       
       
        
    }
    
   
    
    public void Whole()
    {
        int R = Integer.valueOf(tfRed.getText(),16);
        int G = Integer.valueOf(tfGreen.getText(),16);   
        int B = Integer.valueOf(tfBlue.getText(),16);
        
              
        wRed.setText(""+ R);
        wGreen.setText(""+ G);
        wBlue.setText(""+ B);
        
      
        
        
        
        
    }
   
   
}
