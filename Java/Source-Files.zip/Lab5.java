/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 *  Aaron Lim
 * java 113B
 * 0353402
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;


public class Lab5 extends JApplet implements ActionListener

{
    JTextField tfAmount = new JTextField (10);
    JTextField tfRate = new JTextField (10);
    JTextField tfYear = new JTextField (10);
    JLabel lblPayment = new JLabel ("Monthly Payment");
    JLabel lblTotal = new JLabel ("Total Purchase Cost");
    JButton btnCalculate = new JButton ("Calculate");
    
    
    Container content = getContentPane();
    
    public void init ()
    {
        content.setLayout(new GridLayout (5,2));
        content.add(new JLabel("Amount Borrowed"));
        content.add (tfAmount);
        content.add(new JLabel("Interest Rate"));
        content.add (tfRate);
        content.add(new JLabel("Years To Pay"));
        content.add (tfYear);
        content.add(lblPayment);
        content.add(lblTotal);
        content.add(btnCalculate);
        btnCalculate.addActionListener(this);
        
        
        
    }

    @Override
    public void actionPerformed(ActionEvent e)
    
    {
      NumberFormat fmt = NumberFormat.getCurrencyInstance();
      double Amount = Double.parseDouble (tfAmount.getText());
      double Rate = Double.parseDouble (tfRate.getText());
      double Year = Double.parseDouble (tfYear.getText());
        
      double totRate = Rate / 100;
      double totMonth = totRate / 12;
      double payment = (1-(Math.pow(1/(1+totMonth),Year * 12)));
      
      lblPayment.setText(fmt.format(totMonth));
      lblTotal.setText (fmt.format(payment * 12 * Year));
      
      
      
        
        
        
    }
    
    
    
    
    
    
    
    
}


