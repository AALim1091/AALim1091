/*
 *Aaron Lim
 * Lab 14
 * 0353402
 * CSIS-113B
 * May 27, 2013
 */


import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.Random;

public class Lab14 extends JApplet implements ActionListener,MouseListener
{
    JLabel[] lblBoard = new JLabel[16];
    int[] nums =  {1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8};
    int firstChoice = -1;
    int tries =0;
    JLabel lblFirst = new JLabel();
    JButton btnGame = new JButton("New Game");
    JLabel lblTries = new JLabel("Number of Tries = 0");
    JPanel pnlControl = new JPanel();
    JPanel p = new JPanel();
    Container content = this.getContentPane();
    Font font = new Font("Helvetica",Font.BOLD,24);
    
    public void init()
    {
        creatlbls();
        shuffle();
        
        add(pnlControl,BorderLayout.CENTER);
        p.setLayout(new FlowLayout());
        p.add(btnGame);
        btnGame.addActionListener(this);
        p.add(lblTries);
        add(p,BorderLayout.SOUTH);
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        shuffle();
        firstChoice=-1;
        for(int i = 0; i< lblBoard.length;i++)
        {
            lblBoard[i].setText("");
        }
        tries=0;
        lblTries.setText(""+tries);
        
    }
    public void creatlbls()
    {
         pnlControl.setLayout(new GridLayout(4,4,5,5));
        for(int i =0; i<16;i++)
        {
          lblBoard[i]= new JLabel("", JLabel.CENTER);
          lblBoard[i].setOpaque(true);
          lblBoard[i].setBackground(Color.GREEN);
          lblBoard[i].setForeground(Color.WHITE);
          lblBoard[i].setFont(font);
          lblBoard[i].addMouseListener(this);
          lblBoard[i].setName("" + i );
          pnlControl.add(lblBoard[i]);
        }
        System.out.println("Labels created");
        
    }
     public void shuffle()
    {
        int num1;
        int num2;
        int tmp;
        Random r = new Random(15);
        for(int i = 0; i<500; i++)
        {
            num1 = Math.abs(r.nextInt(nums.length));
            num2 = Math.abs(r.nextInt(nums.length));
            tmp = nums[num1];
            nums[num1] = nums[num2];
            nums[num2] = tmp;
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) 
    {
        JLabel l = (JLabel) e.getSource();
        int theNumber = Integer.parseInt(l.getName());
        if(firstChoice == -1)
        {
            l.setText("" + nums[theNumber]);
            lblFirst=l;
            firstChoice= theNumber;
        }
        else if( nums[theNumber] != nums[firstChoice])
        {
            l.setText("" + nums[theNumber]);
            pnlControl.paintImmediately(0,0, pnlControl.getWidth(), pnlControl.getHeight());
            try
            {  
                 Thread.sleep(250);
              
            }
            catch(InterruptedException ie)    
            {
            
            }
              lblFirst.setText("");
              l.setText("");
              lblFirst = null;
              firstChoice = -1;
              tries++;
              
          }
        else
        {
          l.setText(""+nums[theNumber]);
          firstChoice=-1;
          tries++;
          
        
        }
         lblTries.setText("Number of tries ="+tries);
    }

    public void mousePressed(MouseEvent e)
    {
    }
    public void mouseReleased(MouseEvent e)
    {
    }
    public void mouseEntered(MouseEvent e) 
    {
    }
    public void mouseExited(MouseEvent e)
    {
    }



  
    
}












	

	
		
	

	
		
		
	

	
		

