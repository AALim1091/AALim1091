 /*
 Aaron Lim
 * Lab 3
 * CSIS-113B
 * February 11, 2013
 */

/**
 *
 * @author Aaron
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Magic extends JApplet implements MouseMotionListener
{
    JLabel myName = new JLabel ("Aaron Lim");
    JLabel myID = new JLabel ("0353402");
    Container content = this.getContentPane();
    
 public void init ()
{
    content.setLayout(new FlowLayout());
Font myFont = new Font("TimesRoman",Font.BOLD+Font.ITALIC, 48);
        myName.setFont(myFont);
        myName.setForeground(Color.BLACK);
        myName.setBackground(Color.WHITE);
        content.add(myName);
 Font myFont2 = new Font ("TimesRoman",Font.BOLD,24);
        myID.setFont(myFont);
        myID.setForeground(Color.BLUE);
        myID.setBackground(Color.WHITE);
        content.add(myID);
        content.addMouseMotionListener(this);
    
    
    
}

    @Override
    public void mouseDragged(MouseEvent e)
    {
     myName.setVisible(true);
     myID.setVisible(true);
    }

    @Override
    public void mouseMoved(MouseEvent e)
    {
     myName.setVisible(false);
     myID.setVisible(false);
    }
 
}