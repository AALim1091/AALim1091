/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rm109
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Draw extends JApplet 
{
    @Override
    public void paint(Graphics g)
    {
        //super.paint(g);
        g.setColor(Color.BLUE);
     
        g.setColor(Color.RED);
        g.fillRect(50,75,100,150);
        
        FontMetrics fm = g.getFontMetrics();
        int rowHeight = fm.getHeight();
        String s = "Row height:" + rowHeight;
        int strWidth = fm.stringWidth(s);
       String sWidth= "String Width:" + strWidth;
        
        g.drawString(s, 15, 20);
        g.drawString(sWidth, 15, 50);
        
    }
    
    
    
    
    
    
}
