/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Aaron
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Ascending extends JApplet implements ActionListener

{
JTextField tfNum1 = new JTextField(10);
JTextField tfNum2 = new JTextField(10);
JTextField tfNum3 = new JTextField(10);
JLabel lblOutput = new JLabel();
JButton btn = new JButton("Enter");


Container content = this.getContentPane();

@Override
public void init()
{
        content.setLayout(new FlowLayout());
       
        content.add(tfNum1);
        content.add(tfNum2);
        content.add(tfNum3);
         content.add(btn);
        content.add(lblOutput);
        btn.addActionListener(this);
       

 

}
   
    @Override
    public void actionPerformed(ActionEvent e)
   
   
    {
        int num1,num2,num3;
        num1= Integer.parseInt(tfNum1.getText());
        num2= Integer.parseInt(tfNum2.getText());
        num3= Integer.parseInt(tfNum3.getText());
       
        if(this.isAcending(num1, num2, num3))
        {
       
        lblOutput.setText("Numbers are ascending");
        }
        else
        {
            lblOutput.setText("Number are Not ascending");
           
        }
       
       
       
    
       
              
       }
    public boolean isAcending(int n1, int n2, int n3)
    {
        return n1 < n2 && n2 < n3 ? true : false;
        
        /*
        if(n1 < n2 && n2 < n3)
        {
            return true;
        }
        else
        {
            return false;
        }   
         **/
    
    }
}
