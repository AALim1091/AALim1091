/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Aaron
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Whatnumber extends JApplet implements ActionListener

{
JTextField tfGrade = new JTextField(10);
JLabel lblOutput = new JLabel();
JButton btnCompute = new JButton("Enter");


Container content = this.getContentPane();

@Override
public void init()
{
        content.setLayout(new FlowLayout());
        content.add(new JLabel("Number"));
        content.add(tfGrade);
        content.add(lblOutput);
        content.add(btnCompute);
        btnCompute.addActionListener(this);
       

 

}
   
    @Override
    public void actionPerformed(ActionEvent e)
   
   
    {
        int num = Integer.parseInt(tfGrade.getText());
        String output;
       
       ///String stGrade = tfGrade.getText().toUpperCase();
       //char grade = stGrade.charAt(0);
       switch(num)
       {
           case 1:
               lblOutput.setText("One");
                break;
           case 2:         
               lblOutput.setText("Two");
                 break;
           case 3:                
               lblOutput.setText("Three");
                 break;
           case 4:                  
               lblOutput.setText("Four");
                 break;
           case 5:               
               lblOutput.setText("Five");
                 break; 
               
                 default:
                       output = "Invalid Number";                      
                       lblOutput.setText(output);
      }  
              
       }
   
       
}
   
   
