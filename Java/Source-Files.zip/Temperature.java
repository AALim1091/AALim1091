/**Aaron Lim
 * Lab 3
 * CSIS-113B
 * March 18, 2013
 */
import java.awt.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.text.*;
import java.util.*;

public class Temperature extends JApplet implements ActionListener
{
    Container content = this.getContentPane();
    JTextField tfFarenheit = new JTextField(10);
    JLabel lblCelcius = new JLabel();
    JLabel lblKelvin = new JLabel();
    JButton btnCalculate = new JButton ("Calculate");

   
    
    public void init()
    {
        content.setLayout(new GridLayout(4,2,1,4));
        content.add(new JLabel("Farenheit: ",JLabel.RIGHT));
        content.add(tfFarenheit);
        
        Border blackBorder = BorderFactory.createLineBorder(Color.BLACK,1);
        
        content.add(new JLabel ("Celcius: ",JLabel.RIGHT));
        content.add(lblCelcius);       
        lblCelcius.setBorder(blackBorder);
        lblCelcius.setOpaque(true);
        lblCelcius.setBackground(Color.WHITE);
        
        content.add(new JLabel ("Kelvin: ",JLabel.RIGHT));
        content.add(lblKelvin);
        lblKelvin.setBorder(blackBorder);
        lblKelvin.setOpaque(true);
        lblKelvin.setBackground(Color.WHITE);
        
        content.add(btnCalculate);
        btnCalculate.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        DecimalFormat fmt = new DecimalFormat(".##");
        double val = Double.parseDouble(tfFarenheit.getText());
        double Celcius = this.f2c(val);
        double Kelvin = this.f2k(val);
        lblCelcius.setText("" + fmt.format(Celcius));
        lblKelvin.setText("" + fmt.format(Kelvin));
        
    }
    
    public static final double f2c(double val)
    {       
       double f = (val -32) * 5/9;
        return f;        
    }
    public static final double f2k(double val)
    {
        double k = (val - 32) * 5/9 + 273.15;
        return k;
        
    }
    

  
    
}
