/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rm109
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.*;

public class SimpleText extends JApplet implements ActionListener,MouseMotionListener
{
   Container content = getContentPane();
   JTextField tfNum1 = new JTextField(10);
   JTextField tfNum2 = new JTextField(10);
   JLabel lblOutput = new JLabel();
   JLabel lblDiff = new JLabel();
   JLabel lblProd = new JLabel();
   JButton btn = new JButton("Click Me");
   
   Color diffColor = new Color (255,0,0);
   Color sumColor = new Color (0.0f, 1.0f,0.0f);
   
   public void init()
   {
     content.setLayout(new FlowLayout());
     content.add(tfNum1);
     content.add(new JLabel ("+"));
     content.add(tfNum2);
     content.add(new JLabel("="));
     content.add(lblOutput);
     content.add(new JLabel("difference ="));
     content.add(lblDiff);
     content.add(new JLabel("Product ="));
     content.add(lblProd);
     
 
     content.add(btn);
     btn.addActionListener(this);
     content.addMouseMotionListener(this);
   }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        String myText = tfNum1.getText();
        String myText2 =tfNum2.getText();
        int num1 = Integer.parseInt(myText);
        int num2 = Integer.parseInt(myText2);
        int sum = num1 + num2;
        double diff = num1 - num2;
        double prod = num1 * num2;
        NumberFormat fmt = NumberFormat.getCurrencyInstance();
        lblOutput.setText(fmt.format(sum));
        lblDiff.setText(fmt.format(diff));
        lblProd.setText(fmt.format(prod));
        
        
    }

    @Override
    public void mouseDragged(MouseEvent e)
    {
     lblDiff.setForeground(sumColor);
     lblOutput.setForeground(sumColor);
     lblProd.setForeground(sumColor);
     
    }

    @Override
    public void mouseMoved(MouseEvent e) 
    {
     lblDiff.setForeground(diffColor);
     lblOutput.setForeground(diffColor);
     lblProd.setForeground(diffColor);
     
    }


}


