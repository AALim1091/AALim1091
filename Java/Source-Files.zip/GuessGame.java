/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Aaron
 */
import javax.swing.*;
import java.awt.event.*;

import java.awt.*;
import java.util.*;

public class GuessGame extends JApplet implements ActionListener
{
    JTextField tfNumTimes = new JTextField (10);
    JTextField tfGuess = new JTextField (10);
    JButton btnPlay = new JButton("Guess");
    JLabel lblOutput = new JLabel();

    Container content = this.getContentPane();
    public void init()
    {
    content.setLayout(new GridLayout(3,2));
    content.add(new JLabel ("Number to Search"));
    content.add(tfGuess);
    content.add(new JLabel("Times to Find"));
    content.add(tfNumTimes);
    content.add(btnPlay);
    content.add(lblOutput);
    btnPlay.addActionListener(this);
   
   
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        int guess = Integer.parseInt(tfGuess.getText());
        int numTimes = Integer.parseInt(tfNumTimes.getText());
       
        Random r = new Random();
        int count = 1;
       while(r.nextInt(11) != guess)
       {
          
           count++;
          
       }
       if(count == numTimes)
       {
           lblOutput.setText("You Guessed Right yayay");
       }
        else
       {
          lblOutput.setText("It took" + count + " times to get the number ");
       }
       
       
    }
   
   
}
