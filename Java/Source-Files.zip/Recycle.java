/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rm109
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.*;

public class Recycle extends JApplet implements ActionListener
{
    JTextField tfBottles = new JTextField();
    JTextField tfCans = new JTextField();
    JLabel lblDollars = new JLabel();
    
    JButton btnCalc = new JButton ("Calculate");
    
    Container content = this.getContentPane();
    
    public void init()
    {
       content.setLayout( new GridLayout (4,2));
       content.add(new JLabel("Bottles:"));
       content.add(tfBottles);
       content.add(new JLabel("Cans:"));
       content.add(tfCans);
       content.add(btnCalc);
       content.add(lblDollars);
       btnCalc.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) 
    {
       double bottles = Double.parseDouble(tfBottles.getText());
       double cans = Double.parseDouble(tfCans.getText());
       
       double totBottles = bottles * .070;
       double totCans = cans * .035;
       double totDollars = totBottles + totCans;
       
       NumberFormat fmt = NumberFormat.getCurrencyInstance();
       
       lblDollars.setText(fmt.format(totDollars));
       
       
    }
    
}
