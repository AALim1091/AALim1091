/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rm109
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Math1 extends JApplet implements ActionListener
{
    JPanel pnlTxtArea = new JPanel(); 
    JTextField tfNum1 = new JTextField(10);
    JTextField tfNum2 = new JTextField(10);
    JTextField tfNum3 = new JTextField(10);
    
    JLabel lblSquare = new JLabel();
    JLabel lblCube = new JLabel ();
    JLabel lblSum = new JLabel ();
    
    JButton butCalc = new JButton ("Calculate");
    
    Container content = this.getContentPane ();
    
    public void init()
    {
       pnlTxtArea.setLayout(new GridLayout (2,6));
       pnlTxtArea.add((new JLabel ("num1:", JLabel.RIGHT)));
       pnlTxtArea.add(tfNum1);
       pnlTxtArea.add((new JLabel ("num2:",JLabel.RIGHT)));
       pnlTxtArea.add(tfNum2);
       pnlTxtArea.add((new JLabel ("num3:",JLabel.RIGHT)));
       pnlTxtArea.add(tfNum3);
        
       pnlTxtArea.add((new JLabel ("Square:",JLabel.RIGHT)));
       pnlTxtArea.add(lblSquare);
       pnlTxtArea.add((new JLabel ("Cube:",JLabel.RIGHT)));
       pnlTxtArea.add(lblCube);
       pnlTxtArea.add((new JLabel ("Sum:",JLabel.RIGHT)));
       pnlTxtArea.add(lblSum);
       
        
       content.add(pnlTxtArea, BorderLayout.CENTER);
       content.add(butCalc, BorderLayout.SOUTH);
       butCalc.addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) 
    {
       double num1 = Double.parseDouble (tfNum1.getText());
       double num2 = Double.parseDouble (tfNum2.getText());
       double num3 = Double.parseDouble (tfNum3.getText());
       
       double sum = num1 + num2 + num3;
       double cube = Math.pow(sum, 3.0);
       double square = Math.pow(sum,2.0);
       double sin = Math.sin(sum);
       
       lblSquare.setText("" + square);
       lblCube.setText("" + cube);
       lblSum.setText("" + sum);
       
    }
    
}
